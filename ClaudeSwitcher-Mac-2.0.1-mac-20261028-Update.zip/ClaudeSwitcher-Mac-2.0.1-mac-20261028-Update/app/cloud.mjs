import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import zlib from 'node:zlib';
import { spawn } from 'node:child_process';
import { DatabaseSync } from 'node:sqlite';
import { ITEMS, Problem, requireThat, readJson, atomicJson, exists, safePath, mkdir, isUuid, inspect } from './core.mjs';

export const DEFAULT_SERVER = 'https://ccmanage.zhiyoulm.com';
const ROLES = ['admin', 'member'];
const GROUPS = ['active', 'reserve', 'retired'];
const DETAILS = ['activatedOn', 'organizationId', 'email', 'password', 'totpSecret', 'services', 'note', 'group'];
const META_KEYS = ['activatedOn', 'organizationId', 'email', 'password', 'totpSecret', 'services', 'note'];
const EPOCH_GAP = 11644473600000000n; // Microseconds from 1601 (Chromium cookie epoch) to 1970.
const IV = Buffer.alloc(16, 0x20);
const LIMIT = 1048576;
const UTF8 = new TextDecoder('utf-8', { fatal: true });
const sha256 = data => crypto.createHash('sha256').update(data).digest('hex');
const hostHash = host => crypto.createHash('sha256').update(host, 'utf8').digest();

// Chromium on macOS: "v10" + AES-128-CBC with the Safe Storage password through PBKDF2-SHA1.
export const macKey = password => crypto.pbkdf2Sync(password, 'saltysalt', 1003, 16, 'sha1');

export function openV10(blob, key) {
  requireThat(
    blob instanceof Uint8Array && blob.length >= 19 && blob.length <= LIMIT
      && Buffer.from(blob.subarray(0, 3)).toString('latin1') === 'v10' && (blob.length - 3) % 16 === 0,
    'MIGRATION_CIPHER',
    '这份登录用了暂不支持的加密格式。'
  );
  try {
    const decipher = crypto.createDecipheriv('aes-128-cbc', key, IV);
    return Buffer.concat([decipher.update(blob.subarray(3)), decipher.final()]);
  } catch {
    throw new Problem('MIGRATION_KEY', '这台 Mac 的 Claude 钥匙串密钥解不开该账号存档里的登录数据。');
  }
}

export function sealV10(plain, key) {
  const cipher = crypto.createCipheriv('aes-128-cbc', key, IV);
  return Buffer.concat([Buffer.from('v10'), cipher.update(plain), cipher.final()]);
}

function fileInventory(root, prefix = '', output = {}) {
  const dir = safePath(root, prefix);
  for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
    const key = prefix ? prefix + '/' + entry.name : entry.name;
    const file = safePath(root, key);
    requireThat(!entry.isSymbolicLink() && (entry.isFile() || entry.isDirectory()), 'UNSAFE_FILE', '配置中含有不支持的文件类型。');
    if (entry.isDirectory()) {
      output[key + '/'] = 'directory';
      fileInventory(root, key, output);
    } else {
      output[key] = sha256(fs.readFileSync(file));
    }
  }
  return output;
}

// Checks whether a snapshot directory contains Chromium v10-encrypted cookies (as opposed to synthetic test bytes).
export function hasV10Cookies(root) {
  const network = exists(safePath(root, 'Network', 'Cookies'));
  const source = network ? safePath(root, 'Network', 'Cookies') : safePath(root, 'Cookies');
  if (!exists(source)) return false;
  let scratch = null, db = null;
  try {
    scratch = fs.mkdtempSync(path.join(fs.realpathSync(os.tmpdir()), 'claude-v10-check-'));
    fs.chmodSync(scratch, 0o700);
    for (const suffix of ['', '-wal', '-shm']) {
      const file = safePath(path.dirname(source), path.basename(source) + suffix);
      if (exists(file)) {
        const copy = path.join(scratch, 'Cookies' + suffix);
        fs.copyFileSync(file, copy, fs.constants.COPYFILE_EXCL);
        fs.chmodSync(copy, 0o600);
      }
    }
    db = new DatabaseSync(path.join(scratch, 'Cookies'), { readOnly: true, timeout: 1500 });
    db.exec('PRAGMA query_only=ON; PRAGMA trusted_schema=OFF;');
    const rows = db.prepare("SELECT encrypted_value FROM cookies WHERE host_key IN ('claude.ai','.claude.ai') AND name IN ('sessionKey','sessionKeyV2','sessionKeyV3','lastActiveOrg')").all();
    return rows.some(r => {
      const b = r.encrypted_value instanceof Uint8Array ? Buffer.from(r.encrypted_value) : Buffer.alloc(0);
      return b.length >= 19 && b.subarray(0, 3).toString('latin1') === 'v10' && (b.length - 3) % 16 === 0;
    });
  } catch {
    return false;
  } finally {
    try { db?.close(); } catch {}
    if (scratch) fs.rmSync(scratch, { recursive: true, force: true });
  }
}

// Reads and decrypts first-party Claude login cookies from a snapshot directory, matching 阿常's migration.mjs.
export function readCookies(root, key) {
  const network = exists(safePath(root, 'Network', 'Cookies'));
  const source = network ? safePath(root, 'Network', 'Cookies') : safePath(root, 'Cookies');
  requireThat(exists(source), 'MIGRATION_DATABASE', '登录数据库不存在。');
  let scratch = null, db = null;
  try {
    scratch = fs.mkdtempSync(path.join(fs.realpathSync(os.tmpdir()), 'claude-migrate-'));
    fs.chmodSync(scratch, 0o700);
    for (const suffix of ['', '-wal', '-shm']) {
      const file = safePath(path.dirname(source), path.basename(source) + suffix);
      if (exists(file)) {
        const copy = path.join(scratch, 'Cookies' + suffix);
        fs.copyFileSync(file, copy, fs.constants.COPYFILE_EXCL);
        fs.chmodSync(copy, 0o600);
      }
    }
    try {
      db = new DatabaseSync(path.join(scratch, 'Cookies'), { readOnly: true, timeout: 1500 });
      db.exec('PRAGMA query_only=ON; PRAGMA trusted_schema=OFF;');
    } catch {
      throw new Problem('MIGRATION_DATABASE', '登录数据库无法读取。');
    }
    let schema = '0';
    try {
      schema = String(db.prepare("SELECT value FROM meta WHERE key='version'").get()?.value ?? '0');
    } catch {
      schema = '0';
    }
    if (schema !== '0') {
      requireThat(schema === '23' || schema === '24', 'MIGRATION_SCHEMA', '此版 Claude 的登录数据库格式暂不支持。');
    }
    let statement;
    try {
      statement = db.prepare("SELECT host_key,name,path,value,encrypted_value,expires_utc,is_secure,is_httponly,samesite FROM cookies WHERE host_key IN ('claude.ai','.claude.ai') AND top_frame_site_key='' AND name IN ('sessionKey','sessionKeyV2','sessionKeyV3','lastActiveOrg')");
      statement.setReadBigInts(true);
    } catch {
      try {
        statement = db.prepare("SELECT host_key,name,'/' AS path,value,encrypted_value,expires_utc,1 AS is_secure,1 AS is_httponly,1 AS samesite FROM cookies WHERE host_key IN ('claude.ai','.claude.ai') AND name IN ('sessionKey','sessionKeyV2','sessionKeyV3','lastActiveOrg')");
        statement.setReadBigInts(true);
      } catch {
        throw new Problem('MIGRATION_DATABASE', '登录数据库无法读取。');
      }
    }
    const now = BigInt(Date.now()) * 1000n + EPOCH_GAP, rows = [], seen = new Set();
    let session = false;
    for (const row of statement.all()) {
      requireThat(typeof row.expires_utc === 'bigint', 'MIGRATION_DATABASE', '登录数据库字段格式错误。');
      if (row.expires_utc !== 0n && row.expires_utc <= now) continue;
      requireThat(rows.length < 32, 'MIGRATION_SIZE', '登录 Cookie 数量超过限制。');
      const { host_key: host, name, path: cookiePath } = row;
      requireThat(typeof host === 'string' && typeof name === 'string' && typeof cookiePath === 'string', 'MIGRATION_DATABASE', '登录数据库字段格式错误。');
      requireThat(Buffer.byteLength(host) <= 128 && Buffer.byteLength(name) <= 64 && Buffer.byteLength(cookiePath) <= 256, 'MIGRATION_SIZE', '登录 Cookie 长度超过限制。');
      requireThat(cookiePath === '/', 'MIGRATION_COOKIE_PATH', '登录 Cookie 路径格式不支持。');
      requireThat([row.is_secure, row.is_httponly, row.samesite].every(v => typeof v === 'bigint'), 'MIGRATION_DATABASE', '登录数据库字段格式错误。');
      requireThat(!seen.has(host + '|' + name + '|' + cookiePath), 'MIGRATION_DATABASE', '登录 Cookie 存在重复项。');
      seen.add(host + '|' + name + '|' + cookiePath);
      const encrypted = row.encrypted_value instanceof Uint8Array ? Buffer.from(row.encrypted_value) : Buffer.alloc(0);
      requireThat(encrypted.length <= 65536 + 80, 'MIGRATION_SIZE', '登录 Cookie 超过大小限制。');
      let value;
      if (encrypted.length > 0) {
        const decoded = openV10(encrypted, key);
        const hasPrefix = schema === '24' || (schema === '0' && decoded.length > 32 && crypto.timingSafeEqual(decoded.subarray(0, 32), hostHash(host)));
        const offset = hasPrefix ? 32 : 0;
        requireThat(decoded.length > offset, 'MIGRATION_CIPHER', '登录 Cookie 解密内容无效。');
        if (offset) requireThat(crypto.timingSafeEqual(decoded.subarray(0, 32), hostHash(host)), 'MIGRATION_HOST', '登录 Cookie 的主机校验未通过。');
        value = Buffer.from(decoded.subarray(offset));
        decoded.fill(0);
      } else {
        requireThat(typeof row.value === 'string' && Buffer.byteLength(row.value) <= 65536, 'MIGRATION_SIZE', '登录 Cookie 超过大小限制。');
        value = Buffer.from(row.value, 'utf8');
      }
      encrypted.fill(0);
      requireThat(value.length > 0 && value.length <= 65536, 'MIGRATION_CIPHER', '登录 Cookie 内容为空。');
      requireThat((row.is_secure === 0n || row.is_secure === 1n) && (row.is_httponly === 0n || row.is_httponly === 1n) && row.samesite >= -1n && row.samesite <= 2n, 'MIGRATION_DATABASE', '登录 Cookie 属性无效。');
      rows.push({
        host,
        name,
        path: cookiePath,
        valueBase64: value.toString('base64'),
        expiresUtc: row.expires_utc.toString(),
        secure: row.is_secure === 1n,
        httpOnly: row.is_httponly === 1n,
        sameSite: Number(row.samesite),
      });
      value.fill(0);
      if (name.startsWith('sessionKey')) session = true;
    }
    requireThat(session, 'MIGRATION_EXPIRED', '这个账号的存档里没有未过期的桌面登录。');
    return rows;
  } finally {
    try { db?.close(); } catch {}
    if (scratch) fs.rmSync(scratch, { recursive: true, force: true });
  }
}

function selectGrants(cache, uuid, code) {
  requireThat(cache && typeof cache === 'object' && !Array.isArray(cache), code, '桌面授权缓存格式无效。');
  const selected = {}, prefix = 'acct:' + uuid.toLowerCase() + '|';
  for (const [name, grant] of Object.entries(cache)) {
    if (!name.toLowerCase().startsWith(prefix)) continue;
    requireThat(name.length <= 4096 && grant && typeof grant === 'object' && !Array.isArray(grant), code, '桌面授权缓存条目无效。');
    if (typeof grant.token === 'string' && grant.token.length > 0 && grant.token.length <= 65536 && typeof grant.expiresAt === 'number' && Number.isFinite(grant.expiresAt)) {
      selected[name] = { token: grant.token, expiresAt: grant.expiresAt };
      requireThat(Object.keys(selected).length <= 128, 'MIGRATION_SIZE', '桌面授权缓存条目过多。');
    }
  }
  return selected;
}

function readCache(config, uuid, key) {
  let text = config?.['oauth:tokenCacheV2'];
  if (typeof text !== 'string' || !text) text = config?.['oauth:tokenCache'];
  if (typeof text !== 'string' || !text) return {};
  if (text.length > 1400000 || !/^([A-Za-z0-9+/]{4})*([A-Za-z0-9+/]{2}==|[A-Za-z0-9+/]{3}=)?$/.test(text)) return {};
  try {
    const plain = openV10(Buffer.from(text, 'base64'), key);
    try {
      const parsed = JSON.parse(UTF8.decode(plain).replace(/^\uFEFF+/, ''));
      return selectGrants(parsed, uuid, 'MIGRATION_SNAPSHOT');
    } finally {
      plain.fill(0);
    }
  } catch {
    return {};
  }
}

// Reads a snapshot's cookies and token cache using one or more candidate Keychain keys (Buffer or string).
export function readLogin(root, uuid, keyOrKeys) {
  let config;
  try { config = readJson(safePath(root, 'config.json')); } catch { throw new Problem('MIGRATION_SNAPSHOT', '账号存档配置无法读取。'); }
  requireThat(config && typeof config === 'object' && !Array.isArray(config), 'MIGRATION_SNAPSHOT', '账号存档配置格式错误。');
  const cleanUuid = String(uuid || config.lastKnownAccountUuid || '').toLowerCase();
  requireThat(isUuid(cleanUuid) && String(config.lastKnownAccountUuid || '').toLowerCase() === cleanUuid, 'MIGRATION_IDENTITY', '账号身份与存档不一致。');
  const rawList = Array.isArray(keyOrKeys) ? keyOrKeys : [keyOrKeys];
  const keys = rawList.filter(Boolean).map(k => Buffer.isBuffer(k) ? k : macKey(String(k)));
  requireThat(keys.length > 0, 'KEYCHAIN_READ_FAILED', '缺少钥匙串密钥，无法解封账号快照。');
  let lastError = null;
  for (const key of keys) {
    try {
      const cookies = readCookies(root, key);
      const cache = readCache(config, cleanUuid, key);
      let organizationId = null;
      const orgCookie = cookies.find(c => c.name === 'lastActiveOrg');
      if (orgCookie) {
        try {
          const orgText = Buffer.from(orgCookie.valueBase64, 'base64').toString('utf8').trim();
          if (isUuid(orgText)) organizationId = orgText.toLowerCase();
        } catch {}
      }
      return { cookies, cache, organizationId };
    } catch (e) {
      lastError = e;
    }
  }
  throw lastError || new Problem('MIGRATION_KEY', '这台 Mac 的 Claude 钥匙串密钥解不开该账号存档。');
}

export function parseLogin(raw) {
  let payload = raw;
  if (Buffer.isBuffer(raw) || raw instanceof Uint8Array) {
    try { payload = JSON.parse(UTF8.decode(raw).replace(/^\uFEFF+/, '')); } catch { throw new Problem('BAD_BUNDLE', '云端登录载荷格式无效。'); }
  }
  requireThat(payload && typeof payload === 'object' && !Array.isArray(payload), 'BAD_BUNDLE', '云端登录载荷格式无效。');
  requireThat(payload.format === 1 && payload.kind === 'claude-desktop-account', 'BAD_BUNDLE', '云端登录载荷版本不支持。');
  requireThat(typeof payload.accountUuid === 'string' && isUuid(payload.accountUuid), 'BAD_BUNDLE', '云端登录载荷缺少账号标识。');
  const uuid = payload.accountUuid.toLowerCase();
  requireThat(Array.isArray(payload.cookies) && payload.cookies.length > 0 && payload.cookies.length <= 32, 'BAD_BUNDLE', '云端登录载荷缺少有效 Cookie。');
  const seen = new Set();
  let organizationId = null;
  const cookies = payload.cookies.map(row => {
    requireThat(row && typeof row === 'object' && !Array.isArray(row), 'BAD_BUNDLE', '云端 Cookie 条目无效。');
    requireThat(row.host === 'claude.ai' || row.host === '.claude.ai', 'BAD_BUNDLE', '云端 Cookie 域名不受支持。');
    requireThat(typeof row.name === 'string' && row.name.length > 0 && row.name.length <= 64 && !/[\x00-\x20\x7f;=]/.test(row.name), 'BAD_BUNDLE', '云端 Cookie 名称无效。');
    requireThat(row.path === '/', 'BAD_BUNDLE', '云端 Cookie 路径无效。');
    requireThat(!seen.has(row.host + '|' + row.name), 'BAD_BUNDLE', '云端 Cookie 存在重复项。');
    seen.add(row.host + '|' + row.name);
    requireThat(typeof row.valueBase64 === 'string' && row.valueBase64.length % 4 === 0 && /^[A-Za-z0-9+/]*={0,2}$/.test(row.valueBase64), 'BAD_BUNDLE', '云端 Cookie 值编码无效。');
    const value = Buffer.from(row.valueBase64, 'base64');
    requireThat(value.length > 0 && value.length <= 65536, 'BAD_BUNDLE', '云端 Cookie 值长度无效。');
    if (row.name === 'lastActiveOrg') {
      const orgText = value.toString('utf8').trim();
      if (isUuid(orgText)) organizationId = orgText.toLowerCase();
    }
    let expiry;
    if (typeof row.expiresUtc === 'string') {
      requireThat(/^\d{1,19}$/.test(row.expiresUtc), 'BAD_BUNDLE', '云端 Cookie 过期时间无效。');
      expiry = BigInt(row.expiresUtc);
    } else {
      requireThat(Number.isSafeInteger(row.expiresUtc), 'BAD_BUNDLE', '云端 Cookie 过期时间无效。');
      expiry = BigInt(row.expiresUtc);
    }
    requireThat(expiry >= 0n && expiry <= 9223372036854775807n, 'BAD_BUNDLE', '云端 Cookie 过期时间超出范围。');
    requireThat(typeof row.secure === 'boolean' && typeof row.httpOnly === 'boolean' && Number.isInteger(row.sameSite) && row.sameSite >= -1 && row.sameSite <= 2, 'BAD_BUNDLE', '云端 Cookie 安全属性无效。');
    return { host: row.host, name: row.name, value, expiry, secure: row.secure, httpOnly: row.httpOnly, sameSite: row.sameSite };
  });
  requireThat(cookies.some(c => c.name.startsWith('sessionKey')), 'BAD_BUNDLE', '云端登录载荷缺少 sessionKey。');
  const cache = payload.desktopTokenCache == null ? {} : selectGrants(payload.desktopTokenCache, uuid, 'BAD_BUNDLE');
  return { uuid, cookies, cache, organizationId, sourcePlatform: typeof payload.sourcePlatform === 'string' ? payload.sourcePlatform : 'darwin' };
}

// Writes a clean Chromium schema 24 cookie database sealed with this Mac's key; no -wal or -journal is left beside it.
export function writeCookies(file, cookies, key) {
  const db = new DatabaseSync(file);
  try {
    db.exec(
      "PRAGMA journal_mode=DELETE;" +
      "CREATE TABLE meta(key LONGVARCHAR NOT NULL UNIQUE PRIMARY KEY, value LONGVARCHAR);" +
      "INSERT INTO meta(key,value) VALUES('version','24'),('last_compatible_version','24'),('mmap_status','-1');" +
      "CREATE TABLE cookies(creation_utc INTEGER NOT NULL,host_key TEXT NOT NULL,top_frame_site_key TEXT NOT NULL,name TEXT NOT NULL,value TEXT NOT NULL,encrypted_value BLOB NOT NULL,path TEXT NOT NULL,expires_utc INTEGER NOT NULL,is_secure INTEGER NOT NULL,is_httponly INTEGER NOT NULL,last_access_utc INTEGER NOT NULL,has_expires INTEGER NOT NULL,is_persistent INTEGER NOT NULL,priority INTEGER NOT NULL,samesite INTEGER NOT NULL,source_scheme INTEGER NOT NULL,source_port INTEGER NOT NULL,last_update_utc INTEGER NOT NULL,source_type INTEGER NOT NULL,has_cross_site_ancestor INTEGER NOT NULL);" +
      "CREATE UNIQUE INDEX cookies_unique_index ON cookies(host_key, top_frame_site_key, has_cross_site_ancestor, name, path, source_scheme, source_port);"
    );
    const insert = db.prepare("INSERT INTO cookies(creation_utc,host_key,top_frame_site_key,name,value,encrypted_value,path,expires_utc,is_secure,is_httponly,last_access_utc,has_expires,is_persistent,priority,samesite,source_scheme,source_port,last_update_utc,source_type,has_cross_site_ancestor) VALUES(?,?,'',?,'',?,'/',?,?,?,?,?,?,1,?,?,443,?,1,1)");
    const now = BigInt(Date.now()) * 1000n + EPOCH_GAP;
    db.exec('BEGIN');
    for (const c of cookies) {
      const plain = Buffer.concat([hostHash(c.host), c.value]);
      const sealed = sealV10(plain, key);
      const persistent = c.expiry === 0n ? 0 : 1;
      try {
        insert.run(now, c.host, c.name, sealed, c.expiry, c.secure ? 1 : 0, c.httpOnly ? 1 : 0, now, persistent, persistent, c.sameSite, c.secure ? 2 : 1, now);
      } finally {
        plain.fill(0);
        sealed.fill(0);
      }
    }
    db.exec('COMMIT');
  } finally {
    db.close();
  }
}

function writeFileSynced(file, data) {
  const fd = fs.openSync(file, 'wx', 0o600);
  try { fs.writeFileSync(fd, data); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
}

// Rebuilds a snapshot payload directory using this Mac's Safe Storage key, matching 阿常's buildSnapshot.
function buildPortablePayload(payloadDir, root, login, keyBuffer, coworkBytes = null) {
  for (const item of ITEMS) {
    const p = safePath(payloadDir, item);
    if (exists(p)) fs.rmSync(p, { recursive: true, force: true });
  }
  const config = { lastKnownAccountUuid: login.uuid };
  if (login.cache && Object.keys(login.cache).length > 0) {
    const plain = Buffer.from(JSON.stringify(login.cache), 'utf8');
    try { config['oauth:tokenCacheV2'] = sealV10(plain, keyBuffer).toString('base64'); }
    finally { plain.fill(0); }
  }
  writeFileSynced(path.join(payloadDir, 'config.json'), JSON.stringify(config, null, 2) + '\n');
  writeFileSynced(path.join(payloadDir, 'Local State'), '{}\n');
  mkdir(path.join(payloadDir, 'Local Storage'));
  mkdir(path.join(payloadDir, 'Session Storage'));
  if (coworkBytes instanceof Uint8Array && coworkBytes.length > 0) {
    writeFileSynced(path.join(payloadDir, 'cowork-enabled-cli-ops.json'), coworkBytes);
  }
  let cookieFile = path.join(payloadDir, 'Network', 'Cookies');
  if (inspect(root).layout === 'root') cookieFile = path.join(payloadDir, 'Cookies');
  else mkdir(path.join(payloadDir, 'Network'));
  writeCookies(cookieFile, login.cookies, keyBuffer);
  fs.chmodSync(cookieFile, 0o600);
  for (const suffix of ['-journal', '-wal', '-shm']) {
    try { fs.unlinkSync(cookieFile + suffix); } catch {}
  }
}

export function canDecryptSnapshot(payloadDir, uuid, keychainSecret) {
  if (!keychainSecret) return true;
  if (!hasV10Cookies(payloadDir)) return true;
  try {
    readLogin(payloadDir, uuid, keychainSecret);
    return true;
  } catch {
    return false;
  }
}

export function normalizeServerUrl(value) {
  const raw = typeof value === 'string' && value.trim() ? value.trim() : DEFAULT_SERVER;
  let parsed;
  try { parsed = new URL(raw); } catch {}
  requireThat(
    raw.length <= 512 && !/[\s\x00-\x1f\x7f]/.test(raw) && parsed && ['http:', 'https:'].includes(parsed.protocol) && parsed.hostname && !parsed.search && !parsed.hash,
    'BAD_SERVER_URL',
    '云端服务地址格式无效，请填写以 http:// 或 https:// 开头的地址。'
  );
  if (parsed.hostname.toLowerCase() === 'ccmanage.zhiyoulm.com' && parsed.protocol === 'http:') {
    parsed.protocol = 'https:';
  }
  return parsed.href.replace(/\/+$/, '');
}

function collectEntries(root, prefix = '', entries = {}) {
  const dir = safePath(root, prefix);
  for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name))) {
    const key = prefix ? prefix + '/' + entry.name : entry.name;
    const full = safePath(root, key);
    requireThat(!entry.isSymbolicLink() && (entry.isFile() || entry.isDirectory()), 'UNSAFE_FILE', '配置中含有不支持的文件类型。');
    if (entry.isDirectory()) {
      entries[key + '/'] = null;
      collectEntries(root, key, entries);
    } else {
      entries[key] = fs.readFileSync(full).toString('base64');
    }
  }
  return entries;
}

function soleOrgFolder(root, uuid) {
  if (!root || !isUuid(uuid)) return null;
  const base = path.join(root, 'claude-code-sessions', uuid.toLowerCase());
  if (!exists(base)) return null;
  try {
    const orgs = fs.readdirSync(base, { withFileTypes: true }).filter(e => e.isDirectory() && isUuid(e.name)).map(e => e.name.toLowerCase());
    return orgs.length === 1 ? orgs[0] : null;
  } catch {
    return null;
  }
}

function sanitizeMeta(source) {
  if (!source || typeof source !== 'object') return {};
  const meta = {};
  if (typeof source.activatedOn === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(source.activatedOn)) meta.activatedOn = source.activatedOn;
  if (isUuid(source.organizationId)) meta.organizationId = source.organizationId.toLowerCase();
  if (typeof source.email === 'string' && source.email.trim().length > 0 && source.email.trim().length <= 254) meta.email = source.email.trim();
  if (typeof source.password === 'string' && source.password.trim().length > 0 && source.password.trim().length <= 200) meta.password = source.password.trim();
  if (typeof source.totpSecret === 'string' && source.totpSecret.trim().length > 0 && source.totpSecret.trim().length <= 200) meta.totpSecret = source.totpSecret.trim();
  if (typeof source.services === 'string' && source.services.trim().length > 0 && source.services.trim().length <= 200) meta.services = source.services.trim().normalize('NFC');
  if (typeof source.note === 'string' && source.note.trim().length > 0 && source.note.trim().length <= 200) meta.note = source.note.trim().normalize('NFC');
  return meta;
}

export function packSnapshot(core, snapshotId, { keychainSecret = null, uuid = null, accountMeta = null } = {}) {
  const snap = core.snapshot(snapshotId);
  let accountUuid = isUuid(uuid) ? uuid.toLowerCase() : null;
  if (!accountUuid) {
    try {
      const cfg = readJson(safePath(snap.payload, 'config.json'));
      if (isUuid(cfg?.lastKnownAccountUuid)) accountUuid = cfg.lastKnownAccountUuid.toLowerCase();
    } catch {}
  }
  let loginPayload = null;
  let organizationId = soleOrgFolder(core.root, accountUuid);
  if (keychainSecret && accountUuid && hasV10Cookies(snap.payload)) {
    const login = readLogin(snap.payload, accountUuid, keychainSecret);
    if (login.organizationId) organizationId = login.organizationId;
    loginPayload = {
      format: 1,
      kind: 'claude-desktop-account',
      sourcePlatform: 'darwin',
      createdAt: new Date().toISOString(),
      accountUuid,
      cookies: login.cookies,
      desktopTokenCache: login.cache,
    };
  }
  const cleanMeta = sanitizeMeta(accountMeta);
  if (!cleanMeta.organizationId && isUuid(organizationId)) cleanMeta.organizationId = organizationId.toLowerCase();
  const raw = {
    format: 1,
    manifest: {
      format: 1,
      kind: 'account',
      id: snap.id,
      created: snap.created,
      items: snap.items,
      files: snap.files,
    },
    entries: collectEntries(snap.payload),
    ...(loginPayload ? { login: loginPayload } : {}),
    ...(Object.keys(cleanMeta).length > 0 ? { accountMeta: cleanMeta } : {}),
  };
  const gz = zlib.gzipSync(Buffer.from(JSON.stringify(raw), 'utf8'));
  return { bundle: gz.toString('base64'), sha256: sha256(gz), organizationId };
}

export function unpackSnapshot(core, { snapshotId, bundle, sha256: expectedHash, localKeychainSecret = null, remoteKeychainSecret = null }) {
  requireThat(isUuid(snapshotId), 'BAD_SNAPSHOT', '云端快照编号无效。');
  requireThat(typeof expectedHash === 'string' && /^[a-f0-9]{64}$/i.test(expectedHash), 'BAD_BUNDLE', '云端快照缺少有效的 SHA-256 校验值。');
  requireThat(typeof bundle === 'string' && bundle.length > 0 && bundle.length <= 128 * 1024 * 1024, 'BAD_BUNDLE', '云端快照数据无效。');
  const gz = Buffer.from(bundle, 'base64');
  requireThat(sha256(gz) === expectedHash.toLowerCase(), 'BAD_BUNDLE', '云端快照校验失败，数据可能已损坏，请重新同步。');
  let raw;
  try {
    raw = JSON.parse(zlib.gunzipSync(gz, { maxOutputLength: 128 * 1024 * 1024 }).toString('utf8'));
  } catch {
    throw new Problem('BAD_BUNDLE', '云端快照解压失败。');
  }
  const m = raw?.manifest;
  requireThat(
    raw?.format === 1 && m?.format === 1 && m.id === snapshotId && Array.isArray(m.items) && m.items.every(x => ITEMS.includes(x))
      && new Set(m.items).size === m.items.length && m.files && typeof m.files === 'object' && !Array.isArray(m.files)
      && raw.entries && typeof raw.entries === 'object' && !Array.isArray(raw.entries),
    'BAD_BUNDLE',
    '云端快照格式不正确。'
  );
  const snapshotsDir = core.p('snapshots');
  mkdir(snapshotsDir);
  const stage = safePath(snapshotsDir, '.cloud-stage-' + crypto.randomUUID());
  const stagePayload = path.join(stage, 'payload');
  const target = safePath(snapshotsDir, snapshotId);
  const backup = exists(target) ? safePath(snapshotsDir, '.cloud-backup-' + crypto.randomUUID()) : null;
  let organizationId = null;
  const accountMeta = sanitizeMeta(raw.accountMeta);
  try {
    mkdir(stagePayload);
    for (const [rel, content] of Object.entries(raw.entries)) {
      requireThat(
        typeof rel === 'string' && rel.length > 0 && !rel.startsWith('/') && !rel.includes('\\') && !rel.split('/').includes('..')
          && m.items.includes(rel.split('/')[0]),
        'BAD_BUNDLE',
        '云端快照包含不允许的文件路径。'
      );
      if (rel.endsWith('/')) {
        requireThat(content === null, 'BAD_BUNDLE', '云端快照目录项格式错误。');
        mkdir(safePath(stagePayload, rel.slice(0, -1)));
      } else {
        requireThat(typeof content === 'string', 'BAD_BUNDLE', '云端快照文件项格式错误。');
        const dest = safePath(stagePayload, rel);
        mkdir(path.dirname(dest));
        const fd = fs.openSync(dest, 'wx', 0o600);
        try { fs.writeFileSync(fd, Buffer.from(content, 'base64')); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
      }
    }

    let items = m.items;
    let files = m.files;
    const coworkBytes = typeof raw.entries['cowork-enabled-cli-ops.json'] === 'string'
      ? Buffer.from(raw.entries['cowork-enabled-cli-ops.json'], 'base64')
      : null;

    if (localKeychainSecret) {
      let login = null;
      if (raw.login && typeof raw.login === 'object') {
        login = parseLogin(raw.login);
      } else if (hasV10Cookies(stagePayload)) {
        const cfg = readJson(safePath(stagePayload, 'config.json'));
        const decoded = readLogin(stagePayload, cfg?.lastKnownAccountUuid, [remoteKeychainSecret, localKeychainSecret]);
        login = parseLogin({
          format: 1,
          kind: 'claude-desktop-account',
          sourcePlatform: 'darwin',
          accountUuid: String(cfg.lastKnownAccountUuid).toLowerCase(),
          cookies: decoded.cookies,
          desktopTokenCache: decoded.cache,
        });
      }
      if (login) {
        organizationId = login.organizationId;
        const keyBuf = macKey(localKeychainSecret);
        try {
          buildPortablePayload(stagePayload, core.root, login, keyBuf, coworkBytes);
          items = ITEMS.filter(item => exists(path.join(stagePayload, item)));
          files = fileInventory(stagePayload);
        } finally {
          keyBuf.fill(0);
          for (const c of login.cookies) c.value?.fill?.(0);
        }
      }
    } else if (raw.login && typeof raw.login === 'object') {
      try { organizationId = parseLogin(raw.login).organizationId; } catch {}
    }

    if (Object.keys(accountMeta).length > 0) {
      atomicJson(path.join(stage, '.account-meta.json'), accountMeta);
    }
    atomicJson(path.join(stage, 'manifest.json'), {
      format: 1,
      kind: 'account',
      id: snapshotId,
      created: typeof m.created === 'string' ? m.created : new Date().toISOString(),
      root: core.root,
      items,
      files,
    });
    if (backup) fs.renameSync(target, backup);
    fs.renameSync(stage, target);
    core.snapshot(snapshotId);
    if (backup) fs.rmSync(backup, { recursive: true, force: true });
    return { organizationId, accountMeta };
  } catch (e) {
    try { fs.rmSync(stage, { recursive: true, force: true }); } catch {}
    if (backup && exists(backup)) {
      try { fs.rmSync(target, { recursive: true, force: true }); fs.renameSync(backup, target); } catch {}
    }
    throw e instanceof Problem ? e : new Problem('BAD_BUNDLE', '云端快照恢复校验未通过。');
  }
}

function reSealExistingSnapshot(core, snapshotId, uuid, localKeychainSecret, remoteKeychainSecret) {
  if (!localKeychainSecret) return null;
  let snap;
  try { snap = core.snapshot(snapshotId); } catch { return null; }
  if (!hasV10Cookies(snap.payload)) return null;
  if (canDecryptSnapshot(snap.payload, uuid, localKeychainSecret)) {
    try { return readLogin(snap.payload, uuid, localKeychainSecret).organizationId; } catch { return null; }
  }
  if (!remoteKeychainSecret) return null;
  let decoded;
  try { decoded = readLogin(snap.payload, uuid, [remoteKeychainSecret]); } catch { return null; }
  const login = parseLogin({
    format: 1,
    kind: 'claude-desktop-account',
    sourcePlatform: 'darwin',
    accountUuid: uuid.toLowerCase(),
    cookies: decoded.cookies,
    desktopTokenCache: decoded.cache,
  });
  const coworkPath = safePath(snap.payload, 'cowork-enabled-cli-ops.json');
  const coworkBytes = exists(coworkPath) ? fs.readFileSync(coworkPath) : null;
  const snapshotsDir = core.p('snapshots');
  const stage = safePath(snapshotsDir, '.cloud-reseal-' + crypto.randomUUID());
  const stagePayload = path.join(stage, 'payload');
  const target = safePath(snapshotsDir, snapshotId);
  const backup = safePath(snapshotsDir, '.cloud-backup-' + crypto.randomUUID());
  const keyBuf = macKey(localKeychainSecret);
  try {
    mkdir(stagePayload);
    buildPortablePayload(stagePayload, core.root, login, keyBuf, coworkBytes);
    const items = ITEMS.filter(item => exists(path.join(stagePayload, item)));
    const files = fileInventory(stagePayload);
    atomicJson(path.join(stage, 'manifest.json'), {
      format: 1,
      kind: 'account',
      id: snapshotId,
      created: snap.created,
      root: core.root,
      items,
      files,
    });
    fs.renameSync(target, backup);
    fs.renameSync(stage, target);
    core.snapshot(snapshotId);
    fs.rmSync(backup, { recursive: true, force: true });
    return login.organizationId;
  } catch {
    try { fs.rmSync(stage, { recursive: true, force: true }); } catch {}
    if (exists(backup)) {
      try { fs.rmSync(target, { recursive: true, force: true }); fs.renameSync(backup, target); } catch {}
    }
    return null;
  } finally {
    keyBuf.fill(0);
    for (const c of login.cookies) c.value?.fill?.(0);
  }
}

function queryKeychainAccount(account) {
  return new Promise((resolve, reject) => {
    const args = account === null
      ? ['find-generic-password', '-s', 'Claude Safe Storage', '-w']
      : ['find-generic-password', '-a', account, '-s', 'Claude Safe Storage', '-w'];
    const child = spawn('/usr/bin/security', args, { stdio: ['ignore', 'pipe', 'pipe'] });
    let stdout = '';
    const timer = setTimeout(() => { child.kill(); reject(new Problem('KEYCHAIN_TIMEOUT', '读取钥匙串超时，请在系统弹窗中允许访问后重试。')); }, 30000);
    child.stdout.on('data', d => { stdout += d.toString('utf8'); });
    child.on('error', () => { clearTimeout(timer); reject(new Problem('KEYCHAIN_READ_FAILED', '无法调用系统钥匙串工具。')); });
    child.on('close', code => {
      clearTimeout(timer);
      const secret = stdout.replace(/\r?\n$/, '');
      if (code === 44) return resolve(null);
      if (code !== 0 || !secret) return reject(new Problem('KEYCHAIN_READ_FAILED', '未能读取本机 Claude Safe Storage 钥匙串密钥。请确认本机已打开过 Claude，并在系统钥匙串弹窗中点击“允许”。'));
      resolve(secret);
    });
  });
}

// Electron keeps the safeStorage key under "Claude Safe Storage" with account "Claude Key";
// "Claude" and any account are checked as fallbacks (matching 阿常's desktopKey in mac-services.mjs).
export async function readMacKeychain() {
  requireThat(process.platform === 'darwin', 'MAC_ONLY', '钥匙串操作仅支持 macOS。');
  for (const account of ['Claude Key', 'Claude', null]) {
    const secret = await queryKeychainAccount(account);
    if (secret !== null) return secret;
  }
  throw new Problem('KEYCHAIN_READ_FAILED', '钥匙串里没有找到 Claude 的加密钥匙（Claude Safe Storage）。请先打开一次 Claude（看到登录页即可），按 ⌘Q 退出后再试。');
}

export async function readMacKeychainAll() {
  requireThat(process.platform === 'darwin', 'MAC_ONLY', '钥匙串操作仅支持 macOS。');
  const found = [];
  for (const account of ['Claude Key', 'Claude', null]) {
    const secret = await queryKeychainAccount(account);
    if (secret !== null && !found.includes(secret)) found.push(secret);
  }
  if (!found.length) {
    throw new Problem('KEYCHAIN_READ_FAILED', '钥匙串里没有找到 Claude 的加密钥匙（Claude Safe Storage）。请先打开一次 Claude（看到登录页即可），按 ⌘Q 退出后再试。');
  }
  return found;
}

// Writes the secret through `security -i` stdin using hex (-X) so the secret never appears in process arguments.
// Only used as a fallback if the target Mac has never opened Claude and has no "Claude Safe Storage" key yet.
export function writeMacKeychain(secret) {
  requireThat(process.platform === 'darwin', 'MAC_ONLY', '钥匙串操作仅支持 macOS。');
  requireThat(typeof secret === 'string' && secret.length > 0 && secret.length <= 4096, 'BAD_KEYCHAIN_SECRET', '云端下发的钥匙串密钥格式无效。');
  const hex = Buffer.from(secret, 'utf8').toString('hex');
  return new Promise((resolve, reject) => {
    const child = spawn('/usr/bin/security', ['-i'], { stdio: ['pipe', 'ignore', 'pipe'] });
    const timer = setTimeout(() => { child.kill(); reject(new Problem('KEYCHAIN_TIMEOUT', '写入钥匙串超时，请在系统弹窗中允许访问后重试。')); }, 30000);
    child.on('error', () => { clearTimeout(timer); reject(new Problem('KEYCHAIN_WRITE_FAILED', '无法调用系统钥匙串工具。')); });
    child.on('close', code => {
      clearTimeout(timer);
      if (code !== 0) return reject(new Problem('KEYCHAIN_WRITE_FAILED', '未能写入本机 Claude Safe Storage 钥匙串密钥。若系统弹出钥匙串授权框，请输入开机密码允许。'));
      resolve();
    });
    child.stdin.on('error', () => {});
    child.stdin.end(`add-generic-password -U -A -s "Claude Safe Storage" -a "Claude Key" -X ${hex}\n`);
  });
}

function cleanAccountMeta(raw) {
  requireThat(raw && typeof raw === 'object', 'BAD_CLOUD_DATA', '云端返回的账号数据格式无效。');
  requireThat(isUuid(raw.id) && isUuid(raw.uuid) && isUuid(raw.snapshot), 'BAD_CLOUD_DATA', '云端账号缺少有效标识。');
  requireThat(typeof raw.label === 'string' && raw.label.trim().length > 0 && raw.label.trim().length <= 80, 'BAD_CLOUD_DATA', '云端账号名称无效。');
  const account = {
    id: raw.id.toLowerCase(),
    label: raw.label.trim().normalize('NFC'),
    uuid: raw.uuid.toLowerCase(),
    snapshot: raw.snapshot.toLowerCase(),
    saved: typeof raw.saved === 'string' && !isNaN(Date.parse(raw.saved)) ? raw.saved : new Date().toISOString(),
    ...sanitizeMeta(raw),
  };
  if (typeof raw.group === 'string' && GROUPS.includes(raw.group) && raw.group !== 'active') account.group = raw.group;
  return account;
}

export class Cloud {
  constructor({ store, core, fetcher = fetch, readKeychain = readMacKeychain, writeKeychain = writeMacKeychain }) {
    Object.assign(this, { store: path.resolve(store), core, fetcher, readKeychain, writeKeychain, keyCache: null });
  }
  async getKeychain() {
    if (typeof this.keyCache === 'string' && this.keyCache.length > 0) return this.keyCache;
    const secret = await this.readKeychain();
    if (typeof secret === 'string' && secret.length > 0) this.keyCache = secret;
    return secret;
  }
  file() { return safePath(this.store, 'cloud.json'); }
  load() {
    const empty = { format: 1, url: DEFAULT_SERVER, username: '', token: null, user: null, keychainHash: null, assigned: {}, syncedSnapshots: {}, stashedAccounts: [], lastSync: null };
    if (!exists(this.file())) return empty;
    let data;
    try { data = readJson(this.file()); } catch { throw new Problem('CLOUD_CORRUPT', '云端登录记录损坏，请重新登录。'); }
    requireThat(data?.format === 1 && typeof data === 'object' && !Array.isArray(data), 'CLOUD_CORRUPT', '云端登录记录损坏，请重新登录。');
    const url = (() => { try { return normalizeServerUrl(data.url); } catch { return DEFAULT_SERVER; } })();
    const user = data.user && typeof data.user === 'object' && typeof data.user.username === 'string' && ROLES.includes(data.user.role)
      ? { id: String(data.user.id || data.user.username), username: data.user.username, role: data.user.role }
      : null;
    const token = user && typeof data.token === 'string' && data.token.length > 0 ? data.token : null;
    return {
      format: 1,
      url,
      username: typeof data.username === 'string' ? data.username : (user?.username || ''),
      token,
      user: token ? user : null,
      keychainHash: typeof data.keychainHash === 'string' ? data.keychainHash : null,
      assigned: data.assigned && typeof data.assigned === 'object' && !Array.isArray(data.assigned) ? data.assigned : {},
      users: Array.isArray(data.users) ? data.users : [],
      syncedSnapshots: data.syncedSnapshots && typeof data.syncedSnapshots === 'object' && !Array.isArray(data.syncedSnapshots) ? data.syncedSnapshots : {},
      stashedAccounts: Array.isArray(data.stashedAccounts) ? data.stashedAccounts : [],
      lastSync: typeof data.lastSync === 'string' ? data.lastSync : null,
      lastRevoked: data.lastRevoked && typeof data.lastRevoked === 'object' ? data.lastRevoked : null,
    };
  }
  saveState(next) {
    atomicJson(this.file(), { format: 1, ...next });
  }
  loggedIn() {
    const s = this.load();
    return Boolean(s.token && s.user && ROLES.includes(s.user.role));
  }
  isAdmin() {
    const s = this.load();
    return Boolean(s.token && s.user?.role === 'admin');
  }
  requireAuth() {
    requireThat(this.loggedIn(), 'AUTH_REQUIRED', '请先使用账号密码登录软件。');
  }
  requireAdmin() {
    this.requireAuth();
    requireThat(this.isAdmin(), 'ADMIN_REQUIRED', '此操作仅限管理员账号使用。');
  }
  view() {
    try {
      const s = this.load();
      return {
        loggedIn: Boolean(s.token && s.user),
        url: s.url,
        username: s.username,
        user: s.user,
        lastSync: s.lastSync,
        lastRevoked: s.user?.role === 'member' ? s.lastRevoked : null,
        assigned: s.user?.role === 'admin' ? s.assigned : {},
        users: s.user?.role === 'admin' ? s.users : [],
        syncedSnapshots: s.syncedSnapshots || {},
      };
    } catch (e) {
      return { loggedIn: false, url: DEFAULT_SERVER, username: '', user: null, error: e instanceof Problem ? e.code : 'CLOUD_UNREADABLE' };
    }
  }
  report() {
    try {
      const s = this.load();
      return { loggedIn: Boolean(s.token && s.user), role: s.user?.role || null };
    } catch {
      return { loggedIn: false, role: null, error: 'UNREADABLE' };
    }
  }
  async request(endpoint, body = {}, { url: customUrl, token: customToken } = {}) {
    const s = this.load();
    const base = customUrl ? normalizeServerUrl(customUrl) : s.url;
    const token = customToken !== undefined ? customToken : s.token;
    const headers = { 'Content-Type': 'application/json; charset=utf-8' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    let response;
    try {
      response = await this.fetcher(base + endpoint, {
        method: 'POST',
        headers,
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(30000),
      });
    } catch {
      throw new Problem('CLOUD_NETWORK', '无法连接云端服务器，请检查网络或服务地址后重试。');
    }
    if (response.status === 401) {
      if (s.token && !customToken) this.saveState({ ...s, token: null, user: null });
      throw new Problem('AUTH_EXPIRED', '登录已过期或账号密码错误，请重新登录。');
    }
    let data;
    try { data = await response.json(); } catch { throw new Problem('CLOUD_BAD_RESPONSE', `云端服务器返回格式错误（HTTP ${response.status}）。`); }
    if (!response.ok || data?.ok === false) {
      const code = typeof data?.code === 'string' && /^[A-Z0-9_]{2,40}$/.test(data.code) ? data.code : 'CLOUD_ERROR';
      const msg = typeof (data?.error || data?.message) === 'string' ? (data.error || data.message).slice(0, 300) : `云端请求失败（HTTP ${response.status}）。`;
      throw new Problem(code, msg);
    }
    return data;
  }
  async login({ url, username, password } = {}) {
    const cleanUrl = normalizeServerUrl(url);
    const cleanUser = typeof username === 'string' ? username.trim() : '';
    const cleanPass = typeof password === 'string' ? password : '';
    requireThat(cleanUser.length >= 1 && cleanUser.length <= 80 && !/[\x00-\x1f\x7f]/.test(cleanUser), 'BAD_CREDENTIALS', '请输入有效的登录账号。');
    requireThat(cleanPass.length >= 1 && cleanPass.length <= 200, 'BAD_CREDENTIALS', '请输入登录密码。');
    const data = await this.request('/login', { username: cleanUser, password: cleanPass }, { url: cleanUrl, token: null });
    requireThat(
      typeof data?.token === 'string' && data.token.length > 0 && data.user && typeof data.user.username === 'string' && ROLES.includes(data.user.role),
      'CLOUD_BAD_RESPONSE',
      '云端登录返回信息不完整。'
    );
    const prev = (() => { try { return this.load(); } catch { return {}; } })();
    this.swapAccountList(prev.username || prev.user?.username || '', data.user.username);
    this.saveState({
      url: cleanUrl,
      username: data.user.username,
      token: data.token,
      user: { id: String(data.user.id || data.user.username), username: data.user.username, role: data.user.role },
      keychainHash: prev.keychainHash || null,
      assigned: prev.assigned || {},
      syncedSnapshots: prev.syncedSnapshots || {},
      stashedAccounts: prev.stashedAccounts || [],
      lastSync: prev.lastSync || null,
    });
    this._streamAbort?.abort();
    try {
      const synced = await this.pull();
      return { message: `登录成功（${data.user.role === 'admin' ? '管理员' : '成员'}：${data.user.username}）。${synced.message}` };
    } catch (e) {
      if (data.user.role === 'admin') {
        return { message: `管理员“${data.user.username}”已登录。云端暂未拉取到快照（${e.message}），可直接添加账号并上传。` };
      }
      throw e;
    }
  }
  // Each login name keeps its own account list on this Mac. Logging in as someone else parks the
  // current list under the previous name and brings back the new name's list, so testing a member
  // login on the admin's Mac never loses the admin's accounts. Snapshots themselves are shared and immutable.
  userListFile(username) { return this.core.p('accounts-user-' + sha256(String(username).toLowerCase()).slice(0, 24) + '.json'); }
  swapAccountList(fromUser, toUser) {
    if (!fromUser || !toUser || String(fromUser).toLowerCase() === String(toUser).toLowerCase()) return;
    const current = this.core.p('accounts.json');
    if (exists(current)) fs.copyFileSync(current, this.userListFile(fromUser));
    const saved = this.userListFile(toUser);
    if (exists(saved)) {
      let data;
      try { data = readJson(saved); } catch { data = null; }
      if (data?.format === 1 && Array.isArray(data.accounts)) { atomicJson(current, data); return; }
    }
    atomicJson(current, { format: 1, accounts: [] });
  }
  async logout() {
    return this.core.exclusive(() => {
      const s = (() => { try { return this.load(); } catch { return { url: DEFAULT_SERVER, username: '' }; } })();
      this.saveState({ ...s, token: null, user: null });
      this._streamAbort?.abort();
      return { message: '已退出登录。' };
    });
  }
  knownSnapshots(localKeychainSecret = null) {
    const valid = [];
    let list = [];
    try { list = this.core.accounts(); } catch {}
    for (const a of list) {
      if (!isUuid(a?.snapshot)) continue;
      try {
        const snap = this.core.snapshot(a.snapshot);
        if (localKeychainSecret && !canDecryptSnapshot(snap.payload, a.uuid, localKeychainSecret)) continue;
        valid.push(a.snapshot.toLowerCase());
      } catch {}
    }
    return [...new Set(valid)];
  }
  discoverLocalAccounts(currentAccounts = []) {
    return Array.isArray(currentAccounts) ? [...currentAccounts] : [];
  }
  currentActiveIdentity(preferredId = null) {
    let activeAccountId = isUuid(preferredId) ? preferredId.toLowerCase() : null;
    let activeUuid = null;
    try {
      const live = inspect(this.core.root);
      if (isUuid(live?.uuid)) activeUuid = live.uuid.toLowerCase();
    } catch {}
    try {
      const list = this.core.accounts();
      if (activeAccountId) {
        const byId = list.find(a => a.id === activeAccountId);
        if (byId && isUuid(byId.uuid)) activeUuid = byId.uuid.toLowerCase();
      } else if (activeUuid) {
        const byUuid = list.find(a => a.uuid === activeUuid);
        if (byUuid && isUuid(byUuid.id)) activeAccountId = byUuid.id.toLowerCase();
      }
    } catch {}
    return { activeAccountId, activeUuid };
  }
  async syncActiveAccount(accountId = null) {
    if (!this.loggedIn()) return null;
    const { activeAccountId, activeUuid } = this.currentActiveIdentity(accountId);
    if (!activeAccountId && !activeUuid) return null;
    this._lastReportedActiveUuid = activeUuid || '';
    return this.request('/active-sync', { accountId: activeAccountId, accountUuid: activeUuid }).catch(() => null);
  }
  maybeSyncActiveAccount(liveUuid) {
    if (!this.loggedIn()) return;
    const clean = isUuid(liveUuid) ? liveUuid.toLowerCase() : '';
    if (clean === this._lastReportedActiveUuid) return;
    this._lastReportedActiveUuid = clean;
    if (clean) this.syncActiveAccount().catch(() => {});
  }
  async pull() {
    this.requireAuth();
    return this.core.exclusive(async () => {
      this.core.requireReady();
      const s = this.load();
      let localKeychainSecret = null;
      try { localKeychainSecret = await this.getKeychain(); } catch {}

      const data = await this.request('/pull', { knownSnapshots: [], ...this.currentActiveIdentity() });
      requireThat(Array.isArray(data?.accounts), 'CLOUD_BAD_RESPONSE', '云端返回的账号列表格式错误。');

      let keychainHash = s.keychainHash;
      // When this Mac already has its own Claude Safe Storage key in Keychain, never overwrite it:
      // snapshots are re-sealed with this Mac's key (阿常 migration.mjs pattern). Only fall back to
      // writeKeychain if this Mac has no readable key yet (or in legacy mock environments).
      if (!localKeychainSecret && typeof data.keychainSecret === 'string' && data.keychainSecret.length > 0) {
        const nextHash = sha256(data.keychainSecret);
        if (nextHash !== keychainHash) {
          await this.writeKeychain(data.keychainSecret);
          keychainHash = nextHash;
        }
      }

      const remoteAccounts = [];
      const assigned = {};
      const syncedSnapshots = { ...s.syncedSnapshots };
      const seenIds = new Set(), seenUuids = new Set();

      const localAccounts = this.discoverLocalAccounts(this.core.accounts(), s.syncedSnapshots, s.user?.username || s.username);
      const myUserId = String(s.user?.id ?? '');
      for (const raw of data.accounts) {
        const account = cleanAccountMeta(raw);
        requireThat(!seenIds.has(account.id) && !seenUuids.has(account.uuid), 'BAD_CLOUD_DATA', '云端账号列表中存在重复的账号编号。');
        seenIds.add(account.id); seenUuids.add(account.uuid);
        const assignedIds = Array.isArray(raw.assignedUserIds)
          ? raw.assignedUserIds.filter(x => typeof x === 'string' || typeof x === 'number').map(String)
          : [];
        if (Array.isArray(raw.assignedUserIds)) {
          assigned[account.id] = assignedIds;
        }
        const isAssignedToMe = s.user.role !== 'admin' || !Array.isArray(raw.assignedUserIds) || assignedIds.includes(myUserId);
        const haveSnapshot = (() => { try { this.core.snapshot(account.snapshot); return true; } catch { return false; } })();
        if (typeof raw.bundle === 'string' && raw.bundle.length > 0) {
          const unpacked = unpackSnapshot(this.core, {
            snapshotId: account.snapshot,
            bundle: raw.bundle,
            sha256: raw.sha256,
            localKeychainSecret,
            remoteKeychainSecret: data.keychainSecret,
          });
          if (!account.organizationId && isUuid(unpacked?.organizationId)) {
            account.organizationId = unpacked.organizationId.toLowerCase();
          }
          if (unpacked?.accountMeta) {
            for (const k of META_KEYS) {
              if (!account[k] && unpacked.accountMeta[k]) account[k] = unpacked.accountMeta[k];
            }
          }
        } else if (isAssignedToMe) {
          requireThat(haveSnapshot, 'SNAPSHOT_MISSING', `账号“${account.label}”缺少快照数据，请重试同步。`);
          const orgId = reSealExistingSnapshot(this.core, account.snapshot, account.uuid, localKeychainSecret, data.keychainSecret);
          if (!account.organizationId && isUuid(orgId)) {
            account.organizationId = orgId.toLowerCase();
          }
          try {
            const cachedMeta = sanitizeMeta(readJson(this.core.p('snapshots', account.snapshot, '.account-meta.json')));
            for (const k of META_KEYS) {
              if (!account[k] && cachedMeta[k]) account[k] = cachedMeta[k];
            }
          } catch {}
        } else {
          // Admin account list item not assigned to this admin: do not download or retain snapshot on local disk.
          if (haveSnapshot && Boolean(s.syncedSnapshots?.[account.id])) {
            try { fs.rmSync(this.core.p('snapshots', account.snapshot), { recursive: true, force: true }); } catch {}
          }
        }
        const prevLocal = localAccounts.find(x => x.id === account.id || x.uuid === account.uuid);
        if (prevLocal) {
          for (const k of ['password', 'totpSecret', 'services']) {
            if (!account[k] && prevLocal[k]) account[k] = prevLocal[k];
          }
          if (prevLocal.note !== undefined) {
            account.note = prevLocal.note;
          }
        }
        remoteAccounts.push(account);
        syncedSnapshots[account.id] = account.snapshot;
        if (raw.usage && typeof raw.usage === 'object' && (raw.usage.five_hour || raw.usage.seven_day)) {
          try {
            const usageFile = this.core.p('usage.json');
            const uCache = exists(usageFile) ? readJson(usageFile) : {};
            const remoteChecked = Number(raw.usage.checkedAt) || 0;
            const localChecked = Number(uCache?.[account.id]?.checkedAt) || 0;
            if (remoteChecked >= localChecked) {
              uCache[account.id] = {
                status: 'API',
                source: 'api',
                checkedAt: remoteChecked || Math.floor(Date.now() / 1000),
                tier: raw.usage.tier || uCache?.[account.id]?.tier || null,
                five_hour: raw.usage.five_hour || null,
                seven_day: raw.usage.seven_day || null,
              };
              atomicJson(usageFile, uCache);
            }
          } catch {}
        }
        if (Array.isArray(raw.assignedUserIds)) {
          assigned[account.id] = raw.assignedUserIds.filter(x => typeof x === 'string' || typeof x === 'number').map(String);
        }
      }

      let finalAccounts;
      let stashedAccounts = Array.isArray(s.stashedAccounts) ? [...s.stashedAccounts] : [];
      let revokedAccounts = [];
      let revokedActive = null;
      let unuploadedCount = 0;
      if (s.user.role === 'admin') {
        // Admins keep any newly added local accounts (plus any stashed when testing a member login)
        // that have not been pushed to the cloud yet, and keep a newer local snapshot.
        const merged = [...remoteAccounts];
        for (const local of [...stashedAccounts, ...localAccounts]) {
          const idx = merged.findIndex(r => r.id === local.id || r.uuid === local.uuid);
          if (idx < 0) {
            if (s.syncedSnapshots?.[local.id]) {
              delete syncedSnapshots[local.id];
              continue;
            }
            merged.push(local);
            unuploadedCount++;
          } else if (local.saved > merged[idx].saved) {
            merged[idx] = { ...merged[idx], ...local };
          } else {
            merged[idx] = { ...local, ...merged[idx], ...(local.note !== undefined ? { note: local.note } : {}) };
          }
        }
        finalAccounts = merged;
        stashedAccounts = [];
      } else {
        // Detect accounts that were previously assigned/synced to this member and have now been revoked.
        revokedAccounts = localAccounts.filter(
          local => Boolean(s.syncedSnapshots?.[local.id]) && !remoteAccounts.some(r => r.id === local.id || r.uuid === local.uuid)
        );
        for (const rev of revokedAccounts) {
          delete syncedSnapshots[rev.id];
          stashedAccounts = stashedAccounts.filter(x => x.id !== rev.id && x.uuid !== rev.uuid);
        }
        // Keep any local un-uploaded snapshots on this member's Mac visible so they can upload them to the cloud.
        const merged = remoteAccounts.map(({ group, ...rest }) => {
          const prev = localAccounts.find(x => x.id === rest.id || x.uuid === rest.uuid);
          return prev?.group ? { ...rest, group: prev.group } : rest;
        });
        for (const local of [...stashedAccounts, ...localAccounts]) {
          if (revokedAccounts.some(r => r.id === local.id || r.uuid === local.uuid)) continue;
          if (s.syncedSnapshots?.[local.id]) continue;
          const idx = merged.findIndex(r => r.id === local.id || r.uuid === local.uuid);
          if (idx < 0) {
            merged.push(local);
            unuploadedCount++;
          }
        }
        finalAccounts = merged;
        stashedAccounts = [];

        if (revokedAccounts.length > 0) {
          const live = inspect(this.core.root);
          revokedActive = revokedAccounts.find(r => r.uuid === live.uuid) || null;
          if (revokedActive) {
            try { await this.core.platform?.notifyRevokedAccount?.(revokedActive.label); } catch {}
            try { await this.core.platform?.forceQuit?.(); } catch {}
            try { this.core.apply(null); } catch {}
          }
        }
      }

      atomicJson(this.core.p('accounts.json'), { format: 1, accounts: finalAccounts });
      let latestUsers = Array.isArray(s.users) ? s.users : [];
      if (s.user.role === 'admin') {
        try {
          const uData = await this.request('/users', {});
          if (Array.isArray(uData?.users)) {
            latestUsers = uData.users.filter(u => u && (typeof u.id === 'string' || typeof u.id === 'number') && typeof u.username === 'string').map(u => ({
              id: String(u.id),
              username: u.username,
              name: typeof u.name === 'string' ? u.name : '',
            }));
          }
        } catch {}
      }
      const lastRevoked = revokedAccounts.length > 0
        ? { labels: revokedAccounts.map(a => a.label), at: new Date().toISOString(), closedClaude: Boolean(revokedActive) }
        : (s.lastRevoked || null);
      this.saveState({
        ...s,
        keychainHash,
        assigned: s.user.role === 'admin' ? assigned : {},
        users: s.user.role === 'admin' ? latestUsers : [],
        syncedSnapshots,
        stashedAccounts,
        lastSync: new Date().toISOString(),
        lastRevoked,
      });
      if (revokedActive) {
        return { message: `管理员已收回账号“${revokedAccounts.map(a => a.label).join('、')}”，已关闭 Claude 并清除该账号的本地登录状态。`, revoked: lastRevoked };
      }
      if (revokedAccounts.length > 0) {
        return { message: `管理员已收回账号“${revokedAccounts.map(a => a.label).join('、')}”。当前可用 ${remoteAccounts.length} 个账号。`, revoked: lastRevoked };
      }
      if (s.user.role === 'admin') {
        const myAssignedCnt = remoteAccounts.filter(a => (assigned[a.id] || []).includes(myUserId)).length;
        const extraMsg = unuploadedCount > 0 ? `；本机有 ${unuploadedCount} 个未上传快照` : '';
        return { message: `已同步云端账号列表（共 ${remoteAccounts.length} 个，分配给我 ${myAssignedCnt} 个${extraMsg}）。` };
      }
      if (unuploadedCount > 0) {
        return { message: `已从云端同步 ${remoteAccounts.length} 个账号快照；读取到本机 ${unuploadedCount} 个未上传快照，可点「上传到云端」。` };
      }
      return { message: `已从云端同步 ${remoteAccounts.length} 个账号快照。` };
    });
  }
  async syncMemberIfChanged() {
    if (!this.loggedIn() || this.isAdmin() || this.core.busy) return null;
    const data = await this.request('/pull?omitBundle=1', { knownSnapshots: [] });
    if (!Array.isArray(data?.accounts)) return null;
    const s = this.load();
    const remoteIds = new Set(data.accounts.filter(a => isUuid(a?.id)).map(a => a.id.toLowerCase()));
    const localSyncedIds = this.core.accounts()
      .filter(a => Boolean(s.syncedSnapshots?.[a.id]))
      .map(a => a.id.toLowerCase());
    const changed = localSyncedIds.length !== remoteIds.size || localSyncedIds.some(id => !remoteIds.has(id));
    if (!changed) return null;
    return this.pull();
  }
  async handleRemoteCommand(cmd) {
    if (!cmd || typeof cmd !== 'object' || !this.loggedIn() || this.isAdmin()) return null;
    // Wait briefly if another operation is currently holding core.busy
    for (let i = 0; i < 15 && this.core.busy; i++) {
      await new Promise(r => setTimeout(r, 200));
    }
    if (this.core.busy) return null;
    const res = await this.pull().catch(() => null);
    if (cmd.type === 'revoke_account' && isUuid(cmd.accountUuid)) {
      const live = inspect(this.core.root);
      if (live.uuid && live.uuid.toLowerCase() === cmd.accountUuid.toLowerCase()) {
        await this.core.exclusive(async () => {
          const label = typeof cmd.label === 'string' && cmd.label ? cmd.label : '当前账号';
          try { await this.core.platform?.notifyRevokedAccount?.(label); } catch {}
          try { await this.core.platform?.forceQuit?.(); } catch {}
          try { this.core.apply(null); } catch {}
          const s = this.load();
          this.saveState({
            ...s,
            lastRevoked: { labels: [label], at: new Date().toISOString(), closedClaude: true },
          });
        }).catch(() => {});
      }
    }
    return res;
  }
  startCommandStream() {
    if (this._streamRunning) return;
    this._streamRunning = true;
    const sleep = ms => new Promise(r => { const t = setTimeout(r, ms); t.unref?.(); });
    (async () => {
      while (this._streamRunning) {
        let s;
        try { s = this.load(); } catch { s = null; }
        if (!s?.token || !s?.user || s.user.role === 'admin') {
          await sleep(3000);
          continue;
        }
        const ac = new AbortController();
        this._streamAbort = ac;
        try {
          const res = await this.fetcher(s.url + '/events', {
            method: 'GET',
            headers: { Authorization: `Bearer ${s.token}`, Accept: 'text/event-stream' },
            signal: ac.signal,
          });
          if (!res.ok || !res.body) {
            await sleep(8000);
            continue;
          }
          this._streamConnected = true;
          const decoder = new TextDecoder();
          let buf = '';
          for await (const chunk of res.body) {
            buf += decoder.decode(chunk, { stream: true });
            let boundary;
            while ((boundary = buf.indexOf('\n\n')) >= 0) {
              const frame = buf.slice(0, boundary);
              buf = buf.slice(boundary + 2);
              let eventName = 'message', dataLine = '';
              for (const line of frame.split('\n')) {
                if (line.startsWith('event:')) eventName = line.slice(6).trim();
                else if (line.startsWith('data:')) dataLine += line.slice(5).trim();
              }
              if (eventName === 'connected') {
                await this.syncMemberIfChanged().catch(() => {});
              } else if (eventName === 'command' && dataLine) {
                try {
                  const cmd = JSON.parse(dataLine);
                  await this.handleRemoteCommand(cmd);
                } catch {}
              }
            }
          }
        } catch {
          // Reconnect after transient disconnect
        } finally {
          this._streamConnected = false;
          if (this._streamAbort === ac) this._streamAbort = null;
        }
        await sleep(5000);
      }
    })();
  }
  async push({ id = null } = {}) {
    this.requireAuth();
    return this.core.exclusive(async () => {
      this.core.requireReady();
      const list = (id ? [this.core.getAccount(id)] : this.core.accounts()).filter(
        a => exists(this.core.p('snapshots', a.snapshot, 'manifest.json'))
      );
      requireThat(list.length > 0, 'NO_ACCOUNTS', '本机还没有已保存的本地账号快照可上传。');
      let keychainSecret = '';
      try {
        keychainSecret = await this.getKeychain();
      } catch (e) {
        const needsKeychain = list.some(a => {
          try { return hasV10Cookies(this.core.snapshot(a.snapshot).payload); } catch { return false; }
        });
        if (needsKeychain || this.isAdmin()) throw e;
      }
      let candidateSecrets = keychainSecret ? [keychainSecret] : [];
      if (this.readKeychain === readMacKeychain && process.platform === 'darwin') {
        try { candidateSecrets = await readMacKeychainAll(); } catch {}
      }
      let chromeAccounts = {};
      try {
        const chromeData = readJson(safePath(this.store, 'chrome-profiles.json'));
        if (chromeData?.accounts && typeof chromeData.accounts === 'object') chromeAccounts = chromeData.accounts;
      } catch {}
      let usageCache = {};
      try {
        const uData = readJson(this.core.p('usage.json'));
        if (uData && typeof uData === 'object' && !Array.isArray(uData)) usageCache = uData;
      } catch {}
      const sBefore = this.load();
      const accounts = list.map(a => {
        const alreadySynced = Boolean(sBefore.syncedSnapshots?.[a.id]);
        const extra = Object.fromEntries(DETAILS.filter(k => a[k] !== undefined).map(k => [k, a[k]]));
        const ca = chromeAccounts[a.id] || {};
        if (!extra.email && typeof ca.profileEmail === 'string' && ca.profileEmail.trim()) extra.email = ca.profileEmail.trim();
        if (!extra.note && typeof ca.note === 'string' && ca.note.trim()) extra.note = ca.note.trim().normalize('NFC');
        if (alreadySynced) delete extra.note;
        if (!extra.services && Array.isArray(ca.steps) && ca.steps[9] && ca.steps[9] !== 'unusable') {
          extra.services = 'Claude, Antigravity';
        }
        const { bundle, sha256: hash, organizationId } = packSnapshot(this.core, a.snapshot, {
          keychainSecret: candidateSecrets.length ? candidateSecrets : null,
          uuid: a.uuid,
          accountMeta: extra,
        });
        if (!extra.organizationId && isUuid(organizationId)) extra.organizationId = organizationId.toLowerCase();
        const uEntry = usageCache[a.id];
        const usagePayload = uEntry && (uEntry.five_hour || uEntry.seven_day) ? {
          id: a.id,
          uuid: a.uuid,
          tier: uEntry.tier || null,
          checkedAt: uEntry.checkedAt || Math.floor(Date.now() / 1000),
          five_hour: uEntry.five_hour ? { utilization: uEntry.five_hour.utilization ?? null, resetsAt: uEntry.five_hour.resetsAt ?? null } : null,
          seven_day: uEntry.seven_day ? { utilization: uEntry.seven_day.utilization ?? null, resetsAt: uEntry.seven_day.resetsAt ?? null } : null,
        } : undefined;
        return {
          id: a.id,
          uuid: a.uuid,
          label: a.label,
          snapshot: a.snapshot,
          saved: a.saved,
          ...extra,
          sha256: hash,
          bundle,
          ...(usagePayload ? { usage: usagePayload } : {}),
        };
      });
      const data = await this.request('/push', { keychainSecret, accounts });
      const s = this.load();
      const syncedSnapshots = { ...s.syncedSnapshots };
      const serverAssigned = new Map();
      if (Array.isArray(data?.accounts)) {
        for (const item of data.accounts) {
          if (isUuid(item?.uuid) && typeof item?.label === 'string' && item.label.trim()) {
            serverAssigned.set(item.uuid.toLowerCase(), {
              id: isUuid(item.id) ? item.id.toLowerCase() : null,
              label: item.label.trim(),
            });
          }
        }
      }
      if (serverAssigned.size > 0) {
        const currentAll = this.core.accounts();
        const usedLabels = new Set(currentAll.map(x => x.label.toLowerCase()));
        const updatedAll = currentAll.map(acc => {
          const assigned = serverAssigned.get(acc.uuid.toLowerCase());
          if (!assigned) return acc;
          usedLabels.delete(acc.label.toLowerCase());
          let nextLabel = assigned.label;
          if (usedLabels.has(nextLabel.toLowerCase())) nextLabel = acc.label;
          usedLabels.add(nextLabel.toLowerCase());
          const nextId = assigned.id && !currentAll.some(x => x.id === assigned.id && x.uuid !== acc.uuid) ? assigned.id : acc.id;
          if (nextId !== acc.id) delete syncedSnapshots[acc.id];
          syncedSnapshots[nextId] = acc.snapshot;
          return { ...acc, id: nextId, label: nextLabel };
        });
        atomicJson(this.core.p('accounts.json'), { format: 1, accounts: updatedAll });
      } else {
        for (const a of list) syncedSnapshots[a.id] = a.snapshot;
      }
      this.saveState({
        ...s,
        keychainHash: keychainSecret ? sha256(keychainSecret) : s.keychainHash,
        syncedSnapshots,
        lastSync: new Date().toISOString(),
      });
      return { message: typeof data?.message === 'string' && data.message ? data.message : `已将 ${list.length} 个账号快照上传到云端。` };
    });
  }
  async syncUsage(usageViews = null) {
    if (!this.loggedIn()) return null;
    let accounts = [];
    try { accounts = this.core.accounts(); } catch { return null; }
    if (!accounts.length) return null;
    let byId = new Map();
    if (Array.isArray(usageViews)) {
      for (const v of usageViews) {
        if (v?.id && (v.five_hour || v.seven_day)) byId.set(v.id, v);
      }
    } else {
      try {
        const uCache = readJson(this.core.p('usage.json'));
        if (uCache && typeof uCache === 'object') {
          for (const [k, v] of Object.entries(uCache)) {
            if (v && (v.five_hour || v.seven_day)) byId.set(k, v);
          }
        }
      } catch {}
    }
    const usages = [];
    for (const a of accounts) {
      const u = byId.get(a.id);
      if (!u || (!u.five_hour && !u.seven_day)) continue;
      usages.push({
        id: a.id,
        uuid: a.uuid,
        tier: u.tier || null,
        checkedAt: u.checkedAt || Math.floor(Date.now() / 1000),
        five_hour: u.five_hour ? { utilization: u.five_hour.utilization ?? null, resetsAt: u.five_hour.resetsAt ?? null } : null,
        seven_day: u.seven_day ? { utilization: u.seven_day.utilization ?? null, resetsAt: u.seven_day.resetsAt ?? null } : null,
      });
    }
    if (!usages.length) return null;
    return this.request('/usage-sync', { usages, ...this.currentActiveIdentity() }).catch(() => null);
  }
  async users() {
    this.requireAdmin();
    const data = await this.request('/users', {});
    requireThat(Array.isArray(data?.users), 'CLOUD_BAD_RESPONSE', '云端返回的用户列表格式错误。');
    const users = data.users.filter(u => u && (typeof u.id === 'string' || typeof u.id === 'number') && typeof u.username === 'string').map(u => ({
      id: String(u.id),
      username: u.username,
      name: typeof u.name === 'string' ? u.name : '',
      accountIds: Array.isArray(u.accountIds) ? u.accountIds.map(String) : [],
    }));
    const s = this.load();
    this.saveState({
      ...s,
      users: users.map(({ id, username, name }) => ({ id, username, name })),
    });
    return { users };
  }
  async assign({ accountId, userIds } = {}) {
    this.requireAdmin();
    const account = this.core.getAccount(accountId);
    requireThat(Array.isArray(userIds) && userIds.every(u => typeof u === 'string' && u.trim().length > 0), 'BAD_USERS', '选择的用户列表格式无效。');
    const cleanIds = [...new Set(userIds.map(u => u.trim()))];
    requireThat(cleanIds.length <= 1, 'SINGLE_ASSIGNEE_ONLY', '一个账号只能分配给一个人。');
    const s = this.load();
    const prevIds = Array.isArray(s.assigned?.[account.id]) ? s.assigned[account.id] : [];
    if (cleanIds.length === 1 && prevIds.length > 0 && !prevIds.includes(cleanIds[0])) {
      throw new Problem('ALREADY_ASSIGNED', `账号“${account.label}”已分配给其他成员，请先收回账号后再分配。`);
    }
    const data = await this.request('/assign', { accountId: account.id, userIds: cleanIds });
    this.saveState({
      ...s,
      assigned: { ...s.assigned, [account.id]: cleanIds },
    });
    return {
      message: typeof data?.message === 'string' && data.message
        ? data.message
        : (cleanIds.length ? `已将“${account.label}”分配给指定成员。` : `已收回“${account.label}”，现为空闲未分配状态。`),
    };
  }
}
