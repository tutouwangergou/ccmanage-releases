export const VERSION = '2.0.1-mac-20261028';
// Runtimes bundled with this version. An update that needs different ones downloads the complete package.
export const RUNTIME = { node: '22.23.3', electron: '44.4.5' };
