import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { Switcher, Problem, requireThat, atomicJson, readJson, mkdir, safePath, exists, inspect, VERSION } from './core.mjs';
import { MacPlatform } from './platform.mjs';
import { sessionReport } from './sessions.mjs';
import { Usage } from './usage.mjs';
import { Carry } from './carry.mjs';
import { LoginCheck } from './login-check.mjs';
import { ChromeProfiles } from './chrome.mjs';
import { LaunchGuard } from './launch-guard.mjs';
import { Cloud } from './cloud.mjs';

const here = path.dirname(fileURLToPath(import.meta.url));
export const PORT = 48763;
export function createApi({ core, platform, token, projects, automation = {}, onQuit = () => {}, onChoose = () => {} }) {
  const server = http.createServer(async (req,res) => {
    const origin = 'http://127.0.0.1:' + server.address().port;
    const headers = { 'Cache-Control':'no-store', 'Referrer-Policy':'no-referrer', 'X-Content-Type-Options':'nosniff', 'X-Frame-Options':'DENY', 'Content-Security-Policy': "default-src 'self'; connect-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'; form-action 'none'" };
    const send = (code, body, type = 'application/json; charset=utf-8') => { res.writeHead(code, {...headers,'Content-Type':type}); res.end(type.startsWith('application/json') ? JSON.stringify(body) : body); };
    if (req.headers.host !== new URL(origin).host) return send(403,{ error:'请求来源不匹配。' });
    if (req.method === 'GET' && ['/', '/ui.js', '/ui.css'].includes(req.url)) {
      const entry = { '/':['index.html','text/html; charset=utf-8'], '/ui.js':['ui.js','text/javascript; charset=utf-8'], '/ui.css':['ui.css','text/css; charset=utf-8'] }[req.url];
      return send(200,fs.readFileSync(path.join(here,'web',entry[0])),entry[1]);
    }
    if (req.method !== 'POST' || req.url !== '/api') return send(404,{error:'页面不存在。'});
    const supplied = req.headers['x-switcher-token'];
    if (typeof supplied !== 'string' || Buffer.byteLength(supplied) !== Buffer.byteLength(token) || !crypto.timingSafeEqual(Buffer.from(supplied),Buffer.from(token)) || req.headers.origin !== origin || !/^application\/json(?:;|$)/.test(req.headers['content-type'] || '')) return send(403,{error:'此窗口已失效，请重新打开应用。',code:'UNAUTHORIZED'});
    try {
      let text = ''; for await (const part of req) { text += part; requireThat(Buffer.byteLength(text) <= 65536, 'REQUEST_LARGE','选择的数据过多。'); }
      let body; try { body = JSON.parse(text); } catch { throw new Problem('BAD_JSON','请求格式错误。'); }
      requireThat(body && typeof body.action === 'string' && (!body.args || (typeof body.args === 'object' && !Array.isArray(body.args))), 'BAD_REQUEST','请求格式错误。');
      const args = body.args || {};
      let result;
      switch (body.action) {
        case 'ping': result = { version: VERSION }; break;
        case 'status': {
          const cloudView = automation.cloud ? automation.cloud.view() : null;
          if (cloudView && !cloudView.loggedIn) {
            result = { version: VERSION, live: { compatible: false, cookie: 'missing', layout: null, uuid: null, reasons: [] }, accounts: [], pending: null, recovery: false, busy: false, platform: platform.info(), cloud: cloudView };
            try { result.claudeRunning = (await platform.running()).length > 0; } catch { result.claudeRunning = null; }
            if (automation.guard) result.launchGuard = await automation.guard.view();
            break;
          }
          result = core.status(); result.platform = platform.info();
          if (cloudView?.loggedIn && cloudView.user?.role === 'admin') {
            const myId = String(cloudView.user.id || '');
            for (const a of result.accounts) {
              const isSynced = cloudView.syncedSnapshots?.[a.id] === a.snapshot;
              const isAssignedToMe = (cloudView.assigned?.[a.id] || []).map(String).includes(myId);
              const hasLocalSnap = exists(core.p('snapshots', a.snapshot, 'manifest.json'));
              if (isSynced && !hasLocalSnap) {
                if (a.state === 'damaged') a.state = 'present';
                if (!isAssignedToMe) a.cloudOnly = true;
              }
            }
          }
          automation.cloud?.maybeSyncActiveAccount?.(result.live?.uuid);
          // Lets the window warn before a switch quits a running Claude; null when it cannot be checked.
          try { result.claudeRunning = (await platform.running()).length > 0; } catch { result.claudeRunning = null; }
          if(automation.usage)result.usage=automation.usage.views(core.accounts());
          if(automation.loginCheck)result.loginCheck=automation.loginCheck.view();
          if(automation.guard)result.launchGuard=await automation.guard.view();
          if(cloudView)result.cloud=cloudView;
          // A damaged profile record must not hide the account list.
          if(automation.chrome){try{result.chrome=automation.chrome.view();}catch(e){result.chrome={error:e instanceof Problem?e.code:'PROFILES_UNREADABLE'};}}
          break;
        }
        case 'report': result = { ...core.report(), platformInfo: platform.info(),carry:automation.carry?.view(),sessions:sessionReport(core,projects),...(automation.cloud?{cloud:automation.cloud.report()}:{}) }; break;
        case 'cloud-login': requireThat(automation.cloud,'UNKNOWN_ACTION','不支持此操作。'); result = await automation.cloud.login(args); if (typeof automation.usage?.refresh === 'function') automation.usage.refresh().catch(() => {}); break;
        case 'cloud-register': requireThat(automation.cloud,'UNKNOWN_ACTION','不支持此操作。'); result = await automation.cloud.register(args); if (typeof automation.usage?.refresh === 'function') automation.usage.refresh().catch(() => {}); break;
        case 'cloud-logout': requireThat(automation.cloud,'UNKNOWN_ACTION','不支持此操作。'); result = await automation.cloud.logout(); break;
        case 'cloud-pull': requireThat(automation.cloud,'UNKNOWN_ACTION','不支持此操作。'); result = await automation.cloud.pull(); if (typeof automation.usage?.refresh === 'function') automation.usage.refresh().catch(() => {}); break;
        case 'cloud-push': requireThat(automation.cloud,'UNKNOWN_ACTION','不支持此操作。'); automation.cloud.requireAuth(); result = await automation.cloud.push(args); if (typeof automation.usage?.refresh === 'function') automation.usage.refresh(args?.id ? { id: args.id } : {}).catch(() => {}); break;
        case 'cloud-users': requireThat(automation.cloud,'UNKNOWN_ACTION','不支持此操作。'); result = await automation.cloud.users(); break;
        case 'cloud-assign': requireThat(automation.cloud,'UNKNOWN_ACTION','不支持此操作。'); result = await automation.cloud.assign(args); break;
        case 'save': automation.cloud?.requireAuth(); result = await core.save(args); automation.loginCheck?.clearAccount(result.account); automation.cloud?.syncActiveAccount?.(result.account)?.catch?.(() => {}); if (typeof automation.usage?.refresh === 'function') automation.usage.refresh({ id: result.account }).catch(() => {}); break;
        case 'rename': automation.cloud?.requireAuth(); result = await core.rename(args); break;
        case 'edit': automation.cloud?.requireAuth(); result = await core.edit(args); break;
        case 'group': automation.cloud?.requireAuth(); result = await core.setGroup(args); break;
        case 'profile-edit': automation.cloud?.requireAdmin(); requireThat(automation.chrome,'UNKNOWN_ACTION','不支持此操作。'); result = await automation.chrome.edit(args); break;
        case 'profile-pages': automation.cloud?.requireAdmin(); requireThat(automation.chrome,'UNKNOWN_ACTION','不支持此操作。'); result = await automation.chrome.savePages(args); break;
        case 'profile-create': automation.cloud?.requireAdmin(); requireThat(automation.chrome,'UNKNOWN_ACTION','不支持此操作。'); result = await automation.chrome.create(args); break;
        case 'profile-open': automation.cloud?.requireAdmin(); requireThat(automation.chrome,'UNKNOWN_ACTION','不支持此操作。'); result = await automation.chrome.open(args); break;
        case 'profile-steps': automation.cloud?.requireAdmin(); requireThat(automation.chrome,'UNKNOWN_ACTION','不支持此操作。'); result = await automation.chrome.steps(args); break;
        case 'profile-antigravity': automation.cloud?.requireAdmin(); requireThat(automation.chrome,'UNKNOWN_ACTION','不支持此操作。'); result = await automation.chrome.antigravity(args); break;
        case 'profile-rename': automation.cloud?.requireAdmin(); requireThat(automation.chrome,'UNKNOWN_ACTION','不支持此操作。'); result = await automation.chrome.rename(args); break;
        case 'usage-refresh': {
          requireThat(typeof automation.usage?.refresh === 'function','UNKNOWN_ACTION','不支持此操作。');
          if (automation.cloud?.loggedIn()) { try { await automation.cloud.pull(); } catch {} }
          result = await automation.usage.refresh(args);
          break;
        }
        case 'switch': {
          automation.cloud?.requireAuth();
          if (typeof core.getAccount === 'function' && typeof core.p === 'function') {
            const targetAcc = core.getAccount(args.id);
            if (targetAcc?.snapshot) {
              requireThat(
                exists(core.p('snapshots', targetAcc.snapshot, 'manifest.json')),
                'SNAPSHOT_NOT_DOWNLOADED',
                `“${targetAcc.label}”仅在云端账号列表中，未下载快照到本机。如需在本机切换使用，请先在「账号管理」中将该账号分配给自己。`
              );
            }
          }
          await automation.guard?.check({before:true});
          const switchArgs = automation.cloud && !automation.cloud.isAdmin() ? { ...args, allowUnsaved: true } : args;
          result = automation.carry?await automation.carry.switchAccount(switchArgs):await core.switchAccount(switchArgs);
          automation.loginCheck?.schedule(args.id);
          automation.cloud?.syncActiveAccount?.(args.id)?.catch?.(() => {});
          if (typeof automation.usage?.refresh === 'function') automation.usage.refresh({ id: args.id }).catch(() => {});
          break;
        }
        case 'prepare': automation.cloud?.requireAdmin(); await automation.guard?.check({before:true}); result = await core.prepare(args); break;
        case 'cancel': automation.cloud?.requireAdmin(); await automation.guard?.check({before:true}); result = await core.cancel(); break;
        case 'recover': automation.cloud?.requireAuth(); result = await core.recover(); break;
        case 'rebuild': automation.cloud?.requireAuth(); result = await core.rebuildIndex(); break;
        case 'launch': automation.cloud?.requireAuth(); result = await core.exclusive(async () => { requireThat(!core.recovery(), 'RECOVERY_REQUIRED','请先恢复中断的操作，再打开 Claude。'); await platform.launch(); return {message:'已打开 Claude。'}; }); break;
        case 'stop-claude': automation.cloud?.requireAuth(); result = await core.exclusive(async () => { requireThat(!core.recovery(), 'RECOVERY_REQUIRED','请先恢复中断的操作，再关闭 Claude。'); return platform.forceQuit(); }); break;
        case 'launch-guard': requireThat(automation.guard,'UNKNOWN_ACTION','不支持此操作。'); result = automation.guard.save(args); break;
        case 'choose': automation.cloud?.requireAdmin(); result = await onChoose(); break;
        case 'quit': requireThat(!core.busy,'BUSY','请等待当前操作结束。'); automation.loginCheck?.stop(); automation.usage?.stopAutoRefresh?.(); result = {message:'工具已退出。'}; setTimeout(onQuit,200); break;
        default: throw new Problem('UNKNOWN_ACTION','不支持此操作。');
      }
      send(200,{ok:true,result});
    } catch (e) {
      // Never return stack traces, filesystem paths or arbitrary third-party errors.
      send(400,{ok:false,code:e instanceof Problem ? e.code : 'OPERATION_FAILED',error:e instanceof Problem ? e.message : '操作未完成，原账号快照仍保留。请打开“检查修复”；如显示操作中断，先恢复备份。'});
    }
  });
  server.requestTimeout = 30000; server.headersTimeout = 10000;
  return server;
}

async function main() {
  requireThat(process.platform === 'darwin', 'MAC_ONLY', '请在 Mac 上打开此程序。');
  process.umask(0o077);
  const home = os.homedir(), store = path.join(home,'Library','Application Support','Claude Switcher');
  mkdir(store); fs.chmodSync(store,0o700);
  const runtime = safePath(store,'runtime.json'), guard = new LaunchGuard({store}), platform = new MacPlatform({guard}), token = crypto.randomBytes(32).toString('hex');
  const settingsFile = safePath(store,'settings.json'), support = path.join(home,'Library','Application Support');
  let root = path.join(support,'Claude');
  if (exists(settingsFile)) {
    const candidate = safePath(support,readJson(settingsFile).root);
    requireThat(path.basename(candidate).toLowerCase() === 'claude','UNSAFE_PATH','保存的数据目录无效，请导出诊断信息。'); root = candidate;
  }
  // Bind before any core initialization, so two instances cannot modify the store concurrently.
  const proxy = {}, automation = {}, background=process.argv.includes('--background');
  const server = createApi({ core: proxy, platform, token, projects: path.join(home,'.claude','projects'),
    automation,
    onQuit: () => { try { fs.unlinkSync(runtime); } catch {} server.close(); setTimeout(() => process.exit(0),300).unref(); },
    onChoose: async () => proxy.exclusive(async () => {
      proxy.requireReady();
      requireThat(proxy.accounts().length === 0,'PATH_IN_USE','已有账号保存，不能更换数据目录。请先导出诊断报告。');
      const selected = platform.chooseDataFolder();
      requireThat(inspect(selected).compatible,'UNSUPPORTED_LAYOUT','所选目录不含支持的 Claude 数据格式，原设置保留。');
      atomicJson(settingsFile,{root:selected}); proxy.root = selected;
      return {message:'已更新数据目录。'};
    }) });
  try {
    await new Promise((resolve,reject) => { server.once('error',reject); server.listen(PORT,'127.0.0.1',resolve); });
  } catch (e) {
    if (e.code !== 'EADDRINUSE') throw e;
    let previous;
    try {
      previous = readJson(runtime);
      requireThat(/^[a-f0-9]{64}$/.test(previous.token),'BUSY','工具端口已被占用。');
      const response = await fetch(`http://127.0.0.1:${PORT}/api`, { method:'POST',headers:{'Origin':`http://127.0.0.1:${PORT}`,'Content-Type':'application/json','X-Switcher-Token':previous.token}, body:JSON.stringify({action:'ping'}),signal:AbortSignal.timeout(2500) });
      const data = await response.json(); requireThat(response.ok && data.result?.version,'BUSY','工具端口被其他程序占用。');
    } catch { throw new Problem('PORT_BUSY','工具端口已被占用。请关闭先前的切换器，或重新启动 Mac 后重试。'); }
    return;
  }
  const core = new Switcher({store,root,platform});
  Object.setPrototypeOf(proxy, Object.getPrototypeOf(core)); Object.assign(proxy,core);
  automation.usage=new Usage({core:proxy, onUpdate: views => automation.cloud?.syncUsage(views)});
  automation.carry=new Carry({core:proxy,projects:path.join(home,'.claude','projects')});
  automation.loginCheck=new LoginCheck({core:proxy});
  automation.chrome=new ChromeProfiles({store,core:proxy});
  automation.guard=guard;
  automation.cloud=new Cloud({store,core:proxy});
  automation.cloud.startCommandStream();
  atomicJson(runtime,{token,pid:process.pid,version:VERSION});
  automation.usage.startAutoRefresh();
  setInterval(() => {
    if (!proxy.busy && automation.cloud?.loggedIn() && !automation.cloud?.isAdmin() && !automation.cloud?._streamConnected) {
      automation.cloud.syncMemberIfChanged().catch(() => {});
    }
  }, 60000).unref();
  // Desktop windows share this backend; it never opens a browser.
  for (const signal of ['SIGTERM','SIGINT']) process.on(signal,() => { try { fs.unlinkSync(runtime); } catch {} process.exit(0); });
}
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) main().catch(e => {
  console.error(e instanceof Problem ? `${e.code}: ${e.message}` : 'START_FAILED: 工具启动失败。请使用安装包中的“诊断与修复.command”重新打开。'); process.exit(1);
});
