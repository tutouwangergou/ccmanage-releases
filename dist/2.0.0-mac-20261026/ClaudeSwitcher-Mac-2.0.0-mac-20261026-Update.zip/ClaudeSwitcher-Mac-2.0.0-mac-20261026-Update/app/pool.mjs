import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { safePath, exists, readJson, atomicJson, requireThat, mkdir } from './core.mjs';
import { dirs, transcripts, uuidScan, targetOrg, placeIndex } from './sessions.mjs';

// Session pool shared by every saved account.
// Claude only writes the signed-in account's folder, so comparing each account's index files with the
// hashes recorded for it after the last sync (its base) shows what that account created, changed or
// deleted. pool.json keeps the agreed version of each session (content hash) or a deletion marker, plus
// every account's base. Nothing is stored twice: copies come from whichever account folder holds the
// agreed version. Replaced and deleted entries are moved to pool-backups, never erased.
const NAME = /^local_(?:local_)?[a-zA-Z0-9-]+\.json$/;
const LIMIT = 5000;
const newer = (x, y) => x.at > y.at || (x.at === y.at && x.turns > y.turns);
const version = v => ({ hash: v.hash, at: v.at, turns: v.turns });
const hashOf = file => crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');

function load(core) {
  try {
    const m = readJson(core.p('pool.json'));
    if (m?.format === 1 && m.sessions && typeof m.sessions === 'object' && m.accounts && typeof m.accounts === 'object') return m;
  } catch {}
  // Missing or unreadable state behaves like a first sync: everything merges, nothing is deleted.
  return { format: 1, sessions: {}, accounts: {} };
}

// What one account folder holds now. `names` covers every index file, parseable or not, so an
// unreadable file is never mistaken for a deletion; `incomplete` disables deletion detection.
function holdings(core, account, tx) {
  const root = safePath(core.root, 'claude-code-sessions', account.uuid);
  const held = { account, files: new Map(), names: new Set(), incomplete: !exists(root) };
  for (const org of dirs(root)) {
    try { for (const name of fs.readdirSync(safePath(root, org))) if (NAME.test(name)) held.names.add(name); }
    catch { held.incomplete = true; }
  }
  for (const row of uuidScan(core, account.uuid, tx).rows) {
    const name = path.basename(row.key);
    try {
      const v = { ...row, uuid: account.uuid, hash: hashOf(safePath(root, row.key)) }, other = held.files.get(name);
      if (!other || newer(v, other)) held.files.set(name, v);
    } catch { held.incomplete = true; }
  }
  return held;
}
const hashes = held => Object.fromEntries([...held.files].map(([name, v]) => [name, v.hash]));

function collect(m, held, now) {
  const base = m.accounts[held.account.uuid] || {};
  for (const [name, v] of held.files) {
    if (base[name] === v.hash || !v.available || !(v.at <= now + 30000)) continue;
    const agreed = m.sessions[name];
    if (!agreed) m.sessions[name] = version(v);
    else if (agreed.deleted) { if (v.at > agreed.deletedAt) m.sessions[name] = version(v); }
    // Changed from the agreed version: a plain update. Both sides changed: the newer one wins.
    else if (agreed.hash !== v.hash && (agreed.hash === base[name] || newer(v, agreed))) m.sessions[name] = version(v);
  }
  if (held.incomplete) return;
  const gone = Object.keys(base).filter(name => !held.names.has(name));
  // A folder that lost most of its entries was more likely reset than edited; refill it instead.
  if (gone.length > 20 && gone.length * 2 > Object.keys(base).length) return;
  for (const name of gone) {
    const agreed = m.sessions[name];
    // Only delete what nobody else has changed since this account last saw it.
    if (agreed && !agreed.deleted && agreed.hash === base[name]) m.sessions[name] = { deleted: true, deletedAt: now, hash: agreed.hash };
  }
}

export async function syncPool(core, { targetId, now = Date.now() }, projects) {
  const empty = { copied: 0, updated: 0, removed: 0, existing: 0, missing: 0, failed: 0 };
  try {
    requireThat(core.busy, 'LOCK_REQUIRED', '需要账号操作锁。');
    await core.closed();
    const target = core.getAccount(targetId), base = safePath(core.root, 'claude-code-sessions');
    const saved = core.accounts(), seen = new Set(saved.map(a => a.uuid));
    const all = [...saved, ...dirs(base).filter(u => !seen.has(u)).map(uuid => ({ id: null, uuid }))];
    const tx = transcripts(core, projects), m = load(core);
    const held = new Map(all.map(a => [a.uuid, holdings(core, a, tx)]));
    for (const h of held.values()) collect(m, h, now);
    m.accounts = Object.fromEntries(all.map(a => [a.uuid, hashes(held.get(a.uuid))]));
    atomicJson(core.p('pool.json'), m);
    const mine = held.get(target.uuid), unknown = new Set();
    // Entries no account can supply with an available transcript are reported, not copied.
    for (const h of held.values()) for (const name of h.files.keys()) if (!m.sessions[name] && !mine.names.has(name)) unknown.add(name);
    if (!Object.keys(m.sessions).length) return { ...empty, missing: unknown.size, code: 'NO_RECENT' };
    requireThat(Object.values(m.sessions).filter(s => !s.deleted).length <= LIMIT, 'POOL_LARGE', '会话池超过 5000 条。');

    const targetRoot = safePath(base, target.uuid);
    const org = targetOrg(targetRoot, [...mine.files.values()], target.organizationId), dest = safePath(targetRoot, org); mkdir(dest);
    const holders = new Map();
    for (const h of held.values()) for (const v of h.files.values()) if (v.available && !holders.has(v.hash)) holders.set(v.hash, v);
    const result = { ...empty }; let backupDir = null;
    const backup = file => {
      backupDir ??= core.p('pool-backups', new Date(now).toISOString().replace(/[:.]/g, '-') + '-' + crypto.randomUUID().slice(0, 8));
      mkdir(backupDir); fs.copyFileSync(file, safePath(backupDir, path.basename(file)), fs.constants.COPYFILE_EXCL);
    };
    for (const [name, agreed] of Object.entries(m.sessions)) {
      const have = mine.files.get(name);
      try {
        if (agreed.deleted) {
          if (!have) continue;
          const file = safePath(targetRoot, have.key); backup(file); fs.rmSync(file); result.removed++; continue;
        }
        if (have?.hash === agreed.hash) { result.existing++; continue; }
        // Unparseable target files are left alone rather than replaced.
        if (!have && mine.names.has(name)) { result.existing++; continue; }
        const source = holders.get(agreed.hash);
        if (!source) { if (have) result.existing++; else result.missing++; continue; }
        const output = have ? safePath(targetRoot, have.key) : safePath(dest, name);
        if (have) backup(output);
        placeIndex(safePath(base, source.uuid, source.key), output);
        if (have) result.updated++; else result.copied++;
      } catch { result.failed++; }
    }
    result.missing += unknown.size;
    m.accounts[target.uuid] = hashes(holdings(core, target, tx));
    atomicJson(core.p('pool.json'), m);
    return { ...result, code: result.failed ? 'PARTIAL' : 'OK' };
  } catch (e) { return { ...empty, code: ['ORG_AMBIGUOUS', 'APP_RUNNING', 'POOL_LARGE'].includes(e.code) ? e.code : 'COPY_FAILED' }; }
}
