// Compatibility entry for older shortcuts: open the installed desktop application.
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { execFileSync } from 'node:child_process';
const resources=path.dirname(path.dirname(fileURLToPath(import.meta.url)));
try{
  const owner=JSON.parse(fs.readFileSync(path.join(resources,'switcher-owner.json'),'utf8'));
  if(process.platform!=='darwin'||owner.owner!=='community.claude-switcher.mac.preview')throw new Error();
  execFileSync('/usr/bin/open',[path.dirname(path.dirname(resources))],{stdio:'ignore'});
}catch{console.error('INSTALL_FIRST: 请先安装独立窗口版，再从 Applications 打开“Claude 账号切换器”。');process.exitCode=1;}
