import { atomicJson, readJson } from './core.mjs';
import { seconds } from './usage.mjs';
import { syncPool } from './pool.mjs';

const CODES=['NO_RECENT','OK','PARTIAL','ORG_AMBIGUOUS','APP_RUNNING','COPY_FAILED','POOL_LARGE'];
const REASONS={PARTIAL:'部分会话同步失败',ORG_AMBIGUOUS:'目标账号的组织不明确，请在该账号打开一次 Code 会话后用 ⌘Q 退出',APP_RUNNING:'Claude 仍在运行',COPY_FAILED:'同步未完成，可在“检查修复”页导出诊断报告',POOL_LARGE:'会话超过 5000 条'};
// The session pool shared by every saved account syncs on each manual switch. It is always on and has
// no settings; carry.json only keeps the last result for the diagnostic report. Older files may still
// carry a carrySessions flag, which is ignored.
export class Carry {
  constructor({core,projects,now=seconds}) {
    Object.assign(this,{core,projects,now});
    this.file=core.p('carry.json');this.lastCarry=null;
    let saved;try{saved=readJson(this.file);}catch{}
    if(saved?.lastCarry&&typeof saved.lastCarry==='object')this.lastCarry=saved.lastCarry;
  }
  persist(){atomicJson(this.file,{pool:2,lastCarry:this.lastCarry});}
  carryView(){
    const c=this.lastCarry;if(!c)return null;
    return {code:CODES.includes(c.code)?c.code:'COPY_FAILED',...Object.fromEntries(['copied','updated','removed','existing','missing','failed','at'].map(k=>[k,Number.isFinite(c[k])&&c[k]>=0?c[k]:0]))};
  }
  view(){return {lastCarry:this.carryView()};}
  async switchAccount(args) {
    const result=await this.core.switchAccount(args,{beforeLaunch:async({targetId})=>{
      const carry=await syncPool(this.core,{targetId,now:this.now()*1000},this.projects);
      this.lastCarry={...carry,at:this.now()};this.persist();return carry;
    }});
    if(result?.carry) {
      const c=result.carry;
      result.message+=(c.code==='OK'||c.code==='NO_RECENT')?' 会话池：复制 '+c.copied+' 条，'+(c.updated?'更新 '+c.updated+' 条，':'')+(c.removed?'删除 '+c.removed+' 条，':'')+'已有 '+c.existing+' 条，缺失 '+c.missing+' 条。'
        :' 会话池同步未完整完成（'+(REASONS[c.code]||REASONS.COPY_FAILED)+'）；账号切换结果不受此提示影响。';
    }
    return result;
  }
}
