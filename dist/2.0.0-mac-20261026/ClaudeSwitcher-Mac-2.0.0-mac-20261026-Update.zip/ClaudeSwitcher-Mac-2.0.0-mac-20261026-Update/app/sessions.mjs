import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { safePath, exists, readJson, requireThat, isUuid } from './core.mjs';

export function dirs(root) { return exists(root) ? fs.readdirSync(safePath(root), { withFileTypes: true }).filter(e => e.isDirectory() && isUuid(e.name)).map(e => e.name) : []; }

// Known local roots only. Inspect filenames, never conversation bodies; skip links.
export function transcripts(core, projects) {
  const roots=[...new Set([projects,path.join(core.root,'projects')].filter(Boolean).map(p=>path.resolve(p)))];
  const ids=new Set(),locations=[];let budget=50000;
  for(const root of roots) {
    const info={location:root===path.resolve(projects||'.')?'cli-projects':'desktop-projects',present:false,records:0,incomplete:false};locations.push(info);
    try {
      safePath(root);info.present=exists(root);if(!info.present)continue;
      const pending=[{dir:root,depth:0}];
      while(pending.length) {
        const {dir,depth}=pending.pop();let entries;
        try{entries=fs.readdirSync(safePath(dir),{withFileTypes:true});}catch{info.incomplete=true;continue;}
        for(const e of entries) {
          if(--budget<0){info.incomplete=true;pending.length=0;break;}
          if(e.isSymbolicLink()){info.incomplete=true;continue;}
          if(e.isDirectory()){if(depth<12)pending.push({dir:path.join(dir,e.name),depth:depth+1});else info.incomplete=true;}
          else if(e.isFile()&&e.name.endsWith('.jsonl')&&isUuid(e.name.slice(0,-6))){ids.add(e.name.slice(0,-6).toLowerCase());info.records++;}
        }
      }
    }catch{info.incomplete=true;}
  }
  return {ids,locations,incomplete:locations.some(r=>r.incomplete)};
}
export function uuidScan(core,accountUuid,tx) {
  const uuid=String(accountUuid||'').toLowerCase(),root=safePath(core.root,'claude-code-sessions'),base=safePath(root,uuid),rows=[];
  const diagnostic={indexRootPresent:exists(root),accountFolderPresent:exists(base),organizationFolders:0,alternateAccountFolders:0,indexFiles:0,recognized:0,available:0,missingLink:0,missingTranscript:0,unavailableFlag:0,invalid:0,unreadable:0};
  // Observe alternate layouts without guessing ownership or writing into them.
  for(const first of dirs(root))if(first!==uuid&&exists(safePath(root,first,uuid)))diagnostic.alternateAccountFolders++;
  const orgs=dirs(base);diagnostic.organizationFolders=orgs.length;
  for(const org of orgs) {
    const folder=safePath(base,org);let entries;
    try{entries=fs.readdirSync(folder,{withFileTypes:true});}catch{diagnostic.unreadable++;continue;}
    for(const entry of entries.filter(e=>/^local_(?:local_)?[a-zA-Z0-9-]+\.json$/.test(e.name))) {
      diagnostic.indexFiles++;
      try {
        requireThat(entry.isFile(),'UNSAFE_INDEX','不支持的会话文件类型。');
        const file=safePath(folder,entry.name);requireThat(fs.statSync(file).size<=4*1024*1024,'INDEX_LARGE','会话索引过大。');
        const j=readJson(file);
        if(typeof j?.sessionId!=='string'||!/^(?:local_)?[a-zA-Z0-9-]+$/.test(j.sessionId)||![j.sessionId+'.json','local_'+j.sessionId+'.json'].includes(entry.name)){diagnostic.invalid++;continue;}
        let reason='READY';
        if(!isUuid(j.cliSessionId)){reason='MISSING_LINK';diagnostic.missingLink++;}
        else if(j.transcriptUnavailable===true){reason='UNAVAILABLE_FLAG';diagnostic.unavailableFlag++;}
        else if(!tx.ids.has(j.cliSessionId.toLowerCase())){reason=tx.incomplete?'SCAN_INCOMPLETE':'MISSING_TRANSCRIPT';diagnostic.missingTranscript++;}
        const available=reason==='READY';if(available)diagnostic.available++;diagnostic.recognized++;
        rows.push({key:org+'/'+entry.name,title:typeof j.title==='string'?j.title.slice(0,200):'未命名会话',available,reason,at:Number(j.lastActivityAt)||0,turns:Number(j.completedTurns)||0});
      }catch{diagnostic.unreadable++;}
    }
  }
  return {rows:rows.sort((a,b)=>b.at-a.at),diagnostic};
}
export function accountScan(core,id,tx) {
  return uuidScan(core,core.getAccount(id).uuid,tx);
}
export function sessionReport(core,projects) {
  try {
    const tx=transcripts(core,projects);
    return {transcripts:tx.locations,accounts:core.accounts().map((a,i)=>{
      try{return {number:i+1,...accountScan(core,a.id,tx).diagnostic};}catch{return {number:i+1,code:'READ_FAILED'};}
    })};
  }catch{return {code:'READ_FAILED'};}
}
// Match Windows: one populated org may coexist with empty historical folders.
// Never choose among multiple populated orgs by count or recency.
export function targetOrg(targetRoot, rows, fallbackOrg = null) {
  const orgs = dirs(targetRoot), populated = [...new Set(rows.map(r => r.key.split('/')[0]))];
  const proven = isUuid(fallbackOrg) ? fallbackOrg.toLowerCase() : null;
  const org = populated.length === 1 ? populated[0]
    : proven && (populated.length === 0 || populated.includes(proven)) ? proven
    : populated.length === 0 && orgs.length === 1 ? orgs[0]
    : null;
  requireThat(org, 'ORG_AMBIGUOUS', '无法唯一确认目标组织。请先切到目标账号，在桌面 Code 页打开已有的本地会话并用 ⌘Q 正常退出，再重试；多个有会话的组织不能自动猜选。');
  return org;
}
export function placeIndex(input, output) {
  const temp = output + '.' + crypto.randomUUID() + '.tmp';
  fs.copyFileSync(input, temp, fs.constants.COPYFILE_EXCL); fs.chmodSync(temp, 0o600);
  try { fs.renameSync(temp, output); }
  catch (e) { try { fs.rmSync(temp, { force: true }); } catch {} throw e; }
}
