import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFile, execFileSync, spawn } from 'node:child_process';
import { Problem, requireThat, exists, safePath } from './core.mjs';

function run(file, args) { return execFileSync(file, args, { encoding: 'utf8', timeout: 15000, maxBuffer: 1024 * 1024, stdio: ['ignore','pipe','pipe'] }).trim(); }
export function targetPids(records, appPath) {
  const prefix = appPath + '/Contents/';
  const roots = records.filter(record => record.comm.startsWith(prefix)).map(record => record.pid);
  const children = new Map();
  for (const record of records) {
    const list = children.get(record.ppid) || [];
    list.push(record.pid);
    children.set(record.ppid, list);
  }
  const seen = new Set(roots), stack = [...roots];
  while (stack.length) {
    const pid = stack.pop();
    for (const child of children.get(pid) || []) if (!seen.has(child)) { seen.add(child); stack.push(child); }
  }
  return [...seen];
}
export class MacPlatform {
  constructor({ guard = null } = {}) { this.app = null; this.guard = guard; }
  findApp() {
    requireThat(process.platform === 'darwin', 'MAC_ONLY', '此程序仅用于 macOS。');
    const candidates = ['/Applications/Claude.app', path.join(os.homedir(), 'Applications', 'Claude.app')].filter(exists);
    requireThat(candidates.length === 1, candidates.length ? 'MULTIPLE_APPS' : 'APP_NOT_FOUND', candidates.length ? '发现多份 Claude 应用，请仅保留一份正在使用的安装，再检查。' : '没有找到 Claude.app。请先把官方 Claude 放入“应用程序”文件夹。');
    const app = safePath(candidates[0]);
    const plist = path.join(app, 'Contents', 'Info.plist');
    let id, executable, version;
    try {
      id = run('/usr/bin/plutil', ['-extract','CFBundleIdentifier','raw','-o','-',plist]);
      executable = run('/usr/bin/plutil', ['-extract','CFBundleExecutable','raw','-o','-',plist]);
      version = run('/usr/bin/plutil', ['-extract','CFBundleShortVersionString','raw','-o','-',plist]);
    } catch { throw new Problem('APP_INFO_UNREADABLE', '无法读取 Claude 应用信息，请重新安装官方 Claude。'); }
    requireThat(id === 'com.anthropic.claudefordesktop' && executable === 'Claude', 'UNKNOWN_APP', '此 Claude 应用标识暂不支持，请导出诊断报告。');
    this.app = { path: app, id, version: /^\d[\w.\-]{0,50}$/.test(version) ? version : 'unknown' };
    return this.app;
  }
  processRecords() {
    let lines;
    try { lines = run('/bin/ps', ['-axo','pid=,ppid=,comm=']).split('\n'); } catch { throw new Problem('PROCESS_CHECK_FAILED', '无法确认 Claude 是否完全退出，已停止写入。'); }
    return lines.flatMap(line => {
      const match = line.trim().match(/^(\d+)\s+(\d+)\s+(.+)$/);
      return match ? [{ pid: Number(match[1]), ppid: Number(match[2]), comm: match[3] }] : [];
    });
  }
  async running() {
    const app = this.findApp();
    const prefix = app.path + '/Contents/';
    return this.processRecords().filter(record => record.comm.startsWith(prefix)).map(record => record.pid);
  }
  async quit() {
    const app = this.findApp();
    if (!(await this.running()).length) return;
    // AppKit terminate asks for a normal quit. It does not send account logout.
    const script = "ObjC.import('AppKit'); function run(argv) { var list=$.NSRunningApplication.runningApplicationsWithBundleIdentifier(argv[0]); for(var i=0;i<list.count;i++){var a=list.objectAtIndex(i);if(ObjC.unwrap(a.bundleURL.path)===argv[1])a.terminate;} }";
    try { run('/usr/bin/osascript', ['-l','JavaScript','-e',script,app.id,app.path]); }
    catch { throw new Problem('QUIT_FAILED', '无法请求 Claude 退出。请手动按 ⌘Q 后重试。'); }
    for (let i = 0; i < 30; i++) { if (!(await this.running()).length) { await new Promise(r => setTimeout(r,500)); return; } await new Promise(r => setTimeout(r,500)); }
    throw new Problem('QUIT_TIMEOUT', 'Claude 仍有进程未退出，已停止操作。请保存正在进行的工作，手动退出 Claude 后重试。');
  }
  async forceQuit() {
    const app = this.findApp();
    const alive = pid => { try { process.kill(pid, 0); return pid !== process.pid && pid > 1; } catch { return false; } };
    const snapshot = () => targetPids(this.processRecords(), app.path).filter(alive);
    const initial = snapshot();
    if (!initial.length) return { message: 'Claude 没有在运行。' };
    const script = "ObjC.import('AppKit'); function run(argv) { var list=$.NSRunningApplication.runningApplicationsWithBundleIdentifier(argv[0]); for(var i=0;i<list.count;i++){var a=list.objectAtIndex(i);if(ObjC.unwrap(a.bundleURL.path)===argv[1])a.terminate;} }";
    try { run('/usr/bin/osascript', ['-l','JavaScript','-e',script,app.id,app.path]); } catch { /* Helpers can outlive a failed polite quit. */ }
    const wait = ms => new Promise(resolve => setTimeout(resolve, ms));
    const pending = () => [...new Set([...initial, ...snapshot()])].filter(alive);
    for (let i = 0; i < 6 && pending().length; i++) await wait(500);
    for (const pid of pending()) { try { process.kill(pid, 'SIGTERM'); } catch {} }
    await wait(800);
    for (const pid of pending()) { try { process.kill(pid, 'SIGKILL'); } catch {} }
    await wait(400);
    if (pending().length) throw new Problem('QUIT_TIMEOUT', 'Claude 的后台进程仍未结束。请在活动监视器中结束 Claude 后重试。');
    return { message: '已关闭 Claude，并结束仍在后台的进程。' };
  }
  async launch() {
    const app = this.findApp();
    // Backstop for the check the API runs before switching: the proxy may have gone away meanwhile.
    await this.guard?.check();
    try { run('/usr/bin/open', ['-a',app.path]); } catch { throw new Problem('LAUNCH_FAILED', '本地操作已完成，但 Claude 未能自动打开。请从“应用程序”手动打开。'); }
  }
  info() {
    let app; try { app = this.findApp(); } catch (e) { return { installed: false, code: e.code || 'APP_CHECK_FAILED' }; }
    return { installed: true, claudeVersion: app.version, macOS: run('/usr/bin/sw_vers', ['-productVersion']) };
  }
  chooseDataFolder() {
    let selected;
    try { selected = run('/usr/bin/osascript', ['-l','JavaScript','-e',"var a=Application.currentApplication(); a.includeStandardAdditions=true; a.chooseFolder({withPrompt:'选择 Claude 的数据文件夹（通常位于资源库 / Application Support / Claude）'}).toString();"]); }
    catch { throw new Problem('CANCELLED', '已取消选择。'); }
    const base = path.join(os.homedir(), 'Library', 'Application Support');
    const result = safePath(base, selected);
    requireThat(result !== base && path.basename(result).toLowerCase() === 'claude', 'UNSAFE_PATH', '请选择当前用户资源库下名为 Claude 的数据文件夹。');
    return result;
  }
  openBrowser(url) { const child = spawn('/usr/bin/open', [url], { detached: true, stdio: 'ignore' }); child.on('error', () => {}); child.unref(); }
  async notifyRevokedAccount(label) {
    const clean = String(label || '当前账号').replace(/[\x00-\x1f\x7f]/g, '').slice(0, 80);
    const msg = `管理员已收回您当前使用的 Claude 账号“${clean}”。\n\n点击「确定」后将立即关闭 Claude 并清除该账号的本地登录态（15 秒未操作将自动关闭）。`;
    const script = `var a=Application.currentApplication();a.includeStandardAdditions=true;a.displayDialog(${JSON.stringify(msg)},{withTitle:"Claude 账号已被收回",buttons:["确定"],defaultButton:"确定",withIcon:"caution",givingUpAfter:15});`;
    await new Promise(resolve => {
      const child = execFile('/usr/bin/osascript', ['-l', 'JavaScript', '-e', script], { timeout: 18000 }, () => resolve());
      child.on('error', () => resolve());
    });
  }
}
