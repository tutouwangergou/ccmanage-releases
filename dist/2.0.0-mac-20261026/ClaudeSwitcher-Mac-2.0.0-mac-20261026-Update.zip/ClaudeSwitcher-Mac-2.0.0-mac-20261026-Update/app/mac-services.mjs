import os from 'node:os';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import fs from 'node:fs';
import { safePath, exists, requireThat, Problem } from './core.mjs';
const exec = promisify(execFile);
// Label of the login item created by versions with automatic switching; kept so it can be removed.
const OWNER='community.claude-switcher.mac.preview', LABEL=OWNER+'.watcher';
export async function command(file,args) {
  const r=await exec(file,args,{encoding:'utf8',timeout:12000,maxBuffer:1024*1024,windowsHide:true});
  return r.stdout.trim();
}
export class MacServices {
  constructor({home=os.homedir(),run=command,platform=process.platform}={}) { Object.assign(this,{home,run,platform}); }
  requireMac(){requireThat(this.platform==='darwin','MAC_ONLY','此操作需要在 Mac 上进行。');}
  startupFile(){return safePath(this.home,'Library','LaunchAgents',LABEL+'.plist');}
  async startupOwned() {
    const file=this.startupFile();if(!exists(file))return false;
    let data;try{data=JSON.parse(await this.run('/usr/bin/plutil',['-convert','json','-o','-',file]));}catch{throw new Problem('STARTUP_UNKNOWN','已有登录启动文件无法确认，已停止修改。');}
    requireThat(data.Label===LABEL&&data.ClaudeSwitcherOwner===OWNER,'STARTUP_UNKNOWN','同名启动项不是此工具创建的，已停止修改。');
    return true;
  }
  // Removes the login item left by earlier versions; unknown same-named files are preserved.
  async removeStartup() {
    this.requireMac();
    if(await this.startupOwned())fs.unlinkSync(this.startupFile());
  }
}
