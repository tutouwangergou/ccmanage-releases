export const VERSION = '2.0.0-mac-20261026';
// Runtimes bundled with this version. An update that needs different ones downloads the complete package.
export const RUNTIME = { node: '22.23.3', electron: '44.4.5' };
