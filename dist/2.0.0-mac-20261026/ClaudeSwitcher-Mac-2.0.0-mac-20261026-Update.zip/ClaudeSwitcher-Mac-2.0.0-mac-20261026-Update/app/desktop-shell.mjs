import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { ORIGIN } from './desktop-backend.mjs';
import { VERSION } from './version.mjs';

const SETUP='https://code.claude.com/docs/en/setup';
export function localPage(url){try{const u=new URL(url);return u.origin===ORIGIN&&u.pathname==='/';}catch{return false;}}
// Only these exact pages may leave the window: the setup doc and the download pages named in the usage guide.
const EXTERNAL=new Set([SETUP,'https://github.com/2dust/v2rayN/releases/tag/7.21.0','https://claude.com/product/overview','https://antigravity.google/']);
export function externalPage(url){return EXTERNAL.has(url);}
// Opens at about 1300×820 so every account column fits; smaller screens get their whole work area.
export function windowOptions(preload,area={width:1340,height:860}){return {
  width:Math.max(760,Math.min(1300,area.width-40)),height:Math.max(520,Math.min(820,area.height-40)),minWidth:760,minHeight:520,center:true,show:false,title:'Claude 账号管理工具',backgroundColor:'#f6f4ef',
  webPreferences:{preload,nodeIntegration:false,contextIsolation:true,sandbox:true,webSecurity:true,webviewTag:false,devTools:false,partition:'claude-switcher-window'}
};}
// 2FA QR scan: macOS's own Core Image detector reads one picture piped in on stdin; nothing is written to disk.
const QR_SCRIPT=`ObjC.import('CoreImage');
function run(){
  const img=$.CIImage.imageWithData($.NSFileHandle.fileHandleWithStandardInput.readDataToEndOfFile);if(img.isNil())return '[]';
  const found=$.CIDetector.detectorOfTypeContextOptions($.CIDetectorTypeQRCode,$(),$({CIDetectorAccuracy:$.CIDetectorAccuracyHigh})).featuresInImage(img),out=[];
  for(let i=0;i<found.count;i++){const m=found.objectAtIndex(i).messageString;if(!m.isNil())out.push(m.js);}
  return JSON.stringify(out);
}`;
export function decodeQr(png){return new Promise(resolve=>{
  const child=execFile('/usr/bin/osascript',['-l','JavaScript','-e',QR_SCRIPT],{timeout:15000,maxBuffer:1<<20},(error,stdout)=>{
    if(error)return resolve([]);try{const list=JSON.parse(stdout);resolve(Array.isArray(list)?list.filter(x=>typeof x==='string'):[]);}catch{resolve([]);}
  });
  child.stdin.on('error',()=>{});child.stdin.end(png);
});}
export const SCREEN_SETTINGS='x-apple.systempreferences:com.apple.preference.security?Privacy_ScreenCapture';
// Whole screens first, then every other window, so a QR code behind this window is still found.
// Only an otpauth://totp link leaves this function; the pictures stay in memory.
export async function scanQr({desktopCapturer,systemPreferences,screen,ownId,decode=decodeQr}){
  if(!desktopCapturer)return {ok:false,code:'UNSUPPORTED'};
  if(systemPreferences?.getMediaAccessStatus('screen')!=='granted'){
    // The first request makes macOS ask and puts this app in the Screen Recording list.
    await desktopCapturer.getSources({types:['screen'],thumbnailSize:{width:1,height:1}}).catch(()=>{});
    return {ok:false,code:'PERMISSION'};
  }
  let width=1920,height=1080;
  for(const d of screen?.getAllDisplays?.()||[]){width=Math.max(width,Math.round(d.size.width*d.scaleFactor));height=Math.max(height,Math.round(d.size.height*d.scaleFactor));}
  for(const type of ['screen','window']){
    let sources;try{sources=await desktopCapturer.getSources({types:[type],thumbnailSize:{width,height}});}catch{return {ok:false,code:'FAILED'};}
    for(const source of sources){
      if(source.id===ownId||!source.thumbnail||source.thumbnail.isEmpty())continue;
      const url=(await decode(source.thumbnail.toPNG())).find(text=>/^otpauth:\/\/totp\//i.test(text));
      if(url)return {ok:true,url};
    }
  }
  return {ok:false,code:'NONE'};
}
export async function startDesktop({app,BrowserWindow,Menu,dialog,shell,ipcMain,screen,desktopCapturer,systemPreferences,backend,updater,preload}){
  let window=null,quitting=false,quitPending=false;
  const reveal=()=>{if(window){if(window.isMinimized())window.restore();window.show();window.focus();}};
  if(!app.requestSingleInstanceLock()){app.quit();return null;}
  app.on('second-instance',reveal);app.on('activate',reveal);
  app.on('window-all-closed',()=>{});
  const finish=()=>{quitting=true;app.quit();};
  const quit=async()=>{
    if(quitPending)return {ok:false};quitPending=true;
    try{await backend.quit();finish();return {ok:true};}
    catch(e){
      reveal();await dialog.showMessageBox(window,{type:'warning',title:'暂时无法退出',message:e.code==='BUSY'?'账号操作正在进行，请完成后再退出。':'后台尚未确认停止，请稍后再试。',detail:'应用会保留当前窗口和账号数据。',buttons:['知道了']});return {ok:false};
    }finally{quitPending=false;}
  };
  app.on('before-quit',event=>{if(!quitting){event.preventDefault();void quit();}});
  await app.whenReady();
  let state;
  try{state=await backend.connect();}
  catch(e){
    await dialog.showMessageBox({type:'error',title:'Claude 账号管理工具',message:e.code==='VERSION_MISMATCH'?'旧版后台仍在运行，请先退出旧版工具。':'切换器未能启动。',detail:'请使用安装包内的“诊断与修复.command”。问题编号：'+(e.code==='VERSION_MISMATCH'?'VERSION_MISMATCH':'START_FAILED'),buttons:['关闭']});finish();return null;
  }
  window=new BrowserWindow(windowOptions(preload,screen?.getPrimaryDisplay().workAreaSize));
  const reload=async()=>{
    try{state=await backend.connect();await window.loadURL(ORIGIN+'/#'+state.token);reveal();}
    catch{await dialog.showMessageBox(window,{type:'warning',message:'未能重新连接后台。请运行安装包里的“诊断与修复.command”。',buttons:['知道了']});}
  };
  const contents=window.webContents,session=contents.session;
  session.setPermissionRequestHandler((_contents,_permission,callback)=>callback(false));
  session.setPermissionCheckHandler(()=>false);
  session.webRequest.onBeforeRequest((details,callback)=>{
    const local=details.url.startsWith(ORIGIN+'/')||details.url.startsWith('blob:'+ORIGIN+'/')||details.url==='about:blank';
    callback({cancel:!local});
  });
  const openExternal=url=>{if(externalPage(url))void shell.openExternal(url).catch(()=>{});};
  contents.setWindowOpenHandler(({url})=>{openExternal(url);return {action:'deny'};});
  contents.on('will-navigate',(event,url)=>{if(!localPage(url)){event.preventDefault();openExternal(url);}});
  contents.on('will-redirect',(event,url)=>{if(!localPage(url))event.preventDefault();});
  contents.on('will-attach-webview',event=>event.preventDefault());
  session.on('will-download',event=>event.preventDefault());
  const trusted=event=>event.sender===contents&&event.senderFrame===contents.mainFrame&&localPage(event.senderFrame.url);
  ipcMain.handle('switcher:quit',event=>{
    if(!trusted(event))return {ok:false};
    return quit();
  });
  let savingReport=false;
  ipcMain.handle('switcher:report',async event=>{
    if(!trusted(event)||savingReport)return {ok:false};savingReport=true;let temporary;
    try{
      // No renderer-supplied path or content: read the existing allowlisted report.
      const report=await backend.report();
      const choice=await dialog.showSaveDialog(window,{title:'保存脱敏诊断报告',defaultPath:path.join(app.getPath('downloads'),'ClaudeSwitcher-诊断报告.json'),filters:[{name:'JSON 报告',extensions:['json']}],properties:['showOverwriteConfirmation']});
      if(choice.canceled||!choice.filePath)return {ok:true,canceled:true};
      temporary=path.join(path.dirname(choice.filePath),'.switcher-report-'+crypto.randomUUID()+'.tmp');
      fs.writeFileSync(temporary,JSON.stringify(report,null,2),{flag:'wx',mode:0o600});fs.renameSync(temporary,choice.filePath);temporary=null;
      return {ok:true,canceled:false};
    }catch{return {ok:false};}
    finally{if(temporary)try{fs.unlinkSync(temporary);}catch{}savingReport=false;}
  });
  let scanning=false;
  ipcMain.handle('switcher:scan-qr',async event=>{
    if(!trusted(event)||scanning)return {ok:false,code:'BUSY'};scanning=true;
    try{
      const result=await scanQr({desktopCapturer,systemPreferences,screen,ownId:window.getMediaSourceId?.()});
      if(result.code==='PERMISSION'){
        const choice=await dialog.showMessageBox(window,{type:'info',message:'扫码需要“录屏”权限。',detail:'打开“系统设置 → 隐私与安全性 → 录屏与系统录音”，打开“Claude 账号管理工具”，然后退出并重新打开本工具再点“扫码”。\n画面只在本机识别，不保存、不联网，只取出二维码里的 2FA 密钥。',buttons:['打开系统设置','取消'],defaultId:0,cancelId:1});
        if(choice.response===0)void shell.openExternal(SCREEN_SETTINGS).catch(()=>{});
      }
      return result;
    }catch{return {ok:false,code:'FAILED'};}
    finally{scanning=false;}
  });
  if(updater){
    updater.onChange=state=>{if(!contents.isDestroyed?.())contents.send('switcher:update',state);};
    // The first call from the page reports the previous update run and checks once per launch.
    let started=false;
    ipcMain.handle('switcher:update-start',event=>{
      if(!trusted(event))return null;
      if(started)return {result:null,state:updater.state};
      started=true;const result=updater.takeResult();void updater.check();
      return {result,state:updater.state};
    });
    ipcMain.handle('switcher:update-check',event=>trusted(event)?updater.check():null);
    ipcMain.handle('switcher:update-apply',async event=>{
      if(!trusted(event))return {ok:false};
      const prepared=await updater.apply();if(!prepared)return {ok:false};
      // The installer can replace the app only after the backend and this window have stopped.
      try{await backend.quit();}
      catch(e){
        if(e.code==='BUSY'){updater.fail(prepared,'BUSY','账号操作正在进行，请完成后再点“更新”。');return {ok:false};}
        updater.fail(prepared,'STOP_FAILED','后台没有停止，请稍后再点“更新”。');void reload();return {ok:false};
      }
      try{updater.handOff(prepared);}
      catch{updater.fail(prepared,'UPDATE_FAILED','更新未完成，旧版本仍可正常使用。');void reload();return {ok:false};}
      finish();return {ok:true};
    });
  }
  const checkUpdate=async()=>{
    reveal();const state=await updater.check();
    if(state.phase==='latest')await dialog.showMessageBox(window,{type:'info',message:'已是最新版本。',detail:'当前版本：'+VERSION,buttons:['知道了']});
    else if(state.phase==='error'&&state.during==='check')await dialog.showMessageBox(window,{type:'warning',message:'暂时无法检查更新。',detail:state.message,buttons:['知道了']});
  };
  // Nothing needs to keep running without the window, so closing it quits; a busy operation keeps the window open.
  window.on('close',event=>{if(!quitting){event.preventDefault();void quit();}});
  window.on('page-title-updated',event=>event.preventDefault());
  contents.on('render-process-gone',()=>{void dialog.showMessageBox(window,{type:'error',message:'界面意外停止。可从“窗口”菜单重新加载；后台服务继续运行。',buttons:['知道了']});});
  window.once('ready-to-show',reveal);
  Menu.setApplicationMenu(Menu.buildFromTemplate([
    {label:'Claude 账号管理工具',submenu:[{label:'显示主窗口',click:reveal},...(updater?[{label:'检查更新…',click:()=>void checkUpdate()}]:[]),{type:'separator'},{label:'隐藏账号管理工具',role:'hide'},{label:'隐藏其他应用',role:'hideOthers'},{label:'显示全部',role:'unhide'},{type:'separator'},{label:'退出工具',accelerator:'CmdOrCtrl+Q',click:()=>void quit()}]},
    {label:'编辑',submenu:[{label:'撤销',role:'undo'},{label:'重做',role:'redo'},{type:'separator'},{label:'剪切',role:'cut'},{label:'复制',role:'copy'},{label:'粘贴',role:'paste'},{label:'全选',role:'selectAll'}]},
    {label:'窗口',submenu:[{label:'最小化',role:'minimize'},{label:'缩放',role:'zoom'},{label:'显示主窗口',click:reveal},{label:'重新连接并加载界面',accelerator:'CmdOrCtrl+R',click:reload},{label:'关闭窗口并退出',accelerator:'CmdOrCtrl+W',click:()=>window.close()}]},
    {label:'帮助',submenu:[{label:'安装 Claude Code',click:()=>openExternal(SETUP)},{label:'使用提示',click:()=>void dialog.showMessageBox(window,{type:'info',message:'关闭窗口即退出工具。',detail:'正在保存或切换账号时会等操作完成再退出。遇到问题请打开“检查修复”。',buttons:['知道了']})}]}
  ]));
  await window.loadURL(ORIGIN+'/#'+state.token);
  return {window,quit,reveal};
}
