import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import os from 'node:os';
import { DatabaseSync } from 'node:sqlite';

export { VERSION } from './version.mjs';
import { VERSION } from './version.mjs';
// cowork-enabled-cli-ops.json names one owner account, so it follows the account. A hot Cookies-journal
// must never meet another account's Cookies. Snapshots taken before these were added simply lack them;
// restoring one clears the live copies.
export const ITEMS = ['Local State', 'Network', 'Cookies', 'Cookies-wal', 'Cookies-shm', 'Cookies-journal', 'Local Storage', 'Session Storage', 'cowork-enabled-cli-ops.json', 'config.json'];
const UUID = /^[a-f0-9]{8}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{4}-[a-f0-9]{12}$/i;
export const isUuid = x => typeof x === 'string' && UUID.test(x);
export class Problem extends Error {
  constructor(code, message) { super(message); this.code = code; }
}
export function requireThat(value, code, message) { if (!value) throw new Problem(code, message); }
export function readJson(file) { return JSON.parse(fs.readFileSync(file, 'utf8').replace(/^\uFEFF/, '')); }
export function exists(file) { try { fs.lstatSync(file); return true; } catch (e) { if (e.code === 'ENOENT') return false; throw e; } }
export function safePath(root, ...parts) {
  const base = path.resolve(root), result = path.resolve(base, ...parts);
  requireThat(result === base || result.startsWith(base + path.sep), 'UNSAFE_PATH', '路径不在允许范围内，已停止操作。');
  let current = path.parse(result).root;
  for (const component of result.slice(current.length).split(path.sep).filter(Boolean)) {
    current = path.join(current, component);
    if (exists(current)) requireThat(!fs.lstatSync(current).isSymbolicLink(), 'SYMLINK', '检测到符号链接，已停止操作。请使用本机普通目录。');
  }
  return result;
}
export function mkdir(dir) { safePath(dir); fs.mkdirSync(dir, { recursive: true, mode: 0o700 }); }
export function atomicJson(file, value) {
  safePath(path.dirname(file), path.basename(file));
  const temp = file + '.' + crypto.randomUUID() + '.tmp';
  const fd = fs.openSync(temp, 'wx', 0o600);
  try { fs.writeFileSync(fd, JSON.stringify(value, null, 2) + '\n'); fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  fs.renameSync(temp, file);
  // Persist the rename where the filesystem supports directory fsync.
  try { const d = fs.openSync(path.dirname(file), 'r'); try { fs.fsyncSync(d); } finally { fs.closeSync(d); } } catch {}
}
function hash(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
function inventory(root, prefix = '', output = {}) {
  const dir = safePath(root, prefix);
  for (const entry of fs.readdirSync(dir, { withFileTypes: true }).sort((a,b) => a.name.localeCompare(b.name))) {
    const key = prefix ? prefix + '/' + entry.name : entry.name;
    const file = safePath(root, key);
    requireThat(!entry.isSymbolicLink() && (entry.isFile() || entry.isDirectory()), 'UNSAFE_FILE', '配置中含有不支持的文件类型。');
    if (entry.isDirectory()) { output[key + '/'] = 'directory'; inventory(root, key, output); }
    else output[key] = hash(file);
  }
  return output;
}
function copy(source, dest) {
  safePath(source); safePath(dest);
  const st = fs.lstatSync(source);
  requireThat(st.isDirectory() || st.isFile(), 'UNSAFE_FILE', '配置包含不支持的文件。');
  if (st.isDirectory()) {
    mkdir(dest);
    for (const child of fs.readdirSync(source)) copy(safePath(source, child), safePath(dest, child));
  } else {
    fs.copyFileSync(source, dest, fs.constants.COPYFILE_EXCL);
    fs.chmodSync(dest, 0o600);
    const fd = fs.openSync(dest, 'r+'); try { fs.fsyncSync(fd); } finally { fs.closeSync(fd); }
  }
}
export function inspect(root) {
  const result = { compatible: false, cookie: 'missing', layout: null, uuid: null, reasons: [] };
  try {
    safePath(root);
    if (!exists(root)) { result.reasons.push('DATA_NOT_FOUND'); return result; }
    const config = readJson(safePath(root, 'config.json'));
    const local = readJson(safePath(root, 'Local State'));
    if (!local || typeof local !== 'object' || Array.isArray(local)) throw new Error('Local State');
    const network = exists(safePath(root, 'Network', 'Cookies'));
    const legacy = exists(safePath(root, 'Cookies'));
    if (network && legacy) { result.reasons.push('AMBIGUOUS_COOKIES'); return result; }
    // Only two explicit Electron layouts are supported. Unknown layouts stay read only.
    result.layout = network ? 'network' : legacy ? 'root' : null;
    if (!result.layout) { result.reasons.push('COOKIE_FILE_MISSING'); return result; }
    if (!exists(safePath(root, 'Local Storage'))) { result.reasons.push('STORAGE_MISSING'); return result; }
    result.uuid = isUuid(config.lastKnownAccountUuid) ? config.lastKnownAccountUuid.toLowerCase() : null;
    let db, scratch;
    try {
      // SQLite may create/update SHM even with readOnly=true. Inspect a private
      // disposable copy including WAL, keeping live and immutable snapshot bytes untouched.
      // macOS /var is a system symlink to /private/var; canonicalize only the
      // trusted OS temporary root, not arbitrary profile or data paths.
      scratch = fs.mkdtempSync(path.join(fs.realpathSync(os.tmpdir()), 'claude-cookie-check-')); fs.chmodSync(scratch, 0o700);
      const source = safePath(root, ...(network ? ['Network','Cookies'] : ['Cookies']));
      for (const suffix of ['', '-wal', '-shm']) if (exists(safePath(root, path.relative(root, source + suffix)))) copy(source + suffix, path.join(scratch, 'Cookies' + suffix));
      db = new DatabaseSync(path.join(scratch, 'Cookies'), { readOnly: true, timeout: 1500 });
      db.exec('PRAGMA query_only=ON; PRAGMA trusted_schema=OFF;');
      const row = db.prepare("SELECT count(*) AS total, coalesce(sum(CASE WHEN expires_utc=0 OR expires_utc>(strftime('%s','now')+11644473600)*1000000 THEN 1 ELSE 0 END),0) AS valid FROM cookies WHERE host_key IN ('claude.ai','.claude.ai') AND name IN ('sessionKey','sessionKeyV2','sessionKeyV3') AND (length(encrypted_value)>0 OR length(value)>0)").get();
      result.cookie = row.total === 0 ? 'missing' : row.valid > 0 ? 'present' : 'expired';
      result.compatible = true;
    } catch { result.cookie = 'unreadable'; result.reasons.push('COOKIE_UNREADABLE'); }
    finally { if (db) db.close(); if (scratch) fs.rmSync(safePath(fs.realpathSync(os.tmpdir()), path.basename(scratch)), { recursive: true, force: true }); }
    if (!result.uuid) result.reasons.push('IDENTITY_UNKNOWN');
  } catch (e) { result.reasons.push(e instanceof Problem ? e.code : 'CONFIG_UNREADABLE'); }
  return result;
}
function valid(state) { return state.compatible && state.cookie === 'present' && !!state.uuid; }
function requireValid(state) {
  requireThat(state.compatible, 'UNSUPPORTED_LAYOUT', '无法确认此版 Claude 的数据格式。请先正常退出 Claude 后重新检查；仍不支持时导出诊断报告。');
  requireThat(state.uuid, 'IDENTITY_UNKNOWN', '无法确认当前账号身份。请进入 Claude 正常聊天界面，并打开一次 Code 页面，然后用 ⌘Q 退出。');
  requireThat(state.cookie === 'present', 'LOGIN_' + state.cookie.toUpperCase(), '未找到可保存的桌面登录态。请在 Claude 中登录后正常退出；已保存的账号不会被覆盖。');
}
function label(value) {
  requireThat(typeof value === 'string' && value.trim().length > 0 && value.trim().length <= 80 && !/[\x00-\x1f\x7f]/.test(value), 'BAD_NAME', '请输入 1–80 个字符的账号名称。');
  return value.trim().normalize('NFC');
}
// Optional details the user records while editing; empty input clears the field.
function activatedOn(value) {
  if (value === undefined || value === null || value === '') return undefined;
  const date = typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value) ? new Date(value + 'T00:00:00Z') : null;
  requireThat(date && !isNaN(date) && date.toISOString().slice(0, 10) === value && value >= '2020-01-01' && value <= '2100-12-31', 'BAD_DATE', '开通时间格式无效，请选择一个日期。');
  return value;
}
function organizationId(value) {
  if (value === undefined || value === null || value === '') return undefined;
  requireThat(isUuid(typeof value === 'string' ? value.trim() : value), 'BAD_ORGANIZATION', 'Organization ID 格式无效，应类似 xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx。');
  return value.trim().toLowerCase();
}
function email(value) {
  if (value === undefined || value === null || value === '') return undefined;
  const text = typeof value === 'string' ? value.trim() : '';
  requireThat(text.length <= 254 && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(text) && !/[\x00-\x1f\x7f]/.test(text), 'BAD_EMAIL', '邮箱格式无效。');
  return text;
}
function accountPassword(value) {
  if (value === undefined || value === null) return undefined;
  const text = typeof value === 'string' ? value.trim() : null;
  if (text === '') return undefined;
  requireThat(text !== null && text.length <= 200 && !/[\x00-\x1f\x7f]/.test(text), 'BAD_PASSWORD', '密码最多 200 个字符，且不能换行。');
  return text;
}
function totpSecretField(value) {
  if (value === undefined || value === null) return undefined;
  let text = typeof value === 'string' ? value.trim() : null;
  if (!text) return undefined;
  if (/^otpauth:/i.test(text)) {
    try { text = (new URL(text).searchParams.get('secret') || '').trim(); } catch {}
  }
  const clean = text.replace(/[\s-]+/g, '').replace(/=+$/, '');
  const finalText = /^[A-Za-z2-7]{16,128}$/.test(clean) ? clean.toUpperCase() : text;
  requireThat(finalText.length > 0 && finalText.length <= 200 && !/[\x00-\x1f\x7f]/.test(finalText), 'BAD_TOTP', '2FA 密钥格式无效（最多 200 个字符，且不能换行）。');
  return finalText;
}
function accountServices(value) {
  if (value === undefined || value === null) return undefined;
  const list = Array.isArray(value)
    ? value.map(x => String(x || '').trim()).filter(Boolean)
    : typeof value === 'string'
      ? value.split(/[,，、;；]+/).map(x => x.trim()).filter(Boolean)
      : null;
  if (list === null) throw new Problem('BAD_SERVICES', '已开通服务格式无效。');
  const unique = [...new Set(list.map(x => x.normalize('NFC')))];
  const joined = unique.join(', ');
  if (!joined) return undefined;
  requireThat(joined.length <= 200 && !/[\x00-\x1f\x7f]/.test(joined), 'BAD_SERVICES', '已开通服务最多 200 个字符，且不能换行。');
  return joined;
}
// Free-text note shown in the account list.
function note(value) {
  if (value === undefined || value === null) return undefined;
  const text = typeof value === 'string' ? value.trim().normalize('NFC') : null;
  if (text === '') return undefined;
  requireThat(text !== null && text.length <= 200 && !/[\x00-\x1f\x7f]/.test(text), 'BAD_NOTE', '备注最多 200 个字符，且不能换行。');
  return text;
}
// List group: 使用中 (default, not stored), 储备 or 作废.
const GROUPS = ['active', 'reserve', 'retired'];
function group(value) {
  if (value === undefined || value === null || value === '' || value === 'active') return undefined;
  requireThat(GROUPS.includes(value), 'BAD_GROUP', '分组无效。');
  return value;
}
const groupName = { active: '使用中', reserve: '储备', retired: '作废' };
// Details the user records for each account; kept across re-saves and index rebuilds.
const DETAILS = ['activatedOn', 'organizationId', 'email', 'password', 'totpSecret', 'services', 'note', 'group'];
const details = account => Object.fromEntries(DETAILS.filter(k => account?.[k] !== undefined).map(k => [k, account[k]]));

// Every mutation runs behind the server's exclusive localhost listener and busy guard.
// Snapshots are immutable; only small JSON pointers are atomically replaced.
export class Switcher {
  constructor({ store, root, platform, fault = () => {} }) {
    this.store = path.resolve(store); this.root = path.resolve(root); this.platform = platform; this.fault = fault; this.busy = false;
    mkdir(this.store); mkdir(this.p('snapshots'));
    if (!exists(this.p('accounts.json'))) atomicJson(this.p('accounts.json'), { format: 1, accounts: [] });
  }
  p(...parts) { return safePath(this.store, ...parts); }
  accounts() {
    let data;
    try { data = readJson(this.p('accounts.json')); } catch { throw new Problem('INDEX_CORRUPT', '账号列表损坏，原始快照仍保留。请按 ⌘Q 退出 Claude，再在“检查修复”中点「从快照重建账号列表」；仍失败再导出诊断报告。不要重复安装覆盖数据。'); }
    requireThat(data.format === 1 && Array.isArray(data.accounts) && data.accounts.every(a => isUuid(a.id) && isUuid(a.snapshot) && isUuid(a.uuid) && typeof a.label === 'string') && new Set(data.accounts.map(a => a.id)).size === data.accounts.length && new Set(data.accounts.map(a => a.uuid)).size === data.accounts.length, 'INDEX_CORRUPT', '账号列表不完整，已停止写入。请按 ⌘Q 退出 Claude，再在“检查修复”中点「从快照重建账号列表」。');
    return data.accounts;
  }
  getAccount(id) { const account = this.accounts().find(a => a.id === id); requireThat(account, 'ACCOUNT_MISSING', '找不到所选账号，请刷新列表。'); return account; }
  pending() { return exists(this.p('pending.json')) ? readJson(this.p('pending.json')) : null; }
  recovery() { return exists(this.p('operation.json')); }
  requireReady(allowPending = false) {
    requireThat(!this.recovery(), 'RECOVERY_REQUIRED', '上次操作中断。请先在“检查修复”中恢复操作前的备份。');
    requireThat(allowPending || !this.pending(), 'LOGIN_PENDING', '请先完成当前登录并保存，或取消登录恢复原来的账号。');
  }
  async exclusive(fn) {
    requireThat(!this.busy, 'BUSY', '另一个操作正在进行，请稍候。'); this.busy = true;
    try { return await fn(); } finally { this.busy = false; }
  }
  async closed() {
    requireThat(!(await this.platform.running()).length, 'APP_RUNNING', '请从 Claude 菜单选择“退出 Claude”或按 ⌘Q，再重试。关闭窗口不等于退出，也不要点“退出登录”。');
  }
  capture(kind) {
    const id = crypto.randomUUID(), base = this.p('snapshots', id), payload = path.join(base, 'payload');
    mkdir(payload);
    const items = ITEMS.filter(item => exists(safePath(this.root, item)));
    const before = {};
    for (const item of items) {
      const src = safePath(this.root, item);
      before[item] = fs.statSync(src).isDirectory() ? inventory(src) : hash(src);
      copy(src, path.join(payload, item));
    }
    for (const item of items) {
      const src = safePath(this.root, item);
      const after = fs.statSync(src).isDirectory() ? inventory(src) : hash(src);
      const dst = path.join(payload, item);
      const saved = fs.statSync(dst).isDirectory() ? inventory(dst) : hash(dst);
      requireThat(JSON.stringify(before[item]) === JSON.stringify(after) && JSON.stringify(after) === JSON.stringify(saved), 'FILES_CHANGED', 'Claude 数据仍在变化，已取消保存。请正常退出后重试。');
    }
    atomicJson(path.join(base, 'manifest.json'), { format: 1, kind, id, created: new Date().toISOString(), root: this.root, items, files: inventory(payload) });
    return id;
  }
  snapshot(id) {
    requireThat(isUuid(id), 'BAD_SNAPSHOT', '备份编号无效。');
    const base = this.p('snapshots', id), payload = safePath(base, 'payload'), m = readJson(safePath(base, 'manifest.json'));
    requireThat(m.format === 1 && m.id === id && m.root === this.root && Array.isArray(m.items) && m.items.every(x => ITEMS.includes(x)) && new Set(m.items).size === m.items.length, 'BAD_SNAPSHOT', '备份格式或设备目录不匹配。账号备份仅供原电脑、原 macOS 用户使用。');
    requireThat(JSON.stringify(m.files) === JSON.stringify(inventory(payload)), 'SNAPSHOT_CHANGED', '备份文件校验失败，已停止恢复。请选用其他完好的备份或修复登录。');
    requireThat(JSON.stringify([...m.items].sort()) === JSON.stringify(fs.readdirSync(payload).sort()), 'BAD_SNAPSHOT', '备份清单与实际文件不一致。');
    return { ...m, payload };
  }
  apply(id) {
    const snapshot = id ? this.snapshot(id) : null;
    if (snapshot) mkdir(this.root);
    // Preflight all paths, including nested symlinks, before the first removal.
    for (const item of ITEMS) {
      const p = safePath(this.root, item);
      if (exists(p) && fs.lstatSync(p).isDirectory()) inventory(p);
    }
    for (const item of ITEMS) {
      const p = safePath(this.root, item);
      if (exists(p)) fs.rmSync(p, { recursive: true });
      this.fault('remove:' + item);
      if (snapshot?.items.includes(item)) copy(safePath(snapshot.payload, item), p);
    }
    if (snapshot) {
      for (const item of snapshot.items) {
        const live = safePath(this.root, item), saved = safePath(snapshot.payload, item);
        requireThat(JSON.stringify(fs.statSync(live).isDirectory() ? inventory(live) : hash(live)) === JSON.stringify(fs.statSync(saved).isDirectory() ? inventory(saved) : hash(saved)), 'RESTORE_MISMATCH', '恢复后的文件不一致，请执行中断恢复。');
      }
    }
  }
  persistAccount(name, id, state, extraDetails = {}) {
    const all = this.accounts(), existing = id ? this.getAccount(id) : null;
    if (existing) requireThat(existing.uuid === state.uuid, 'WRONG_ACCOUNT', '当前登录的账号与要更新的账号不同，已拒绝覆盖。请取消登录或登录正确账号。');
    else {
      requireThat(!all.some(a => a.uuid === state.uuid), 'DUPLICATE_ACCOUNT', '这个账号已经保存，请更新已有账号。');
      requireThat(!all.some(a => a.label.toLowerCase() === name.toLowerCase()), 'DUPLICATE_NAME', '这个名称已经存在，请换一个。');
    }
    const snapshot = this.capture('account'), captured = inspect(this.snapshot(snapshot).payload);
    requireValid(captured); requireThat(captured.uuid === state.uuid, 'IDENTITY_CHANGED', '账号在操作期间发生变化，已取消保存。');
    const mergedDetails = { ...details(existing) };
    for (const k of DETAILS) {
      if (extraDetails[k] !== undefined) mergedDetails[k] = extraDetails[k];
    }
    const account = { id: existing?.id || crypto.randomUUID(), label: existing?.label || name, uuid: captured.uuid, snapshot, saved: new Date().toISOString(), ...mergedDetails };
    // Update in place so the list keeps its order across switches; new accounts go to the end.
    atomicJson(this.p('accounts.json'), { format: 1, accounts: existing ? all.map(a => a.id === account.id ? account : a) : [...all, account] });
    return account;
  }
  async rename({ id, name }) {
    return this.exclusive(() => {
      this.requireReady();
      const account = this.getAccount(id), next = label(name);
      if (next === account.label) return { message: '名称没有变化。' };
      requireThat(!this.accounts().some(a => a.id !== account.id && a.label.toLowerCase() === next.toLowerCase()), 'DUPLICATE_NAME', '这个名称已经存在，请换一个。');
      atomicJson(this.p('accounts.json'), { format: 1, accounts: this.accounts().map(a => a.id === account.id ? { ...a, label: next } : a) });
      return { message: `已把名称改为“${next}”。登录数据和额度记录没有改动。` };
    });
  }
  async setGroup({ id, group: value }) {
    return this.exclusive(() => {
      this.requireReady();
      const account = this.getAccount(id), next = group(value), updated = { ...account };
      if (next === account.group) return { message: '分组没有变化。' };
      if (next === undefined) delete updated.group; else updated.group = next;
      atomicJson(this.p('accounts.json'), { format: 1, accounts: this.accounts().map(a => a.id === account.id ? updated : a) });
      return { message: `已把“${account.label}”移到「${groupName[next || 'active']}」。` };
    });
  }
  async edit({ id, name, activatedOn: date, organizationId: org, email: mail, password: pass, totpSecret: totp, services: svc, note: text, group: kind }) {
    return this.exclusive(() => {
      this.requireReady();
      const account = this.getAccount(id), next = label(name);
      const fields = {
        activatedOn: activatedOn(date),
        organizationId: organizationId(org),
        email: email(mail),
        password: pass === undefined ? account.password : accountPassword(pass),
        totpSecret: totp === undefined ? account.totpSecret : totpSecretField(totp),
        services: svc === undefined ? account.services : accountServices(svc),
        note: note(text),
        group: group(kind),
      };
      requireThat(!this.accounts().some(a => a.id !== account.id && a.label.toLowerCase() === next.toLowerCase()), 'DUPLICATE_NAME', '这个名称已经存在，请换一个。');
      const updated = { ...account, label: next };
      for (const k of DETAILS) { if (fields[k] === undefined) delete updated[k]; else updated[k] = fields[k]; }
      atomicJson(this.p('accounts.json'), { format: 1, accounts: this.accounts().map(a => a.id === account.id ? updated : a) });
      return { message: `已保存“${next}”的账号信息。登录数据和额度记录没有改动。` };
    });
  }
  async save({ name, id = null, expectedUuid, stopFirst = false, email: mail, password: pass, totpSecret: totp, services: svc, note: text }) {
    return this.exclusive(async () => {
      this.requireReady(true);
      const extraDetails = {
        email: email(mail),
        password: accountPassword(pass),
        totpSecret: totpSecretField(totp),
        services: accountServices(svc),
        note: note(text),
      };
      let quit = null;
      if (stopFirst === true) {
        requireThat(typeof this.platform.forceQuit === 'function', 'QUIT_FAILED', '无法退出 Claude，已停止保存。');
        quit = await this.platform.forceQuit();
      }
      await this.closed();
      const state = inspect(this.root); requireValid(state);
      requireThat(expectedUuid === state.uuid, 'IDENTITY_CHANGED', '当前账号与刚才界面显示的不一致，请刷新后重新确认。');
      const pending = this.pending();
      if (pending) {
        requireThat(pending.root === this.root && pending.id === id, 'WRONG_TARGET', '请保存到当前登录向导指定的账号。');
        if (pending.uuid) requireThat(state.uuid === pending.uuid, 'WRONG_ACCOUNT', '登录的不是要修复的账号，已拒绝覆盖。请取消恢复原账号，或在 Claude 中登录正确账号。');
        name = pending.name;
      }
      const account = this.persistAccount(label(name || this.getAccount(id).label), id, state, extraDetails);
      if (pending) fs.renameSync(this.p('pending.json'), this.p('login-completed-' + crypto.randomUUID() + '.json'));
      const prefix = !quit ? '账号已保存。' : quit.message === 'Claude 没有在运行。' ? 'Claude 没有在运行，账号已保存。' : '已退出 Claude 并结束后台进程，账号已保存。';
      return { message: prefix + '本地登录态检查通过，请打开 Claude 确认实际登录。', account: account.id };
    });
  }
  async beforeMutation(expectedUuid, { allowUnsaved = false, allowEmpty = false } = {}) {
    let state = inspect(this.root);
    requireThat((state.uuid || null) === (expectedUuid || null), 'IDENTITY_CHANGED', '当前账号已变化，请刷新后重试。');
    // A normal quit lets Claude finish writing its data; only leftovers after the timeout are killed.
    try { await this.platform.quit(); }
    catch (e) {
      if (e?.code !== 'QUIT_TIMEOUT' || typeof this.platform.forceQuit !== 'function') throw e;
      await this.platform.forceQuit();
    }
    await this.closed();
    state = inspect(this.root);
    requireThat((state.uuid || null) === (expectedUuid || null), 'IDENTITY_CHANGED', '退出后检测到账号变化，已停止操作。');
    const emptyLayout = allowEmpty && !state.uuid && !state.reasons.includes('AMBIGUOUS_COOKIES') && !state.reasons.includes('COOKIE_UNREADABLE');
    requireThat(state.compatible || emptyLayout, 'UNSUPPORTED_LAYOUT', '正常退出后仍无法识别当前数据格式，已停止修改。请导出诊断报告。');
    if (valid(state)) {
      const outgoing = this.accounts().find(a => a.uuid === state.uuid);
      if (outgoing) this.persistAccount(outgoing.label, outgoing.id, state);
      else requireThat(allowUnsaved, 'UNSAVED_ACCOUNT', '当前登录账号尚未保存。请先在账号列表上方保存这个账号，再切换。');
    }
    return state;
  }
  begin(kind, backup, extra = {}) {
    atomicJson(this.p('operation.json'), { format: 1, kind, root: this.root, backup, previousPending: this.pending(), ...extra });
  }
  finish() { fs.unlinkSync(this.p('operation.json')); }
  async switchAccount({ id, expectedUuid, allowUnsaved = false }, { beforeLaunch } = {}) {
    return this.exclusive(async () => {
      this.requireReady();
      const account = this.getAccount(id), target = this.snapshot(account.snapshot); requireValid(inspect(target.payload));
      requireThat(inspect(target.payload).uuid === account.uuid, 'WRONG_ACCOUNT', '目标备份的身份不一致，请先修复。');
      const live = await this.beforeMutation(expectedUuid, { allowUnsaved: Boolean(allowUnsaved), allowEmpty: true });
      if (valid(live) && live.uuid === account.uuid) {
        let carry;
        if (beforeLaunch) {
          try { carry = await beforeLaunch({sourceUuid:live.uuid,targetId:account.id}); }
          catch { carry = {code:'COPY_FAILED',copied:0,existing:0,missing:0,failed:0}; }
        }
        await this.platform.launch();
        return { message: '已经是所选账号。已更新保存并重新打开 Claude。', ...(carry?{carry}:{}) };
      }
      const backup = this.capture('before-switch'); this.begin('switch', backup);
      this.apply(account.snapshot); this.finish();
      // Trusted in-process hook only; API input cannot supply executable callbacks.
      let carry;
      if (beforeLaunch) {
        try { carry = await beforeLaunch({sourceUuid:live.uuid,targetId:account.id}); }
        catch { carry = {code:'COPY_FAILED',copied:0,existing:0,missing:0,failed:0}; }
      }
      await this.platform.launch();
      return { message: '已恢复目标账号并打开 Claude。请确认进入正确账号；如果显示未登录，请打开它的账号步骤，在第 5 步点「重新登录 Claude」。工具约 1 分钟后会再检查一次登录状态。', ...(carry?{carry}:{}) };
    });
  }
  async prepare({ id = null, name, expectedUuid }) {
    return this.exclusive(async () => {
      this.requireReady(); const account = id ? this.getAccount(id) : null;
      name = label(account?.label || name);
      if (!account) requireThat(!this.accounts().some(a => a.label.toLowerCase() === name.toLowerCase()), 'DUPLICATE_NAME', '名称已经存在。要重新登录已有账号，请打开它的账号步骤，在第 5 步点「重新登录 Claude」。');
      const state = await this.beforeMutation(expectedUuid, { allowUnsaved: !account });
      // Never clear an unrecognised data layout, even during repair.
      requireThat(state.compatible, 'UNSUPPORTED_LAYOUT', '无法识别当前 Claude 的存储格式，已保留原数据。请导出诊断报告。');
      const backup = this.capture('before-login'); this.begin('prepare-login', backup);
      atomicJson(this.p('pending.json'), { format: 1, root: this.root, id, name, uuid: account?.uuid || null, backup });
      this.apply(null); this.finish();
      await this.platform.launch();
      return { message: '已备份原账号并打开登录窗口。请手动登录目标账号，确认正常聊天后，回到这里点击“完成登录并保存”。工具会先退出 Claude 再保存，不要点“退出登录”。' };
    });
  }
  async cancel() {
    return this.exclusive(async () => {
      this.requireReady(true); const pending = this.pending();
      requireThat(pending && pending.root === this.root, 'NO_PENDING', '没有待取消的登录。');
      this.snapshot(pending.backup); await this.platform.quit(); await this.closed();
      const backup = this.capture('before-cancel'); this.begin('cancel-login', backup);
      this.apply(pending.backup);
      fs.renameSync(this.p('pending.json'), this.p('login-cancelled-' + crypto.randomUUID() + '.json'));
      this.finish(); await this.platform.launch();
      return { message: '已取消登录并恢复操作前的本地状态。' };
    });
  }
  async recover() {
    return this.exclusive(async () => {
      requireThat(this.recovery(), 'NO_RECOVERY', '没有中断的操作。');
      const operation = readJson(this.p('operation.json'));
      requireThat(operation.format === 1 && operation.root === this.root, 'BAD_RECOVERY', '恢复记录不匹配，请导出诊断报告。');
      this.snapshot(operation.backup); await this.platform.quit(); await this.closed();
      this.apply(operation.backup);
      if (operation.previousPending) atomicJson(this.p('pending.json'), operation.previousPending);
      else if (exists(this.p('pending.json'))) fs.renameSync(this.p('pending.json'), this.p('login-interrupted-' + crypto.randomUUID() + '.json'));
      this.finish();
      return { message: '已恢复中断操作之前的数据。可以打开 Claude 检查。' };
    });
  }
  async rebuildIndex() {
    return this.exclusive(async () => {
      this.requireReady(); await this.closed();
      const grouped = new Map();
      for (const id of fs.readdirSync(this.p('snapshots')).filter(isUuid)) {
        try {
          const snapshot = this.snapshot(id);
          if (snapshot.kind !== 'account') continue;
          const state = inspect(snapshot.payload); if (!valid(state)) continue;
          const previous = grouped.get(state.uuid);
          if (!previous || snapshot.created > previous.saved) grouped.set(state.uuid, { id: crypto.randomUUID(), uuid: state.uuid, snapshot: id, saved: snapshot.created });
        } catch {}
      }
      requireThat(grouped.size > 0, 'NO_GOOD_BACKUP', '没有找到可用于重建的完整账号备份，原索引已保留。请导出报告。');
      const previous = (() => { try { return this.accounts(); } catch { return []; } })();
      const all = [...grouped.values()].map((a,i) => { const old = previous.find(b => b.uuid === a.uuid); return { ...a, id: old?.id || a.id, label: old?.label || `恢复的账号 ${i+1}`, ...details(old) }; });
      if (exists(this.p('accounts.json'))) copy(this.p('accounts.json'), this.p('index-before-repair-' + crypto.randomUUID() + '.json'));
      atomicJson(this.p('accounts.json'), { format: 1, accounts: all });
      return { message: `已从完整快照重建 ${all.length} 个账号。请逐个核对账号；此操作未切换当前 Claude。` };
    });
  }
  status() {
    const live = inspect(this.root), all = this.accounts();
    const accounts = all.map(a => {
      let state;
      try { const snap = this.snapshot(a.snapshot); state = inspect(snap.payload); if (state.uuid !== a.uuid) state = { cookie: 'identity-mismatch' }; }
      catch { state = { cookie: 'damaged' }; }
      return { id: a.id, label: a.label, snapshot: a.snapshot, saved: a.saved, current: a.uuid === live.uuid, state: state.cookie, ...details(a) };
    });
    const pending = this.pending();
    return { version: VERSION, live, accounts, pending: pending ? { id: pending.id, name: pending.name } : null, recovery: this.recovery(), busy: this.busy };
  }
  report() {
    // Allowlist only. No raw errors, file paths, UUIDs, names, emails or log text.
    let status;
    try { status = this.status(); } catch (e) { return { version: VERSION, index: 'unreadable', code: e instanceof Problem ? e.code : 'READ_FAILED' }; }
    return { version: VERSION, created: new Date().toISOString(), platform: process.platform, architecture: process.arch,
      live: { compatible: status.live.compatible, cookie: status.live.cookie, layout: status.live.layout, identityPresent: !!status.live.uuid, reasons: status.live.reasons },
      accounts: status.accounts.map((a,i) => ({ number: i + 1, state: a.state })), pending: !!status.pending, interrupted: status.recovery,
      limits: ['Local metadata only; server validity and Keychain decryption are not verified.', 'No credentials or original logs included.'] };
  }
}
