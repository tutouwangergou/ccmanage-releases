import os from 'node:os';
import path from 'node:path';
import fs from 'node:fs';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';
import { execFile, execFileSync, spawn } from 'node:child_process';
import { Problem, requireThat, readJson, atomicJson, exists, safePath, isUuid } from './core.mjs';

// Google Chrome profiles: the list is read from Chrome's own Local State (read only, nothing else in
// Chrome's folder is touched). Each saved Claude account can be bound to one profile and carry what
// the user records about that Google account; that lives in the tool's store, keyed by account id.
// Chrome only creates "Default" and "Profile N" folders; anything else is never passed to Chrome.
const DIR = /^(Default|Profile [1-9]\d{0,4})$/;
export const isProfileDir = value => typeof value === 'string' && DIR.test(value);
const STATUS = ['ok', 'verify', 'disabled'];
// The two pages the buttons open in a profile, by key: by default an IP and environment check for
// using Claude, and the WebRTC Control extension's store page. The user may replace either address.
export const PAGES = {
  check: { url: 'https://ippure.com/claude.html', name: '检测页' },
  webrtc: { url: 'https://chromewebstore.google.com/detail/webrtc-control/fjkmabmdepjfammlpliljpnbhleegehm', name: '插件页' },
};
// Google account pages opened in a new profile by the add-account steps; fixed, not user editable.
const GOOGLE = {
  google: { url: 'https://accounts.google.com/', name: 'Google 登录页' },
  twoStep: { url: 'https://myaccount.google.com/signinoptions/two-step-verification', name: 'Google 两步验证设置' },
  devices: { url: 'https://myaccount.google.com/device-activity', name: 'Google 设备管理页' },
  password: { url: 'https://myaccount.google.com/signinoptions/password', name: 'Google 修改密码页' },
  recoveryEmail: { url: 'https://myaccount.google.com/recovery/email', name: 'Google 辅助邮箱设置' },
  recoveryPhone: { url: 'https://myaccount.google.com/signinoptions/rescuephone', name: 'Google 辅助手机号设置' },
};
// Opened before Antigravity starts, so the profile is Chrome's last used one: Antigravity's Google
// sign-in goes to the default browser, and Chrome opens it in that profile. Shows who is signed in.
const ACCOUNT_PAGE = 'https://myaccount.google.com/';
// An address handed to Chrome: http(s) only, so it can never read as a Chrome switch or run script.
function pageUrl(value, name = '') {
  if (value === undefined || value === null || value === '') return undefined;
  const raw = typeof value === 'string' ? value.trim() : '';
  let url;
  try { url = new URL(raw); } catch {}
  requireThat(raw.length <= 2048 && !/[\s\x00-\x1f\x7f]/.test(raw) && url && ['http:', 'https:'].includes(url.protocol) && url.hostname, 'BAD_URL', `${name}地址无效，请填写以 https:// 或 http:// 开头的完整网址。`);
  return url.href;
}
// Chrome's page for the current profile's name and picture.
const MANAGE_PROFILE = 'chrome://settings/manageProfile';
// Shown in the new window until Chrome is sent on to the settings page, and left there if it cannot be.
const RENAME_PAGE = `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><title>给 Chrome 资料改名</title>
<style>body{font:15px/1.7 -apple-system,"PingFang SC",sans-serif;max-width:560px;margin:72px auto;padding:0 20px;color:#222}input{width:100%;font:inherit;padding:6px 8px;box-sizing:border-box}@media(prefers-color-scheme:dark){body{background:#202124;color:#e8eaed}input{background:#303134;color:inherit;border:1px solid #5f6368}}</style>
<h2>正在打开这个资料的改名页面…</h2>
<p>如果几秒后还停在这里，可以手动改名：</p>
<ol><li>点窗口右上角的头像，再点「自定义个人资料」（或资料名旁边的铅笔）；</li><li>或者把下面的地址复制到地址栏后回车：</li></ol>
<input readonly value="${MANAGE_PROFILE}" onclick="this.select()">
<p>改好后回到 Claude 账号管理工具，列表会显示新名字。</p></html>
`;
const DENIED = 'macOS 没允许本工具控制 Chrome，没能跳到改名页面。请按窗口里的提示改名；想自动跳转，可到「系统设置 → 隐私与安全性 → 自动化」里允许本工具控制 Google Chrome。';
// profileName/profileEmail remember the bound profile as Chrome showed it, for when the list cannot be read.
// steps: the add-account steps, one per step: false, or when it was ticked (ms since 1970; true for
// ticks recorded before the time was kept). Some steps may only be done days after another one.
// The last step records whether the account can use Antigravity; 'unusable' marks one confirmed banned.
const FIELDS = ['profile', 'profileName', 'profileEmail', 'status', 'note', 'steps'];
export const STEP_COUNT = 10;
// Records kept from before steps were added are shorter; the window treats the new steps as unticked.
const isSteps = (value, saved = false) => Array.isArray(value) && (saved ? value.length >= 1 && value.length <= STEP_COUNT : value.length === STEP_COUNT) && value.every((v, i) => typeof v === 'boolean' || (Number.isSafeInteger(v) && v > 0) || (i === STEP_COUNT - 1 && v === 'unusable'));
const text = (value, max) => typeof value === 'string' ? value.trim().normalize('NFC').slice(0, max) : '';

function choice(value, list, code, message) {
  if (value === undefined || value === null || value === '') return undefined;
  requireThat(list.includes(value), code, message);
  return value;
}
// Free-text note about the Google account, shown in the Chrome view.
function note(value) {
  if (value === undefined || value === null) return undefined;
  const result = typeof value === 'string' ? value.trim().normalize('NFC') : null;
  if (result === '') return undefined;
  requireThat(result !== null && result.length <= 200 && !/[\x00-\x1f\x7f]/.test(result), 'BAD_NOTE', '备注最多 200 个字符，且不能换行。');
  return result;
}

// Records with each bound profile's name and address as Chrome lists them now, or null when nothing changed.
function remember(records, list) {
  let changed = false;
  const next = Object.fromEntries(Object.entries(records).map(([id, r]) => {
    const live = r.profile && list.find(p => p.dir === r.profile);
    if (!live || (r.profileName === live.name && (r.profileEmail || '') === live.email)) return [id, r];
    changed = true;
    const { profileEmail: _, ...rest } = r;
    return [id, { ...rest, profileName: live.name, ...(live.email ? { profileEmail: live.email } : {}) }];
  }));
  return changed ? next : null;
}

export class ChromeProfiles {
  constructor({ store, core, home = os.homedir(), applications = ['/Applications', path.join(home, 'Applications')], launch = launchChrome, redirect = redirectTab, running = chromeRunning, quit = quitChrome, startApp = launchAntigravity }) {
    Object.assign(this, { store: path.resolve(store), core, home, applications, launch, redirect, running, quit, startApp });
  }
  file() { return safePath(this.store, 'chrome-profiles.json'); }
  pagesFile() { return safePath(this.store, 'chrome-pages.json'); }
  // The address each button opens: the user's choice, or the default.
  pages() {
    let saved = {};
    if (exists(this.pagesFile())) {
      try { saved = readJson(this.pagesFile()); } catch { throw new Problem('PAGES_CORRUPT', 'Chrome 按钮地址设置损坏，请重新保存设置。'); }
      requireThat(saved?.format === 1 && Object.keys(saved).every(k => k === 'format' || Object.hasOwn(PAGES, k)), 'PAGES_CORRUPT', 'Chrome 按钮地址设置损坏，请重新保存设置。');
      const intact = value => { try { return typeof value === 'string' && pageUrl(value) === value; } catch { return false; } };
      for (const key of Object.keys(PAGES)) if (saved[key] !== undefined) requireThat(intact(saved[key]), 'PAGES_CORRUPT', 'Chrome 按钮地址设置损坏，请重新保存设置。');
    }
    return Object.fromEntries(Object.entries(PAGES).map(([key, page]) => [key, { url: saved[key] || page.url, custom: !!saved[key], default: page.url }]));
  }
  async savePages(values = {}) {
    return this.core.exclusive(() => {
      const next = { format: 1 };
      for (const [key, page] of Object.entries(PAGES)) {
        const url = pageUrl(values[key], page.name);
        if (url && url !== page.url) next[key] = url;
      }
      atomicJson(this.pagesFile(), next);
      return { message: '已保存两个按钮打开的地址。' };
    });
  }
  chromeApp() {
    return this.applications.map(dir => path.join(dir, 'Google Chrome.app')).find(exists) || null;
  }
  antigravityApp() {
    return this.applications.map(dir => path.join(dir, 'Antigravity.app')).find(exists) || null;
  }
  // Profiles Chrome knows about, sorted the way Chrome's own profile menu lists them. Null when the
  // list cannot be read; `denied` records whether macOS privacy protection refused it.
  chromeProfiles() {
    let local;
    this.denied = false;
    try { local = readJson(safePath(this.home, 'Library', 'Application Support', 'Google', 'Chrome', 'Local State')); }
    catch (e) { this.denied = e.code === 'EPERM' || e.code === 'EACCES'; return null; }
    // Chrome numbers new profiles from this counter and never reuses a number, even after a deletion.
    const created = local?.profile?.profiles_created;
    this.created = Number.isSafeInteger(created) && created > 0 ? created : 1;
    const cache = local?.profile?.info_cache;
    if (!cache || typeof cache !== 'object' || Array.isArray(cache)) return null;
    return Object.entries(cache).filter(([dir]) => isProfileDir(dir)).map(([dir, info]) => ({
      dir, name: text(info?.name, 80) || dir, email: text(info?.user_name, 254), fullName: text(info?.gaia_name, 80),
    })).sort((a, b) => a.name.localeCompare(b.name, 'en', { sensitivity: 'base' }));
  }
  records() {
    if (!exists(this.file())) return {};
    let data;
    try { data = readJson(this.file()); } catch { throw new Problem('PROFILES_CORRUPT', 'Chrome 资料记录损坏，已停止写入。请导出诊断报告。'); }
    requireThat(data?.format === 1 && data.accounts && typeof data.accounts === 'object' && !Array.isArray(data.accounts) && Object.keys(data.accounts).every(isUuid) && Object.values(data.accounts).every(r => r && typeof r === 'object' && (r.profile === undefined || isProfileDir(r.profile)) && ['profileName', 'profileEmail'].every(k => r[k] === undefined || (typeof r[k] === 'string' && r[k].length <= 254)) && (r.steps === undefined || isSteps(r.steps, true))), 'PROFILES_CORRUPT', 'Chrome 资料记录损坏，已停止写入。');
    return data.accounts;
  }
  // Chrome's profile list, plus the records of accounts that still exist. While the list is readable,
  // bound profiles' remembered names are kept current (skipped when another operation holds the lock).
  view() {
    const found = this.chromeProfiles(), ids = new Set(this.core.accounts().map(a => a.id));
    let records = this.records();
    const updated = found && remember(records, found);
    if (updated && !this.core.busy) { records = updated; Promise.resolve(this.core.exclusive(() => atomicJson(this.file(), { format: 1, accounts: updated }))).catch(() => {}); }
    const accounts = Object.fromEntries(Object.entries(records).filter(([id]) => ids.has(id)));
    let pages;
    // A damaged settings file still offers the defaults, so the settings dialog can overwrite it.
    try { pages = this.pages(); } catch (e) { pages = { ...Object.fromEntries(Object.entries(PAGES).map(([key, page]) => [key, { url: page.url, custom: false, default: page.url }])), error: e.code }; }
    return { installed: !!this.chromeApp(), readable: found !== null, denied: this.denied, profiles: found || [], accounts, pages };
  }
  // Binding a profile signed in to Google also records that address as the account's email when the
  // account has none yet, so the Chrome view need not repeat it.
  async edit({ id, profile, status, note: memo }) {
    let google = '';
    const result = await this.core.exclusive(() => {
      requireThat(isUuid(id) && this.core.accounts().some(a => a.id === id), 'ACCOUNT_MISSING', '找不到这个 Claude 账号，请刷新列表。');
      const records = this.records(), kept = records[id]?.profile === profile ? records[id] : {};
      let live;
      if (profile) {
        requireThat(isProfileDir(profile), 'BAD_PROFILE', 'Chrome 资料无效，请刷新列表。');
        live = (this.chromeProfiles() || []).find(p => p.dir === profile);
        // A profile Chrome no longer lists, or one bound before the list became unreadable, may stay bound but cannot be newly chosen.
        requireThat(live || kept.profile, 'PROFILE_MISSING', 'Chrome 里没有这个资料，请刷新列表。');
      }
      google = live?.email || '';
      const fields = {
        profile: profile || undefined,
        profileName: profile ? (live ? live.name : kept.profileName) : undefined,
        profileEmail: profile ? (live ? live.email || undefined : kept.profileEmail) : undefined,
        status: choice(status, STATUS, 'BAD_STATUS', 'Google 账号状态无效。'),
        note: note(memo),
        // Progress belongs to the Google account in the profile: kept while the binding stays, reset when it changes.
        steps: kept.steps,
      };
      const next = {};
      for (const [key, value] of Object.entries(records)) {
        if (key === id) continue;
        // A profile belongs to one Claude account: binding it here releases it from the other one.
        const { profile: bound, profileName: _name, profileEmail: _email, ...rest } = value, other = fields.profile && bound === fields.profile ? rest : value;
        if (Object.keys(other).length) next[key] = other;
      }
      const own = Object.fromEntries(FIELDS.filter(k => fields[k] !== undefined).map(k => [k, fields[k]]));
      if (Object.keys(own).length) next[id] = own;
      atomicJson(this.file(), { format: 1, accounts: next });
      return { message: '已保存 Chrome 资料绑定和 Google 账号信息。只保存在本机，不会写进诊断报告。' };
    });
    const account = this.core.accounts().find(a => a.id === id);
    if (!google || !account || account.email) return result;
    try { await this.core.edit({ id, name: account.label, activatedOn: account.activatedOn, organizationId: account.organizationId, email: google, note: account.note, group: account.group }); }
    catch { return result; }
    return { message: `已保存 Chrome 资料绑定，并把 Google 邮箱 ${google} 记为这个账号的邮箱。只保存在本机，不会写进诊断报告。` };
  }
  // Records which add-account steps are ticked for an account.
  async steps({ id, steps }) {
    return this.core.exclusive(() => {
      requireThat(isUuid(id) && this.core.accounts().some(a => a.id === id), 'ACCOUNT_MISSING', '找不到这个 Claude 账号，请刷新列表。');
      requireThat(isSteps(steps), 'BAD_STEPS', '步骤进度无效，请刷新后重试。');
      const records = this.records();
      atomicJson(this.file(), { format: 1, accounts: { ...records, [id]: { ...records[id], steps } } });
      return {};
    });
  }
  // The profile a button acts on: the one bound to account `id`, or an unbound profile `dir` that
  // Chrome currently lists (for a Google account with no Claude account yet).
  target({ id, dir: unbound }) {
    let dir, profile;
    if (id !== undefined) {
      requireThat(isUuid(id) && this.core.accounts().some(a => a.id === id), 'ACCOUNT_MISSING', '找不到这个 Claude 账号，请刷新列表。');
      dir = this.records()[id]?.profile;
      requireThat(dir, 'PROFILE_UNBOUND', '这个账号还没有绑定 Chrome 资料。');
      // Opening needs no access to Chrome's data: when the list is unreadable, trust the validated folder.
      const list = this.chromeProfiles();
      profile = list ? list.find(p => p.dir === dir) : { name: this.records()[id].profileName || dir };
      requireThat(profile, 'PROFILE_MISSING', 'Chrome 里已经没有绑定的资料，请重新绑定。');
    } else {
      requireThat(isProfileDir(unbound), 'BAD_PROFILE', 'Chrome 资料无效，请刷新列表。');
      dir = unbound; profile = (this.chromeProfiles() || []).find(p => p.dir === dir);
      requireThat(profile, 'PROFILE_MISSING', 'Chrome 里没有这个资料，请刷新列表。');
    }
    const app = this.chromeApp();
    requireThat(app, 'CHROME_NOT_FOUND', '没有找到 Google Chrome。请先把 Chrome 放入“应用程序”文件夹。');
    return { app, dir, profile };
  }
  // Opens one of the two pages in a new window of the profile.
  async open({ id, dir, page = 'check' }) {
    requireThat(Object.hasOwn(PAGES, page) || Object.hasOwn(GOOGLE, page), 'BAD_PAGE', '不支持打开这个页面。');
    const target = this.target({ id, dir }), fixed = Object.hasOwn(GOOGLE, page) ? GOOGLE[page] : null;
    this.launch(target.app, target.dir, fixed ? fixed.url : this.pages()[page].url);
    return { message: `已在 Chrome 资料“${target.profile.name}”中打开${fixed ? ' ' + fixed.name : PAGES[page].name}。` };
  }
  // Opens the profile in Chrome, then Antigravity, whose Google sign-in then opens in that profile.
  async antigravity({ id, dir }) {
    const target = this.target({ id, dir }), app = this.antigravityApp();
    requireThat(app, 'ANTIGRAVITY_NOT_FOUND', '没有找到 Antigravity。请先安装，并放入“应用程序”文件夹。');
    this.launch(target.app, target.dir, ACCOUNT_PAGE);
    await this.startApp(app);
    return { message: `已打开 Chrome 资料“${target.profile.name}”和 Antigravity。在 Antigravity 里点 Google 登录，登录页会在这个资料里打开。` };
  }
  // Opens Chrome's own page for renaming the profile. Chrome drops chrome:// addresses given on its
  // command line, so the window first opens a local help page tagged with a one-off mark, and Chrome
  // is then asked over Apple Events to send that tab (and only that tab) to the settings page.
  async rename({ id, dir }) {
    const target = this.target({ id, dir }), name = target.profile.name;
    const outcome = await this.redirect(this.launchMarked(target.app, target.dir), MANAGE_PROFILE);
    if (outcome === 'ok') return { message: `已在 Chrome 资料“${name}”中打开改名页面。改好后回到这里，列表会显示新名字。` };
    if (outcome === 'denied') return { message: `已打开 Chrome 资料“${name}”的窗口，但${DENIED}` };
    return { message: `已打开 Chrome 资料“${name}”的窗口，但没能跳到改名页面。请按窗口里的提示改名。` };
  }
  // Opens the help page in a window of the profile, tagged with a one-off mark; returns the mark.
  launchMarked(app, dir) {
    const mark = crypto.randomUUID(), page = safePath(this.store, 'chrome-rename.html');
    if (!exists(page) || fs.readFileSync(page, 'utf8') !== RENAME_PAGE) fs.writeFileSync(page, RENAME_PAGE, { mode: 0o600 });
    this.launch(app, dir, pathToFileURL(page).href + '#' + mark);
    return mark;
  }
  // Starts Chrome with a profile folder no profile uses yet; Chrome creates the profile and opens it.
  // Needs Chrome's list, so a folder in use is never picked. A running Chrome only opens profiles it
  // already has and silently drops the request, so it is first asked to quit when the user agrees.
  async create({ quitChrome: agreed = false } = {}) {
    const created = await this.core.exclusive(async () => {
      const app = this.chromeApp();
      requireThat(app, 'CHROME_NOT_FOUND', '没有找到 Google Chrome。请先把 Chrome 放入“应用程序”文件夹。');
      if (this.running(app)) {
        requireThat(agreed === true, 'CHROME_RUNNING', 'Chrome 正在运行。运行中的 Chrome 不会新建资料，需要先退出 Chrome。');
        await this.quit(app);
      }
      const list = this.chromeProfiles();
      requireThat(list, this.denied ? 'PROFILES_DENIED' : 'PROFILES_UNREADABLE', this.denied ? 'macOS 不允许本工具读取 Chrome 的资料列表，请到「系统设置 → 隐私与安全性 → 完全磁盘访问权限」打开「Claude 账号切换器」权限。' : '读不到 Chrome 的资料列表，无法确认哪个资料文件夹空着。请先打开一次 Chrome。');
      const used = [...list.map(p => p.dir), ...Object.values(this.records()).map(r => r.profile)].map(d => /^Profile (\d+)$/.exec(d || '')?.[1]).filter(Boolean).map(Number);
      // A deleted profile leaves Chrome's list at once, but Chrome ignores its folder from then on (and
      // the folder may linger), so start past Chrome's own counter and skip any folder still on disk.
      let number = Math.max(this.created, Math.max(0, ...used) + 1), dir = 'Profile ' + number;
      while (isProfileDir(dir) && exists(safePath(this.home, 'Library', 'Application Support', 'Google', 'Chrome', dir))) dir = 'Profile ' + ++number;
      requireThat(isProfileDir(dir), 'BAD_PROFILE', 'Chrome 资料数量过多，无法新建。');
      return { dir, mark: this.launchMarked(app, dir) };
    });
    // The new window goes straight to the rename page; Chrome starting from scratch may take a while.
    // Waiting happens outside the lock so the rest of the tool stays usable.
    const outcome = await this.redirect(created.mark, MANAGE_PROFILE, 30), dir = created.dir;
    if (outcome === 'ok') return { message: `已让 Chrome 新建资料（${dir}），并打开了它的改名页面。起好名字后在这个窗口登录 Google 账号。`, dir };
    if (outcome === 'denied') return { message: `已让 Chrome 新建资料（${dir}）并打开窗口，但${DENIED}`, dir };
    return { message: `已让 Chrome 新建资料（${dir}）并打开窗口，但没能跳到改名页面。请按窗口里的提示改名，再登录 Google 账号。`, dir };
  }
}

// `open -n` starts a second Chrome that hands the arguments to the running one, which then opens a
// window in that profile; without -n a running Chrome would ignore them.
export function launchChrome(app, dir, url) {
  requireThat(process.platform === 'darwin', 'MAC_ONLY', '此操作需要在 Mac 上进行。');
  try { requireThat(execFileSync('/usr/bin/plutil', ['-extract', 'CFBundleIdentifier', 'raw', '-o', '-', path.join(app, 'Contents', 'Info.plist')], { encoding: 'utf8', timeout: 5000 }).trim() === 'com.google.Chrome', 'UNKNOWN_CHROME', '这个 Chrome 应用标识不对，已停止打开。'); }
  catch (e) { throw e instanceof Problem ? e : new Problem('UNKNOWN_CHROME', '无法确认 Chrome 应用，已停止打开。'); }
  const child = spawn('/usr/bin/open', ['-na', app, '--args', '--profile-directory=' + dir, ...(url ? [url] : [])], { detached: true, stdio: 'ignore' });
  child.on('error', () => {}); child.unref();
}

// Starts Antigravity a moment after the Chrome window, so it comes up in front; a running one is brought forward.
export async function launchAntigravity(app) {
  requireThat(process.platform === 'darwin', 'MAC_ONLY', '此操作需要在 Mac 上进行。');
  try { requireThat(execFileSync('/usr/bin/plutil', ['-extract', 'CFBundleIdentifier', 'raw', '-o', '-', path.join(app, 'Contents', 'Info.plist')], { encoding: 'utf8', timeout: 5000 }).trim() === 'com.google.antigravity', 'UNKNOWN_ANTIGRAVITY', '这个 Antigravity 应用标识不对，已停止打开。'); }
  catch (e) { throw e instanceof Problem ? e : new Problem('UNKNOWN_ANTIGRAVITY', '无法确认 Antigravity 应用，已停止打开。'); }
  await new Promise(r => setTimeout(r, 1500));
  const child = spawn('/usr/bin/open', ['-a', app], { detached: true, stdio: 'ignore' });
  child.on('error', () => {}); child.unref();
}

// Asks Chrome over Apple Events to send the tab whose address carries `mark` to `url`, waiting up to
// `seconds` for the new window. 'ok', 'timeout', or 'denied' when macOS refuses the automation.
export function redirectTab(mark, url, seconds = 10) {
  const script = "function run(argv){var c=Application('com.google.Chrome');for(var i=0;i<Number(argv[2])*4;i++){try{var w=c.windows.tabs.url();for(var a=0;a<w.length;a++)for(var b=0;b<w[a].length;b++)if(String(w[a][b]).indexOf(argv[0])>=0){c.windows[a].tabs[b].url=argv[1];return 'ok';}}catch(e){if(e.errorNumber===-1743)return 'denied';}delay(0.25);}return 'timeout';}";
  return new Promise(resolve => execFile('/usr/bin/osascript', ['-l', 'JavaScript', '-e', script, mark, url, String(seconds)], { timeout: (seconds + 10) * 1000, encoding: 'utf8' }, (error, out) => {
    resolve(error ? (/-1743/.test(String(error.stderr || error.message)) ? 'denied' : 'timeout') : String(out).trim() === 'ok' ? 'ok' : String(out).trim() === 'denied' ? 'denied' : 'timeout');
  }));
}

// Whether this Chrome app is running: its main executable is in the process list.
export function chromeRunning(app) {
  const main = path.join(app, 'Contents', 'MacOS', 'Google Chrome');
  try { return execFileSync('/bin/ps', ['-axo', 'comm='], { encoding: 'utf8', timeout: 5000 }).split('\n').some(line => line.trim() === main); }
  catch { return false; }
}
// Asks Chrome to quit the normal way (as with ⌘Q) and waits for it to exit.
export async function quitChrome(app) {
  const script = "ObjC.import('AppKit'); function run(argv) { var list=$.NSRunningApplication.runningApplicationsWithBundleIdentifier('com.google.Chrome'); for(var i=0;i<list.count;i++){var a=list.objectAtIndex(i);if(ObjC.unwrap(a.bundleURL.path)===argv[0])a.terminate;} }";
  try { execFileSync('/usr/bin/osascript', ['-l', 'JavaScript', '-e', script, app], { stdio: 'ignore', timeout: 10000 }); } catch {}
  for (let i = 0; i < 40; i++) { if (!chromeRunning(app)) { await new Promise(r => setTimeout(r, 500)); return; } await new Promise(r => setTimeout(r, 500)); }
  throw new Problem('CHROME_QUIT_TIMEOUT', 'Chrome 还没有退出（可能正在询问是否关闭窗口或下载）。请手动退出 Chrome 后再点新建。');
}
