import fs from 'node:fs';
import path from 'node:path';
import { readJson, atomicJson, exists, isUuid, safePath } from './core.mjs';
import { readMacKeychainAll, macKey, openV10 } from './cloud.mjs';

export const seconds = () => Math.floor(Date.now() / 1000);
function percent(value) { return Number.isFinite(value) && value >= 0 && value <= 100 ? value : null; }

function planHistory(root) {
  const series = new Map();
  if (!root) return series;
  let data;
  try { data = readJson(path.join(root, 'plan-usage-history.json')); } catch { return series; }
  if (!Array.isArray(data?.samples)) return series;
  for (const sample of data.samples) {
    if (!isUuid(String(sample?.org || '')) || !Number.isFinite(sample.t)) continue;
    const at = sample.t > 1e12 ? Math.floor(sample.t / 1000) : Math.floor(sample.t);
    const key = String(sample.org).toLowerCase(), list = series.get(key) || [];
    list.push({ at, five: percent(sample.u?.fh), week: percent(sample.u?.sd) });
    series.set(key, list);
  }
  for (const list of series.values()) list.sort((a, b) => a.at - b.at);
  return series;
}

function latestPlan(series, org) {
  const rows = series.get(org) || [];
  for (let i = rows.length - 1; i >= 0; i--) if (rows[i].five != null || rows[i].week != null) return rows[i];
  return null;
}

const dropped = (prev, cur) => cur.value < prev.value;
function clean(points, now) { return points.filter(p => Number.isFinite(p?.at) && Number.isFinite(p?.value) && p.at <= now + 60).sort((a, b) => a.at - b.at); }

export function inferFiveHour(points, now, span = 5 * 3600) {
  const rows = clean(points, now), last = rows[rows.length - 1];
  if (!last || last.value <= 0) return null;
  let i = rows.length - 1;
  while (i > 0) {
    const prev = rows[i - 1], cur = rows[i];
    if (prev.value <= 0 || dropped(prev, cur) || cur.at - prev.at >= span) break;
    i--;
  }
  if (i === 0) return null;
  const from = Math.max(rows[i - 1].at + span, last.at), to = rows[i].at + span;
  return to > from ? { from, to } : null;
}

export function inferWeekly(points, now, span = 7 * 86400) {
  const rows = clean(points, now), last = rows[rows.length - 1], drops = [];
  for (let i = 1; i < rows.length; i++) {
    if (rows[i].at - rows[i - 1].at < span && dropped(rows[i - 1], rows[i])) drops.push([rows[i-1].at, rows[i].at]);
  }
  if (!drops.length) return null;
  let [from, to] = drops.pop();
  for (const [lo, hi] of drops.reverse()) {
    const n = Math.round((to - hi) / span), a = Math.max(from, lo + n * span), b = Math.min(to, hi + n * span);
    if (a >= b) break;
    from = a;
    to = b;
  }
  while (to <= last.at) { from += span; to += span; }
  return { from: Math.max(from, last.at), to };
}

function soleOrg(root, uuid) {
  if (!root || !isUuid(uuid)) return null;
  const base = path.join(root, 'claude-code-sessions', uuid);
  if (!exists(base)) return null;
  let orgs;
  try { orgs = fs.readdirSync(base, { withFileTypes: true }).filter(entry => entry.isDirectory() && isUuid(entry.name)); } catch { return null; }
  const populated = orgs.filter(org => {
    try { return fs.readdirSync(path.join(base, org.name)).some(name => /^local_(?:local_)?[a-zA-Z0-9-]+\.json$/.test(name)); } catch { return false; }
  });
  return populated.length === 1 ? populated[0].name.toLowerCase() : null;
}

export const USER_AGENT = 'claude-cli/2.1.280 (external, cli)';

export function extractDesktopToken(core, account, secrets, nowMs = Date.now()) {
  if (!secrets || !account) return null;
  const candidateSecrets = Array.isArray(secrets) ? secrets : [secrets];
  const roots = [];
  try {
    const liveCfg = safePath(core.root, 'config.json');
    if (exists(liveCfg)) {
      const cfg = readJson(liveCfg);
      if (cfg?.lastKnownAccountUuid?.toLowerCase() === account.uuid?.toLowerCase()) {
        roots.push(core.root);
      }
    }
  } catch {}
  try {
    if (account.snapshot) {
      const snapCfg = safePath(core.p('snapshots', account.snapshot, 'payload', 'config.json'));
      if (exists(snapCfg)) roots.push(path.dirname(snapCfg));
    }
  } catch {}

  for (const root of roots) {
    try {
      const cfg = readJson(safePath(root, 'config.json'));
      const encoded = cfg['oauth:tokenCacheV2'] || cfg['oauth:tokenCache'];
      if (typeof encoded !== 'string' || !encoded) continue;
      for (const secret of candidateSecrets) {
        if (!secret) continue;
        try {
          const keyBuf = macKey(secret);
          let cacheJson;
          try {
            const dec = openV10(Buffer.from(encoded, 'base64'), keyBuf);
            cacheJson = JSON.parse(dec.toString('utf8'));
          } finally {
            keyBuf.fill(0);
          }
          if (!cacheJson || typeof cacheJson !== 'object') continue;
          const candidates = [];
          for (const [k, v] of Object.entries(cacheJson)) {
            if (typeof v?.token === 'string' && v.token && Number.isFinite(v.expiresAt) && v.expiresAt > nowMs + 30000) {
              if (k.toLowerCase().includes(account.uuid?.toLowerCase() || '')) {
                candidates.push(v);
              } else if (k.includes('user:profile') || k.includes('user:inference')) {
                candidates.push(v);
              }
            }
          }
          if (candidates.length) {
            candidates.sort((a, b) => b.expiresAt - a.expiresAt);
            return { token: candidates[0].token, expiresAt: candidates[0].expiresAt };
          }
        } catch {}
      }
    } catch {}
  }
  return null;
}

export async function queryUsageApi(token, fetcher = fetch) {
  const res = await fetcher('https://api.anthropic.com/api/oauth/usage?cedar_ember=1&skip_spend=1', {
    headers: {
      Authorization: 'Bearer ' + token,
      'anthropic-beta': 'oauth-2025-04-20',
      'Content-Type': 'application/json',
      'User-Agent': USER_AGENT,
    },
    signal: AbortSignal.timeout(10000),
  });
  if (!res.ok) {
    const err = new Error(`HTTP ${res.status}`);
    err.status = res.status;
    throw err;
  }
  const data = await res.json();
  return {
    five_hour: {
      utilization: Number.isFinite(data.five_hour?.utilization) ? data.five_hour.utilization : null,
      resetsAt: data.five_hour?.resets_at ? Math.ceil(Date.parse(data.five_hour.resets_at) / 1000) : null,
    },
    seven_day: {
      utilization: Number.isFinite(data.seven_day?.utilization) ? data.seven_day.utilization : null,
      resetsAt: data.seven_day?.resets_at ? Math.ceil(Date.parse(data.seven_day.resets_at) / 1000) : null,
    },
    tier: data.cedar_ember?.event_props?.tier || null,
  };
}

const FRESH_FOR = 600;
const API_FRESH_FOR = 3600;
export const AUTO_REFRESH_INTERVAL = 60 * 60 * 1000;

export class Usage {
  constructor({ core, now = seconds, fetcher = fetch, readKeychain = readMacKeychainAll, onUpdate = null }) {
    Object.assign(this, { core, now, fetcher, readKeychain, onUpdate, cachedSecrets: null, _refreshing: false, _timer: null, _initTimer: null });
    this.file = core.p('usage.json');
  }
  cache() {
    try {
      const c = readJson(this.file);
      return c && typeof c === 'object' && !Array.isArray(c) ? c : {};
    } catch {
      return {};
    }
  }
  async getSecrets(forceRead = false) {
    if (!forceRead && Array.isArray(this.cachedSecrets) && this.cachedSecrets.length > 0) {
      return this.cachedSecrets;
    }
    try {
      const s = await this.readKeychain();
      const list = (Array.isArray(s) ? s : [s]).filter(Boolean);
      if (list.length > 0) this.cachedSecrets = list;
      return list;
    } catch {
      return this.cachedSecrets || [];
    }
  }
  async refresh({ force = false, id = null } = {}) {
    if (this._refreshing && !force && !id) {
      return { message: '额度正在后台刷新中。', updated: 0 };
    }
    this._refreshing = true;
    try {
      const accounts = id ? [this.core.getAccount(id)] : this.core.accounts();
      if (!accounts.length) return { message: '暂无已保存账号。', updated: 0 };
      let secrets = await this.getSecrets(force);
      let rereadKeychain = force;
      const now = this.now();
      const cache = this.cache();
      let updated = 0;
      for (const a of accounts) {
        const prev = cache[a.id];
        if (!force && prev?.checkedAt && now - prev.checkedAt < 60) continue;
        if (!force && prev?.rateLimitedUntil && now < prev.rateLimitedUntil) continue;
        let grant = extractDesktopToken(this.core, a, secrets, now * 1000);
        if (!grant && !rereadKeychain) {
          rereadKeychain = true;
          secrets = await this.getSecrets(true);
          grant = extractDesktopToken(this.core, a, secrets, now * 1000);
        }
        if (!grant) {
          if (prev) prev.stale = true;
          continue;
        }
        try {
          const quota = await queryUsageApi(grant.token, this.fetcher);
          cache[a.id] = {
            status: 'API',
            source: 'api',
            checkedAt: now,
            tier: quota.tier,
            five_hour: quota.five_hour,
            seven_day: quota.seven_day,
          };
          updated++;
        } catch (e) {
          if (prev) {
            prev.stale = true;
            if (e.status === 429) prev.rateLimitedUntil = now + 300;
          }
        }
      }
      if (updated > 0 || force) {
        atomicJson(this.file, cache);
        if (typeof this.onUpdate === 'function') {
          Promise.resolve().then(() => this.onUpdate(this.views(this.core.accounts()))).catch(() => {});
        }
      }
      return { message: `已完成额度刷新（更新 ${updated} 个账号）。`, updated };
    } finally {
      this._refreshing = false;
    }
  }
  startAutoRefresh(intervalMs = AUTO_REFRESH_INTERVAL) {
    this.stopAutoRefresh();
    this._initTimer = setTimeout(() => {
      this.refresh().catch(() => {});
    }, 1500);
    this._initTimer.unref?.();
    this._timer = setInterval(() => {
      if (this.core.busy) return;
      this.refresh().catch(() => {});
    }, intervalMs);
    this._timer.unref?.();
  }
  stopAutoRefresh() {
    if (this._initTimer) { clearTimeout(this._initTimer); this._initTimer = null; }
    if (this._timer) { clearInterval(this._timer); this._timer = null; }
  }
  views(accounts) {
    const now = this.now(), cache = this.cache(), history = planHistory(this.core.root);
    const meter = (utilization, observedAt, range) => ({
      utilization,
      observedAt,
      resetsAt: range?.to ?? null,
      resetsFrom: range?.from ?? null,
      resetSource: range ? 'inferred' : null,
    });
    return accounts.map(a => {
      const entry = cache[a.id];
      if (entry && entry.status === 'API' && entry.five_hour && entry.seven_day) {
        return {
          id: a.id,
          status: 'API',
          source: 'api',
          tier: entry.tier || null,
          checkedAt: entry.checkedAt || 0,
          stale: Boolean(now - (entry.checkedAt || 0) > API_FRESH_FOR),
          five_hour: {
            utilization: entry.five_hour.utilization,
            observedAt: entry.checkedAt || 0,
            resetsAt: entry.five_hour.resetsAt,
            resetSource: 'api',
          },
          seven_day: {
            utilization: entry.seven_day.utilization,
            observedAt: entry.checkedAt || 0,
            resetsAt: entry.seven_day.resetsAt,
            resetSource: 'api',
          },
        };
      }
      const org = soleOrg(this.core.root, a.uuid) || (isUuid(a.organizationId) ? a.organizationId.toLowerCase() : '');
      const rows = history.get(org) || [], plan = latestPlan(history, org);
      const desktop = plan && plan.at <= now + 60 ? plan : null;
      const five_hour = desktop?.five != null ? meter(desktop.five, desktop.at, inferFiveHour(rows.filter(r => r.five != null).map(r => ({ at: r.at, value: r.five })), now)) : null;
      const seven_day = desktop?.week != null ? meter(desktop.week, desktop.at, inferWeekly(rows.filter(r => r.week != null).map(r => ({ at: r.at, value: r.week })), now)) : null;
      return { id: a.id, status: desktop ? 'DESKTOP' : 'NONE', checkedAt: desktop?.at || 0, stale: Boolean(desktop) && now - desktop.at > FRESH_FOR, five_hour, seven_day };
    });
  }
}
