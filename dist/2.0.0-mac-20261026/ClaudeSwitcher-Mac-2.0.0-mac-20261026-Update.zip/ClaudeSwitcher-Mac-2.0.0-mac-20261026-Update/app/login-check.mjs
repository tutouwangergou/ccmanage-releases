import { atomicJson, readJson, inspect as inspectRoot } from './core.mjs';

// A server-side logout only shows once Claude opens with the restored profile. After a switch,
// re-read the live profile twice (read-only, cookies never decrypted) and flag the account when
// Claude has dropped its login or another account appeared. This is an indirect signal: if Claude
// keeps the old cookie while showing a login page, the check cannot tell.
const DELAYS = [60000, 180000];
const STATES = new Set(['CHECKING', 'OK', 'LOGGED_OUT', 'WRONG_ACCOUNT']);
export class LoginCheck {
  constructor({ core, inspect = inspectRoot, delays = DELAYS, timer = setTimeout, clear = clearTimeout, now = () => Math.floor(Date.now() / 1000) }) {
    Object.assign(this, { core, inspect, delays, timer, clear, now });
    this.file = core.p('login-check.json'); this.timers = []; this.results = {};
    try { const r = readJson(this.file); if (r && typeof r === 'object' && !Array.isArray(r)) this.results = r; } catch {}
  }
  persist() { atomicJson(this.file, this.results); }
  cancel() {
    for (const t of this.timers) this.clear(t);
    this.timers = [];
    for (const [id, r] of Object.entries(this.results)) if (r?.state === 'CHECKING') delete this.results[id];
  }
  schedule(id) {
    const account = this.core.getAccount(id);
    this.cancel();
    this.results[id] = { state: 'CHECKING', at: this.now() }; this.persist();
    this.delays.forEach((ms, i) => {
      const t = this.timer(() => { try { this.check(account, i === this.delays.length - 1); } catch {} }, ms);
      t?.unref?.(); this.timers.push(t);
    });
  }
  check(account, last) {
    if (this.results[account.id]?.state !== 'CHECKING') return;
    // Another operation owns the profile now; its own flow decides the outcome.
    if (this.core.busy || this.core.pending() || this.core.recovery()) { delete this.results[account.id]; this.persist(); this.cancel(); return; }
    const live = this.inspect(this.core.root);
    let state = null;
    if (live.uuid && live.uuid !== account.uuid) state = 'WRONG_ACCOUNT';
    else if (live.compatible && (live.cookie === 'missing' || live.cookie === 'expired')) state = 'LOGGED_OUT';
    if (state) { this.cancel(); this.results[account.id] = { state, at: this.now() }; this.persist(); return; }
    if (!last) return;
    // Unreadable or ambiguous on the final pass stays unknown instead of being reported as healthy.
    if (live.compatible && live.cookie === 'present' && live.uuid === account.uuid) this.results[account.id] = { state: 'OK', at: this.now() };
    else delete this.results[account.id];
    this.persist(); this.timers = [];
  }
  clearAccount(id) { if (id && this.results[id]) { delete this.results[id]; this.persist(); } }
  stop() { for (const t of this.timers) this.clear(t); this.timers = []; }
  view() {
    let ids; try { ids = new Set(this.core.accounts().map(a => a.id)); } catch { return {}; }
    return Object.fromEntries(Object.entries(this.results).filter(([id, r]) => ids.has(id) && STATES.has(r?.state))
      .map(([id, r]) => [id, { state: r.state, at: Number.isFinite(r.at) ? r.at : 0 }]));
  }
}
