'use strict';
const { contextBridge, ipcRenderer } = require('electron');
contextBridge.exposeInMainWorld('switcherDesktop',Object.freeze({quit:()=>ipcRenderer.invoke('switcher:quit'),exportReport:()=>ipcRenderer.invoke('switcher:report'),scanQr:()=>ipcRenderer.invoke('switcher:scan-qr'),
  update:Object.freeze({start:()=>ipcRenderer.invoke('switcher:update-start'),check:()=>ipcRenderer.invoke('switcher:update-check'),apply:()=>ipcRenderer.invoke('switcher:update-apply'),onChange:fn=>{ipcRenderer.on('switcher:update',(_event,state)=>fn(state));}})}));
