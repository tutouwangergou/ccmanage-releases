import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { VERSION } from './version.mjs';

export const ORIGIN='http://127.0.0.1:48763';
export class DesktopError extends Error { constructor(code){super(code);this.code=code;} }
export function validRuntime(state){return state&&Number.isInteger(state.pid)&&state.pid>0&&/^[a-f0-9]{64}$/.test(state.token)&&typeof state.version==='string';}
export class DesktopBackend {
  constructor({store,resources,fetcher=fetch,spawnProcess=spawn,wait=ms=>new Promise(r=>setTimeout(r,ms)),attempts=40}){
    Object.assign(this,{store,resources,fetcher,spawnProcess,wait,attempts});this.state=null;
  }
  readState(){try{return JSON.parse(fs.readFileSync(path.join(this.store,'runtime.json'),'utf8'));}catch{return null;}}
  async call(state,action){
    if(!validRuntime(state))throw new DesktopError('NO_BACKEND');
    const response=await this.fetcher(ORIGIN+'/api',{method:'POST',headers:{Origin:ORIGIN,'Content-Type':'application/json','X-Switcher-Token':state.token},body:JSON.stringify({action}),signal:AbortSignal.timeout(2500),redirect:'error'});
    let data;try{data=await response.json();}catch{throw new DesktopError('NO_BACKEND');}
    if(!response.ok||!data.ok)throw new DesktopError(data.code==='BUSY'?'BUSY':'NO_BACKEND');
    return data.result;
  }
  async probe(){
    const state=this.readState();if(!validRuntime(state))return null;
    let ping;try{ping=await this.call(state,'ping');}catch{return null;}
    if(ping.version!==VERSION||state.version!==VERSION)throw new DesktopError('VERSION_MISMATCH');
    this.state=state;return state;
  }
  async connect(){
    const current=await this.probe();if(current)return current;
    fs.mkdirSync(this.store,{recursive:true,mode:0o700});
    const log=fs.openSync(path.join(this.store,'startup.log'),'a',0o600);
    const env={...process.env};delete env.NODE_OPTIONS;delete env.ELECTRON_RUN_AS_NODE;
    let failed=false;
    try{
      const child=this.spawnProcess(path.join(this.resources,'runtime','node'),['--no-warnings',path.join(this.resources,'app','server.mjs'),'--background'],{detached:true,stdio:['ignore',log,log],env,windowsHide:true});
      child.on('error',()=>{failed=true;});child.unref();
    }finally{fs.closeSync(log);}
    for(let i=0;i<this.attempts&&!failed;i++){
      await this.wait(300);const state=await this.probe();if(state)return state;
    }
    throw new DesktopError('START_FAILED');
  }
  async quit(){
    const current=await this.probe();
    // An absent/unresponsive backend cannot be assumed stopped when its record remains.
    if(!current){if(this.readState())throw new DesktopError('NO_BACKEND');return;}
    await this.call(current,'quit');
    for(let i=0;i<30;i++){
      await this.wait(100);
      const next=this.readState();if(!next||next.pid!==current.pid||next.token!==current.token)return;
    }
    throw new DesktopError('STOP_PENDING');
  }
  async report(){const current=await this.probe();if(!current)throw new DesktopError('NO_BACKEND');return this.call(current,'report');}
}
