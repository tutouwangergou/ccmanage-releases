import net from 'node:net';
import { execFile } from 'node:child_process';
import { Problem, requireThat, readJson, atomicJson, exists, safePath } from './core.mjs';

// On by default (port 10808), can be changed or cleared: before the switcher quits or opens Claude, require the system HTTPS proxy to point at a local
// port that is listening, so Claude never starts without the proxy. Only 127.0.0.1 is contacted; the
// switcher itself still makes no network requests. Claude opened from the Dock is not covered.
const LOCAL = new Set(['127.0.0.1', 'localhost']);
// On until the user saves another port or clears it.
export const DEFAULT_PORT = 10808;
const CORRUPT = '「启动前检查代理」设置损坏，请重新设置端口。';
export function proxyMatches(text, port) {
  const value = key => String(text).match(new RegExp(`^\\s*${key}\\s*:\\s*(\\S+)\\s*$`, 'm'))?.[1];
  // A PAC script or automatic discovery takes precedence over the fixed proxy.
  return value('HTTPSEnable') === '1' && LOCAL.has(value('HTTPSProxy')) && Number(value('HTTPSPort')) === port
    && value('ProxyAutoConfigEnable') !== '1' && value('ProxyAutoDiscoveryEnable') !== '1';
}
export function readProxy() {
  return new Promise(resolve => execFile('/usr/sbin/scutil', ['--proxy'], { encoding: 'utf8', timeout: 5000, maxBuffer: 1 << 20 }, (error, stdout) => resolve(error ? '' : stdout)));
}
export function portListening(port, timeout = 1000) {
  return new Promise(resolve => {
    const socket = net.connect({ host: '127.0.0.1', port });
    const done = ok => { socket.destroy(); resolve(ok); };
    socket.setTimeout(timeout, () => done(false));
    socket.once('connect', () => done(true)).once('error', () => done(false));
  });
}
const validPort = port => Number.isInteger(port) && port >= 1 && port <= 65535;

export class LaunchGuard {
  constructor({ store, proxy = readProxy, listening = portListening }) { Object.assign(this, { store, proxy, listening }); }
  file() { return safePath(this.store, 'launch-guard.json'); }
  // The port to check, or null when the check is off.
  port() {
    if (!exists(this.file())) return DEFAULT_PORT;
    let saved; try { saved = readJson(this.file()); } catch { throw new Problem('GUARD_CORRUPT', CORRUPT); }
    requireThat(saved?.format === 1 && (saved.port === null || validPort(saved.port)), 'GUARD_CORRUPT', CORRUPT);
    return saved.port;
  }
  async state() {
    const port = this.port();
    if (port === null) return { port: null, ok: true };
    const [proxy, listening] = await Promise.all([this.proxy().then(text => proxyMatches(text, port)), this.listening(port)]);
    const reason = !proxy ? `系统代理没有指向 127.0.0.1:${port}（可能被关掉了）` : !listening ? `本机 ${port} 端口没有在监听（代理软件可能没开）` : '';
    return { port, ok: proxy && listening, proxy, listening, reason };
  }
  // before: nothing has changed yet; otherwise the local operation already finished and only the launch is held back.
  async check({ before = false } = {}) {
    const state = await this.state();
    requireThat(state.ok, 'PROXY_REQUIRED', before
      ? `${state.reason}。按「启动前检查代理」设置，这次没有切换账号，也没有关闭或打开 Claude。请在 v2rayN 里打开系统代理后重试；不需要这项检查时，点左下角「代理检查」把端口清空。`
      : `${state.reason}。本地操作已完成，但按「启动前检查代理」设置没有打开 Claude。请在 v2rayN 里打开系统代理后，再从「应用程序」打开 Claude。`);
  }
  async view() {
    try { const { port, ok, reason } = await this.state(); return { port, ok, reason: reason || '' }; }
    catch (e) { return { error: e instanceof Problem ? e.code : 'GUARD_UNREADABLE' }; }
  }
  save({ port = null } = {}) {
    requireThat(port === null || validPort(port), 'BAD_PORT', '请输入 1～65535 的端口，或留空关闭检查。');
    atomicJson(this.file(), { format: 1, port });
    return { message: port === null ? '已关闭启动前检查代理。' : `已开启启动前检查代理：切换账号或打开 Claude 前，系统代理必须指向 127.0.0.1:${port}。` };
  }
}
