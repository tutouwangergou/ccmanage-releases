import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFile, spawn } from 'node:child_process';
import { VERSION, RUNTIME } from './version.mjs';

// In-app updates. Only the window's main process goes online, to one fixed release repository and through
// the system proxy; the backend and the window page still make no network requests. latest.json carries a
// manifest signed with a key that never leaves the release machine, so a changed file, host or account
// cannot push code to users. The installer inside the downloaded package then builds and swaps the app.
export const RELEASES = 'https://github.com/tutouwangergou/ccmanage-releases/releases';
export const FEED = RELEASES + '/latest/download/latest.json';
export const PUBLIC_KEY = 'MCowBQYDK2VwAyEA+j5E20QC9Tb1XNdiaGRiWSpYdv5RkC2ddii3/Xh2GA0=';
export const STAGE = /^\.claude-switcher-install-[0-9a-f-]{36}\.app$/;
export class UpdateError extends Error { constructor(code, message) { super(message); this.code = code; } }
const fail = (code, message) => { throw new UpdateError(code, message); };
const OFFLINE = '无法连接更新服务器。请确认网络（必要时打开代理）后重试。';
const INTERRUPTED = '下载中断。请确认网络后点“重试”，会从断开处继续下载。';

export function versionParts(v) { return (String(v).match(/\d+/g) || []).map(Number); }
export function newer(candidate, current = VERSION) {
  const a = versionParts(candidate), b = versionParts(current);
  for (let i = 0; i < Math.max(a.length, b.length); i++) { const d = (a[i] ?? 0) - (b[i] ?? 0); if (d) return d > 0; }
  return false;
}
const NAME = /^[0-9A-Za-z][0-9A-Za-z._-]{0,79}$/;
const validPackage = p => Boolean(p && NAME.test(p.file) && p.file.endsWith('.zip') && Number.isSafeInteger(p.size) && p.size > 0 && p.size <= 1024 ** 3 && /^[a-f0-9]{64}$/.test(p.sha256));
export function readFeed(text, key = PUBLIC_KEY) {
  let outer, manifest, ok = false;
  try { outer = JSON.parse(text); } catch { fail('BAD_FEED', '更新信息格式错误。'); }
  if (typeof outer?.manifest !== 'string' || typeof outer.signature !== 'string') fail('BAD_FEED', '更新信息格式错误。');
  try { ok = crypto.verify(null, Buffer.from(outer.manifest, 'utf8'), crypto.createPublicKey({ key: Buffer.from(key, 'base64'), format: 'der', type: 'spki' }), Buffer.from(outer.signature, 'base64')); } catch {}
  if (!ok) fail('BAD_SIGNATURE', '更新信息的签名无效，已忽略这次更新。');
  try { manifest = JSON.parse(outer.manifest); } catch { fail('BAD_FEED', '更新信息格式错误。'); }
  const m = manifest;
  if (m?.product !== 'claude-switcher-mac' || !NAME.test(m.version) || typeof m.node !== 'string' || typeof m.electron !== 'string'
    || typeof (m.notes ?? '') !== 'string' || (m.notes ?? '').length > 4000 || !validPackage(m.packages?.update) || !validPackage(m.packages?.full)) fail('BAD_FEED', '更新信息格式错误。');
  return m;
}
// Same runtimes: only the application files are needed. Otherwise the complete package.
export function choosePackage(m, runtime = RUNTIME) {
  const kind = m.node === runtime.node && m.electron === runtime.electron ? 'update' : 'full';
  return { kind, ...m.packages[kind] };
}
export const packageUrl = (m, p) => `${RELEASES}/download/v${m.version}/${p.file}`;
function hashFile(file) {
  return new Promise((resolve, reject) => { const h = crypto.createHash('sha256'); fs.createReadStream(file).on('error', reject).on('data', d => h.update(d)).on('end', () => resolve(h.digest('hex'))); });
}
function runFile(file, args, options) {
  return new Promise((resolve, reject) => execFile(file, args, options, (error, stdout, stderr) => error ? reject(Object.assign(error, { stdout, stderr })) : resolve({ stdout, stderr })));
}
function cleanEnv() { const env = { ...process.env }; delete env.NODE_OPTIONS; delete env.ELECTRON_RUN_AS_NODE; return env; }
// The installer reports "CODE: message" on its first error line; anything else stays private.
function installerError(e) {
  const line = String(e?.stderr || '').split('\n').find(x => /^[A-Z_]+: /.test(x));
  return line ? new UpdateError(line.slice(0, line.indexOf(':')), line.slice(line.indexOf(':') + 2)) : new UpdateError('UPDATE_FAILED', '更新未完成，旧版本仍可正常使用。');
}
const problem = (e, code, message) => e instanceof UpdateError ? { code: e.code, message: e.message } : { code, message };

export class Updater {
  constructor({ store, resources, fetcher, run = runFile, spawnProcess = spawn, arch = process.arch, runtime = RUNTIME, key = PUBLIC_KEY, idle = 60000, onChange = () => {} }) {
    Object.assign(this, { store, resources, fetcher, run, spawnProcess, arch, runtime, key, idle, onChange });
    this.dir = path.join(store, 'updates'); this.release = null; this.state = { phase: 'idle', current: VERSION };
  }
  set(state) { this.state = { current: VERSION, ...state }; this.onChange(this.state); return this.state; }
  busy() { return ['checking', 'downloading', 'preparing', 'installing'].includes(this.state.phase); }
  offer(extra) { const { manifest: m, pkg } = this.release; return { version: m.version, notes: m.notes || '', kind: pkg.kind, size: pkg.size, ...extra }; }
  // What the previous update run left behind, reported once.
  takeResult() {
    const file = path.join(this.store, 'update-result.json'); let r = null;
    try { r = JSON.parse(fs.readFileSync(file, 'utf8')); } catch {}
    try { fs.unlinkSync(file); } catch {}
    if (r?.ok === true && r.version === VERSION) { fs.rmSync(this.dir, { recursive: true, force: true }); return { ok: true, version: VERSION }; }
    if (r?.ok === false) return { ok: false, code: String(r.code || 'UPDATE_FAILED').slice(0, 40), message: String(r.message || '更新未完成。').slice(0, 300) };
    return null;
  }
  async check() {
    if (this.busy()) return this.state;
    this.set({ phase: 'checking' });
    try {
      let response;
      try { response = await this.fetcher(FEED, { cache: 'no-store', signal: AbortSignal.timeout(20000) }); } catch { fail('NETWORK', OFFLINE); }
      // No release published yet.
      if (response.status === 404) return this.set({ phase: 'latest' });
      if (!response.ok) fail('NETWORK', OFFLINE);
      const text = await response.text();
      if (text.length > 65536) fail('BAD_FEED', '更新信息格式错误。');
      const manifest = readFeed(text, this.key);
      if (!newer(manifest.version)) return this.set({ phase: 'latest' });
      this.release = { manifest, pkg: choosePackage(manifest, this.runtime) };
      return this.set(this.offer({ phase: 'available' }));
    } catch (e) { this.release = null; return this.set({ phase: 'error', during: 'check', ...problem(e, 'NETWORK', OFFLINE) }); }
  }
  // Downloads, verifies and stages the new app. The installed app keeps running and is not changed.
  async apply() {
    if (this.busy() || !this.release) return null;
    const { manifest, pkg } = this.release;
    try {
      fs.mkdirSync(this.dir, { recursive: true, mode: 0o700 });
      // Keep only what this release can reuse, so a resumed download survives but old packages do not.
      for (const name of fs.readdirSync(this.dir)) if (![pkg.file, pkg.file + '.part', 'update.log'].includes(name)) fs.rmSync(path.join(this.dir, name), { recursive: true, force: true });
      const zip = path.join(this.dir, pkg.file);
      await this.download(packageUrl(manifest, pkg), zip, pkg, received => this.set(this.offer({ phase: 'downloading', received })));
      this.set(this.offer({ phase: 'preparing' }));
      const base = await this.extract(zip, manifest.version);
      const runner = pkg.kind === 'update' ? path.join(this.resources, 'runtime', 'node') : path.join(base, 'runtime', 'node-' + this.arch);
      const installer = path.join(base, 'installer.mjs');
      let stdout;
      try { ({ stdout } = await this.run(runner, ['--no-warnings', installer, '--stage'], { env: cleanEnv(), timeout: 600000, maxBuffer: 1 << 20, encoding: 'utf8' })); }
      catch (e) { throw installerError(e); }
      let stage;
      try { stage = JSON.parse(stdout.trim().split('\n').pop()).stage; } catch {}
      if (typeof stage !== 'string' || !STAGE.test(path.basename(stage))) fail('UPDATE_FAILED', '更新未完成，旧版本仍可正常使用。');
      return { stage, runner, installer };
    } catch (e) { this.set(this.offer({ phase: 'error', during: 'apply', ...problem(e, 'UPDATE_FAILED', '更新未完成，旧版本仍可正常使用。') })); return null; }
  }
  fail(prepared, code, message) { this.discard(prepared); this.set(this.offer({ phase: 'error', during: 'apply', code, message })); }
  discard(prepared) { if (prepared && STAGE.test(path.basename(prepared.stage))) fs.rmSync(prepared.stage, { recursive: true, force: true }); }
  // Starts the installer's last step detached, so it outlives this window: it waits for this process
  // to exit, swaps the apps and opens the new one.
  handOff({ stage, runner, installer }, pid = process.pid) {
    const log = fs.openSync(path.join(this.dir, 'update.log'), 'a', 0o600);
    try { this.spawnProcess(runner, ['--no-warnings', installer, '--publish', stage, String(pid)], { detached: true, stdio: ['ignore', log, log], env: cleanEnv() }).unref(); }
    finally { fs.closeSync(log); }
    this.set(this.offer({ phase: 'installing' }));
  }
  // Resumes a partial download where the server allows it; the file is used only if its hash matches.
  async download(url, file, pkg, progress) {
    if (fs.existsSync(file) && await hashFile(file) === pkg.sha256) return progress(pkg.size);
    fs.rmSync(file, { force: true });
    const part = file + '.part'; let have = 0;
    try { have = fs.statSync(part).size; } catch {}
    if (have >= pkg.size) { fs.rmSync(part, { force: true }); have = 0; }
    const controller = new AbortController(); let timer;
    const arm = () => { clearTimeout(timer); timer = setTimeout(() => controller.abort(), this.idle); };
    try {
      arm();
      let response;
      try { response = await this.fetcher(url, { headers: have ? { Range: `bytes=${have}-` } : {}, signal: controller.signal }); } catch { fail('NETWORK', OFFLINE); }
      const range = /^bytes (\d+)-/.exec(response.headers.get('content-range') || '');
      if (response.status === 200) have = 0;
      else if (!(response.status === 206 && have && Number(range?.[1]) === have)) { fs.rmSync(part, { force: true }); fail('NETWORK', `下载新版本失败（${response.status}）。请稍后重试。`); }
      const out = fs.openSync(part, have ? 'a' : 'w', 0o600);
      try {
        progress(have); let shown = 0;
        for await (const chunk of response.body) {
          arm(); have += chunk.length;
          if (have > pkg.size) { fs.rmSync(part, { force: true }); fail('BAD_DOWNLOAD', '下载的文件大小不对，已删除。请重试。'); }
          fs.writeSync(out, chunk);
          if (Date.now() - shown > 250) { shown = Date.now(); progress(have); }
        }
      } finally { fs.closeSync(out); }
    } catch (e) { throw e instanceof UpdateError ? e : new UpdateError('NETWORK', INTERRUPTED); }
    finally { clearTimeout(timer); }
    if (have !== pkg.size) fail('NETWORK', INTERRUPTED);
    if (await hashFile(part) !== pkg.sha256) { fs.rmSync(part, { force: true }); fail('BAD_DOWNLOAD', '下载的文件校验失败，已删除。请重试。'); }
    fs.renameSync(part, file); progress(pkg.size);
  }
  async extract(zip, version) {
    const target = path.join(this.dir, 'package-' + version);
    fs.rmSync(target, { recursive: true, force: true }); fs.mkdirSync(target, { mode: 0o700 });
    try { await this.run('/usr/bin/ditto', ['-x', '-k', zip, target], { timeout: 300000 }); } catch { fail('BAD_PACKAGE', '更新包无法解压，请重试。'); }
    const entries = fs.readdirSync(target, { withFileTypes: true }).filter(e => e.name !== '__MACOSX');
    if (entries.length !== 1 || !entries[0].isDirectory()) fail('BAD_PACKAGE', '更新包结构不正确。');
    return path.join(target, entries[0].name);
  }
}
