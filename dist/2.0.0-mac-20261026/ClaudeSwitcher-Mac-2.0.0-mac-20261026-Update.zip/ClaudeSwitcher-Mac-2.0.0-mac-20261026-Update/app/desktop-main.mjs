import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';
import { app, BrowserWindow, Menu, dialog, shell, ipcMain, screen, desktopCapturer, systemPreferences, net } from 'electron';
import { DesktopBackend } from './desktop-backend.mjs';
import { startDesktop } from './desktop-shell.mjs';
import { Updater } from './updater.mjs';

app.setName('Claude 账号管理工具');
app.setPath('userData',path.join(os.homedir(),'Library','Application Support','Claude Switcher Desktop'));
const here=path.dirname(fileURLToPath(import.meta.url)),resources=path.dirname(here),store=path.join(os.homedir(),'Library','Application Support','Claude Switcher');
const backend=new DesktopBackend({store,resources});
// Electron's network stack follows the system proxy settings, unlike Node's fetch.
const updater=new Updater({store,resources,fetcher:(url,options)=>net.fetch(url,options)});
startDesktop({app,BrowserWindow,Menu,dialog,shell,ipcMain,screen,desktopCapturer,systemPreferences,backend,updater,preload:path.join(here,'desktop-preload.cjs')}).catch(()=>{
  dialog.showErrorBox('Claude 账号管理工具','窗口启动失败。请用安装包中的“诊断与修复.command”检查。');app.exit(1);
});
