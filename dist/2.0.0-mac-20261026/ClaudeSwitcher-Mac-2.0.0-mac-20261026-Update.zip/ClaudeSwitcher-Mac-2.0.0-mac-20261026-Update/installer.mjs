import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import crypto from 'node:crypto';
import net from 'node:net';
import { execFileSync } from 'node:child_process';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { safePath, exists, mkdir, readJson, atomicJson, requireThat, Problem, VERSION } from './app/core.mjs';
import { MacServices } from './app/mac-services.mjs';
const here = path.dirname(fileURLToPath(import.meta.url));
export const APP_NAME = 'Claude 账号切换器.app';
export const OWNER = 'community.claude-switcher.mac.preview';
export const REQUIRED_FILES=['installer.mjs','app/core.mjs','app/chrome.mjs','app/version.mjs','app/platform.mjs','app/server.mjs','app/sessions.mjs','app/launch.mjs','app/usage.mjs','app/mac-services.mjs','app/carry.mjs','app/pool.mjs','app/login-check.mjs','app/launch-guard.mjs','app/cloud.mjs','app/desktop-main.mjs','app/desktop-shell.mjs','app/desktop-backend.mjs','app/desktop-preload.cjs','app/updater.mjs','app/package.json','app/web/index.html','app/web/ui.js','app/web/ui.css','assets/switcher.icns','runtime/node-arm64','runtime/node-x64','runtime/electron-arm64.zip','runtime/electron-x64.zip','LICENSE','runtime/NODE-LICENSE'];
// A complete package carries both runtimes. An update package carries only the application files and
// reuses the runtimes of the installed app, which must then be the versions it was built with.
export const UPDATE_FILES=REQUIRED_FILES.filter(name=>!/^runtime\/(node|electron)-/.test(name));
export function verifyPayload(base) {
  const manifest = readJson(safePath(base,'payload-manifest.json'));
  requireThat(manifest.version === VERSION && manifest.files && typeof manifest.files === 'object' && [undefined,'full','update'].includes(manifest.kind), 'BAD_PACKAGE', '安装包清单不匹配，请重新获取完整安装包。');
  for (const name of manifest.kind === 'update' ? UPDATE_FILES : REQUIRED_FILES) requireThat(typeof manifest.files[name] === 'string', 'BAD_PACKAGE','安装包缺少必要文件的校验记录。');
  for (const [name,expected] of Object.entries(manifest.files)) {
    requireThat(!path.isAbsolute(name) && !name.includes('\\') && !name.split('/').includes('..') && /^[a-f0-9]{64}$/.test(expected), 'BAD_PACKAGE','安装包清单格式错误。');
    const file = safePath(base,name);
    requireThat(fs.statSync(file).isFile() && crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex') === expected, 'PACKAGE_CHANGED','安装包文件不完整或被修改。请重新下载或向发送者索取完整包。');
  }
  return manifest;
}
export async function assertStopped(store, fetcher = fetch) {
  const runtime = safePath(store,'runtime.json');
  if (!exists(runtime)) return;
  const previous = readJson(runtime);
  requireThat(Number.isInteger(previous.pid) && previous.pid > 0,'BAD_RUNTIME','工具运行记录异常，请先重启 Mac 后再安装。');
  try { process.kill(previous.pid,0); throw new Problem('RUNNING','请先退出账号管理工具（按 ⌘Q 或关闭它的窗口），再安装、修复或卸载。'); }
  catch(e) { if(e instanceof Problem) throw e; requireThat(e.code === 'ESRCH','RUNNING','无法确认工具是否退出，请先关闭工具再试。'); }
}
export function ownedApp(target) {
  if (!exists(target)) return false;
  try { return readJson(safePath(target,'Contents','Resources','switcher-owner.json')).owner === OWNER; } catch { return false; }
}
function copyFile(source,destination,mode=0o600) { mkdir(path.dirname(destination));fs.copyFileSync(source,destination,fs.constants.COPYFILE_EXCL);fs.chmodSync(destination,mode); }
function hashFile(file) { return crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex'); }
// Copies the verified files into the bundle and records them. keepNode is the recorded hash of the
// runtime carried over from the app being updated.
function installFiles({base,manifest,resources,arch,keepNode}) {
  const installed = {};
  for (const file of Object.keys(manifest.files).filter(x=>x.startsWith('app/'))) {
    copyFile(safePath(base,file),safePath(resources,file)); installed[file]=manifest.files[file];
  }
  if (keepNode) installed['runtime/node']=keepNode;
  for (const [source,dest,mode] of [...(keepNode?[]:[['runtime/node-'+arch,'runtime/node',0o700]]),['runtime/NODE-LICENSE','runtime/NODE-LICENSE',0o600],['LICENSE','LICENSE',0o600]]) {
    copyFile(safePath(base,source),safePath(resources,dest),mode); installed[dest]=manifest.files[source];
  }
  copyFile(safePath(base,'assets','switcher.icns'),safePath(resources,'switcher.icns'));
  installed['switcher.icns']=manifest.files['assets/switcher.icns'];
  atomicJson(safePath(resources,'switcher-owner.json'),{owner:OWNER,version:VERSION,architecture:arch,node:manifest.node,electron:manifest.electron,files:installed});
  return installed;
}
export function buildInstalledApp({base,target,arch,extract}) {
  const manifest = verifyPayload(base);
  requireThat(['arm64','x64'].includes(arch),'CPU_UNSUPPORTED','此安装包支持 Apple Silicon 和 Intel 64 位 Mac。');
  requireThat(!exists(target),'DEST_EXISTS','暂存安装目录已存在，请重试。');
  mkdir(path.dirname(target));
  // Extract only the pinned, manifest-verified official Electron archive for this CPU.
  extract(safePath(base,'runtime','electron-'+arch+'.zip'),target);
  requireThat(exists(safePath(target,'Contents','MacOS','Electron')),'BAD_RUNTIME','桌面运行环境不完整，请重新解压安装包。');
  const resources = safePath(target,'Contents','Resources'); mkdir(resources);
  return installFiles({base,manifest,resources,arch});
}
export function bundledElectron(app){
  return execFileSync('/usr/bin/plutil',['-extract','CFBundleVersion','raw','-o','-',safePath(app,'Contents','Frameworks','Electron Framework.framework','Versions','A','Resources','Info.plist')],{encoding:'utf8',timeout:15000}).trim();
}
function cloneApp(source,target){execFileSync('/usr/bin/ditto',[source,target],{stdio:'pipe',timeout:300000});}
// Builds the new app from the installed one: same Electron and Node, new application files.
export function buildUpdatedApp({base,current,target,copy=cloneApp,nodeVersion=process.versions.node,electronVersion=bundledElectron}) {
  const manifest = verifyPayload(base);
  requireThat(manifest.kind==='update','BAD_PACKAGE','这不是更新包。');
  requireThat(ownedApp(current),'INSTALL_FIRST','没有找到已安装的切换器，请使用完整安装包安装。');
  const from=safePath(current,'Contents','Resources'),owner=readJson(safePath(from,'switcher-owner.json'));
  requireThat(['arm64','x64'].includes(owner.architecture)&&/^[a-f0-9]{64}$/.test(owner.files?.['runtime/node']||''),'REINSTALL_REQUIRED','已安装的应用记录不完整，请使用完整安装包重新安装。');
  requireThat(manifest.node===nodeVersion&&manifest.electron===electronVersion(current),'FULL_UPDATE_REQUIRED','这个版本需要新的运行环境，请使用完整安装包。');
  requireThat(hashFile(safePath(from,'runtime','node'))===owner.files['runtime/node'],'REINSTALL_REQUIRED','已安装文件不完整，请使用完整安装包重新安装。');
  requireThat(!exists(target),'DEST_EXISTS','暂存安装目录已存在，请重试。');
  mkdir(path.dirname(target));
  copy(current,target);
  const resources=safePath(target,'Contents','Resources');
  for (const name of ['app','switcher-owner.json','LICENSE','switcher.icns','runtime/NODE-LICENSE']) fs.rmSync(safePath(resources,name),{recursive:true,force:true});
  return installFiles({base,manifest,resources,arch:owner.architecture,keepNode:owner.files['runtime/node']});
}
export function extractElectron(archive,target){
  const temporary=safePath(target+'.unpack');requireThat(!exists(temporary),'DEST_EXISTS','运行环境暂存目录已存在。');mkdir(temporary);
  try{
    execFileSync('/usr/bin/ditto',['-x','-k',archive,temporary],{stdio:'pipe',timeout:120000});
    fs.renameSync(safePath(temporary,'Electron.app'),target);
    for(const file of ['LICENSE','LICENSES.chromium.html'])if(exists(safePath(temporary,file)))copyFile(safePath(temporary,file),safePath(target,'Contents','Resources','ELECTRON-'+file));
  }finally{fs.rmSync(temporary,{recursive:true,force:true});}
}
export function signInstalledApp(target){
  // Electron ships nested frameworks/helpers with signatures that may not
  // satisfy strict verification after the outer bundle is rebuilt. Re-sign
  // the complete bundle so every nested code object matches the final app.
  execFileSync('/usr/bin/codesign',['--force','--deep','--sign','-','--preserve-metadata=entitlements',target],{stdio:'pipe',timeout:60000});
  // An ad-hoc signature is otherwise identified by its content hash, so macOS privacy permissions
  // (Full Disk Access, needed to read Chrome's profile list) would be lost on every update. Sign the
  // outer app again with an explicit requirement naming only its identifier, so a permission granted
  // once carries over to later versions. Nested Electron helpers keep their own signatures.
  const id=execFileSync('/usr/bin/plutil',['-extract','CFBundleIdentifier','raw','-o','-',path.join(target,'Contents','Info.plist')],{encoding:'utf8',timeout:15000}).trim();
  requireThat(/^[A-Za-z0-9.-]+$/.test(id),'BAD_PACKAGE','应用标识无效，已停止安装。');
  execFileSync('/usr/bin/codesign',['--force','--sign','-','--preserve-metadata=entitlements','--requirements',`=designated => identifier "${id}"`,target],{stdio:'pipe',timeout:60000});
}
export function publishApp(stage,target) {
  safePath(stage);safePath(target);
  mkdir(path.dirname(target));
  if(exists(target))requireThat(ownedApp(target),'UNOWNED_APP','同名应用不是此工具创建的，已停止覆盖。请手动改名后再安装。');
  let previous=null;
  if(exists(target)){previous=target+'.previous-'+crypto.randomUUID();fs.renameSync(target,previous);}
  try{fs.renameSync(stage,target);}catch(e){if(previous&&!exists(target))fs.renameSync(previous,target);throw e;}
  return previous;
}
// macOS keeps listing every copy of the app in its app search, even renamed copies in the Trash, and
// registers them again whenever the new version is registered. A retired copy therefore goes to the
// Trash as a plain folder: no .app name, Info.plist and PkgInfo renamed, so it can no longer register.
// Account data never lives inside the app; renaming the two files back restores an old copy.
const RETIRED='Claude 账号切换器-旧版本-';
export function retireBundle(source,trash) {
  mkdir(trash);
  const target=safePath(trash,RETIRED+crypto.randomUUID());
  fs.renameSync(source,target);
  for(const name of ['Info.plist','PkgInfo']){try{fs.renameSync(safePath(target,'Contents',name),safePath(target,'Contents',name+'.retired'));}catch{}}
  return target;
}
export function retirePreviousApps(apps,trash) {
  const copies=fs.readdirSync(apps).filter(name=>name.startsWith(APP_NAME+'.previous-')&&ownedApp(safePath(apps,name)));
  for(const name of copies)retireBundle(safePath(apps,name),trash);
  return copies.length;
}
// Copies trashed by earlier versions are still bundles. The Trash usually cannot be listed without
// Full Disk Access, so find them through the LaunchServices registry instead.
const LSREGISTER='/System/Library/Frameworks/CoreServices.framework/Frameworks/LaunchServices.framework/Support/lsregister';
export function trashedRegistrations(dump,trash) {
  const prefix=trash+'/Claude 账号切换器',found=new Set();
  for(const line of dump.split('\n')){
    const m=/^path:\s+(.+?)(?: \(0x[0-9a-f]+\))?$/.exec(line);
    if(m&&m[1].startsWith(prefix)&&!m[1].slice(prefix.length).includes('/'))found.add(m[1]);
  }
  return [...found];
}
// Best effort: a failure only leaves an extra entry in the app search.
export function forgetTrashedApps(trash,run=execFileSync) {
  try{
    const paths=trashedRegistrations(run(LSREGISTER,['-dump'],{encoding:'utf8',maxBuffer:512*1024*1024,timeout:60000}),trash);
    let retired=0;
    for(const p of paths){
      try{run(LSREGISTER,['-u',p],{stdio:'pipe',timeout:30000});}catch{}
      try{if(ownedApp(p)){retireBundle(p,trash);retired++;}}catch{}
    }
    return retired;
  }catch{return 0;}
}
// Gives a built bundle this tool's identity and signs it. Nothing outside the bundle changes.
export function finishApp(stage) {
  // Update identity without invoking external build tools or changing security policy.
  const plist=safePath(stage,'Contents','Info.plist');
  for(const [key,value] of [['CFBundleIdentifier',OWNER],['CFBundleName','Claude 账号管理工具'],['CFBundleDisplayName','Claude 账号管理工具'],['CFBundleShortVersionString',VERSION.split('-')[0]],['CFBundleVersion',VERSION.split(/[.-]/).pop()],['CFBundleIconFile','switcher.icns'],['LSMinimumSystemVersion','13.0'],['NSAppleEventsUsageDescription','用于让 Chrome 打开某个资料的改名页面。']]){
    try{execFileSync('/usr/bin/plutil',['-remove',key,plist],{stdio:'pipe'});}catch{}
    execFileSync('/usr/bin/plutil',['-insert',key,'-string',value,plist],{stdio:'pipe'});
  }
  signInstalledApp(stage);
  execFileSync('/usr/bin/codesign',['--verify','--deep','--strict',stage],{stdio:'pipe',timeout:60000});
}
// Installation, upgrades and the running server share the same OS-owned lock.
async function lock() {
  const guard=net.createServer();
  try{await new Promise((resolve,reject)=>{guard.once('error',reject);guard.listen(48763,'127.0.0.1',resolve);});}
  catch{throw new Problem('RUNNING','工具仍在运行或端口被占用，请先退出工具再试。');}
  guard.unref();
  return ()=>new Promise(resolve=>guard.close(resolve));
}
function finishInstall(apps,home) {
  const retired=retirePreviousApps(apps,safePath(home,'.Trash'));
  forgetTrashedApps(safePath(home,'.Trash'));
  return retired;
}
async function removeOldStartup(home,store) {
  // Automatic switching was removed; drop the login item older versions may have created.
  try{await new MacServices({home,core:{p:(...parts)=>safePath(store,...parts)}}).removeStartup();return true;}catch{return false;}
}
const STAGE=/^\.claude-switcher-install-[0-9a-f-]{36}\.app$/;
// In-app update, step 1, run while the tool is still open: build and sign the new app next to the
// installed one. The installed app is not touched. Prints the staged app's path.
export function removeStaleStages(apps,now=Date.now()) {
  // A window closed while it was preparing leaves its staged app behind.
  for(const name of fs.readdirSync(apps).filter(n=>STAGE.test(n))){
    const stale=safePath(apps,name);
    try{if(now-fs.statSync(stale).mtimeMs>3600000)fs.rmSync(stale,{recursive:true,force:true});}catch{}
  }
}
function stageUpdate(apps,target) {
  const manifest=verifyPayload(here),stage=safePath(apps,'.claude-switcher-install-'+crypto.randomUUID()+'.app');
  mkdir(apps);removeStaleStages(apps);
  try{
    if(manifest.kind==='update')buildUpdatedApp({base:here,current:target,target:stage});
    else buildInstalledApp({base:here,target:stage,arch:process.arch,extract:extractElectron});
    finishApp(stage);
  }catch(e){fs.rmSync(stage,{recursive:true,force:true});throw e;}
  console.log(JSON.stringify({stage}));
}
export function alive(pid){try{process.kill(pid,0);return true;}catch(e){return e.code==='EPERM';}}
// Step 2, started by the window just before it quits: wait for it to exit, replace the app and open it
// again. On any failure the installed app stays as it was and opens again; it shows the result.
async function publishUpdate({home,apps,store,target,stage,pid}) {
  const result=safePath(store,'update-result.json');let release=null,valid=false,ok=false;
  try{
    valid=typeof stage==='string'&&path.dirname(stage)===apps&&STAGE.test(path.basename(stage));
    requireThat(valid&&ownedApp(stage),'BAD_STAGE','更新文件不完整，已停止更新。');
    requireThat(Number.isInteger(pid)&&pid>0,'BAD_MODE','更新参数无效。');
    for(let i=0;i<300&&alive(pid);i++)await new Promise(r=>setTimeout(r,200));
    requireThat(!alive(pid),'RUNNING','旧窗口没有退出，已停止更新。');
    await assertStopped(store);release=await lock();
    execFileSync('/usr/bin/codesign',['--verify','--deep','--strict',stage],{stdio:'pipe',timeout:60000});
    publishApp(stage,target);valid=false;
    atomicJson(result,{ok:true,version:VERSION});ok=true;
  }catch(e){
    if(valid)fs.rmSync(stage,{recursive:true,force:true});
    atomicJson(result,{ok:false,version:VERSION,code:e instanceof Problem?e.code:'UPDATE_FAILED',message:e instanceof Problem?e.message:'更新未完成。'});
  }finally{if(release)await release();}
  // The new backend needs the port the lock held, so the app opens only after it is released.
  // Tidying up after a swap takes a while (the app registry is scanned) and is best effort.
  if(ownedApp(target))execFileSync('/usr/bin/open',[target],{stdio:'pipe'});
  if(ok){try{finishInstall(apps,home);}catch{}await removeOldStartup(home,store);}
}
async function main() {
  requireThat(process.platform === 'darwin','MAC_ONLY','请在 Mac 上运行安装程序。');process.umask(0o077);
  const home=os.homedir(), apps=safePath(home,'Applications'), store=safePath(home,'Library','Application Support','Claude Switcher');
  const target=safePath(apps,APP_NAME), mode=process.argv[2] || '--install';
  if(mode==='--diagnose'){
    console.log('正在检查安装包与本机界面。不会清理 Claude 数据，也不会更改系统安全设置。');
    verifyPayload(here);
    requireThat(ownedApp(target),'INSTALL_FIRST','请先双击“安装.command”。');
    const resources=safePath(target,'Contents','Resources'),owner=readJson(safePath(resources,'switcher-owner.json'));
    requireThat(owner.version===VERSION,'UPGRADE_REQUIRED','已安装版本较旧。先退出旧工具（点“退出工具”或按 ⌘Q），再运行“安装.command”升级。');
    for(const [file,sha] of Object.entries(owner.files))requireThat(crypto.createHash('sha256').update(fs.readFileSync(safePath(resources,file))).digest('hex')===sha,'REINSTALL_REQUIRED','已安装文件不完整。请退出工具后运行“安装.command”重新安装，账号数据会保留。');
    execFileSync('/usr/bin/codesign',['--verify','--deep','--strict',target],{stdio:'pipe',timeout:30000});
    execFileSync(safePath(resources,'runtime','node'),['--version'],{stdio:'pipe',timeout:10000});
    console.log('安装文件、签名结构和后台运行环境已通过，正在打开独立窗口。');
    execFileSync('/usr/bin/open',[target],{stdio:'pipe'});return;
  }
  if(mode==='--stage')return stageUpdate(apps,target);
  if(mode==='--publish')return publishUpdate({home,apps,store,target,stage:process.argv[3],pid:Number(process.argv[4])});
  await assertStopped(store);
  const release=await lock();
  if(mode==='--uninstall'){
    requireThat(ownedApp(target),'UNOWNED_APP','没有找到此工具安装的应用。账号备份不会被删除。');
    const answer=execFileSync('/usr/bin/osascript',['-e','button returned of (display dialog "移除 Claude 账号切换器应用？账号快照和 Claude 数据都会保留。" buttons {"取消", "移到废纸篓"} default button "取消" with title "卸载切换器")'],{encoding:'utf8'}).trim();
    if(answer!=='移到废纸篓'){console.log('已取消。');await release();return;}
    const services=new MacServices({home,core:{p:(...parts)=>safePath(store,...parts)}});
    await services.removeStartup();
    const trash=safePath(home,'.Trash');
    try{execFileSync(LSREGISTER,['-u',target],{stdio:'pipe',timeout:30000});}catch{}
    retireBundle(target,trash);
    forgetTrashedApps(trash);
    console.log('应用已移到废纸篓。所有账号快照均已保留。');await release();return;
  }
  requireThat(mode==='--install','BAD_MODE','安装参数无效。');
  console.log('正在校验安装包，并安装独立窗口应用…');
  mkdir(apps); const stage=safePath(apps,'.claude-switcher-install-'+crypto.randomUUID()+'.app');
  try{
    buildInstalledApp({base:here,target:stage,arch:process.arch,extract:extractElectron});
    finishApp(stage);
  }catch(e){fs.rmSync(stage,{recursive:true,force:true});throw e;}
  publishApp(stage,target);
  const retired=finishInstall(apps,home);
  if(!(await removeOldStartup(home,store)))console.log('保留了一个无法确认来源的登录启动项，未作修改。');
  console.log('安装完成：访达 → 个人文件夹 → Applications → Claude 账号切换器。');
  if(retired)console.log('旧版本应用已移到废纸篓，账号数据没有被删除。');
  console.log('首次实机验证：请按使用说明完成 A → B → A，并确认不会再次要求登录。');
  await release();
  execFileSync('/usr/bin/open',[target],{stdio:'pipe'});
}
if(process.argv[1]&&import.meta.url===pathToFileURL(path.resolve(process.argv[1])).href)main().catch(e=>{console.error(e instanceof Problem?`${e.code}: ${e.message}`:'INSTALL_FAILED: 操作未完成，原有账号数据保留。请确认已退出工具，并重新解压完整安装包后重试。');process.exit(1);});
