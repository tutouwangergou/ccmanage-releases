'use strict';
const $ = id => document.getElementById(id);
const token = location.hash.slice(1) || sessionStorage.getItem('switcher-token');
if (location.hash) { sessionStorage.setItem('switcher-token',token); history.replaceState(null,'',location.pathname); }
let state, selected = null, polling=false;
// Accounts are re-saved whenever you switch away, so the save time is roughly when each was last used.
// Claude's login cookie lasts about four weeks without use; flag accounts after two.
const IDLE_DAYS=14;
function idleDays(a){return a.current?0:Math.max(0,Math.floor((Date.now()-Date.parse(a.saved))/86400000));}
const loginCheckText={LOGGED_OUT:'登录失效',WRONG_ACCOUNT:'账号不一致'};
let shownCheck=null,shownRevokedAt=sessionStorage.getItem('switcher-revoked-at')||null;
// Plans are paid monthly: expiry is one month after activation; a day past the next month's end clamps (1/31 → 2/28).
function expiryOf(a){
  if(!a.activatedOn)return null;
  const [y,m,d]=a.activatedOn.split('-').map(Number),target=m;
  return new Date(Date.UTC(y,target,Math.min(d,new Date(Date.UTC(y,target+1,0)).getUTCDate())));
}
function expiryInfo(a){
  const end=expiryOf(a);if(!end)return null;
  const now=new Date(),days=Math.round((end-Date.UTC(now.getFullYear(),now.getMonth(),now.getDate()))/86400000),date=end.toISOString().slice(0,10).replaceAll('-','/');
  return {date,days:days<0?`过期 ${-days} 天`:days===0?'今天到期':`剩 ${days} 天`,text:days<0?`已于 ${date} 到期`:days===0?`今天到期（${date}）`:`${date} 到期 · 剩 ${days} 天`,level:days<0?'danger':days<=3?'warn':''};
}
const hasCloud=()=>Boolean(state?.cloud);
const isLoggedIn=()=>!hasCloud()||Boolean(state.cloud.loggedIn);
const isAdmin=()=>!hasCloud()||state.cloud?.user?.role==='admin';
let activeTab='accounts';
const isManage=()=>isAdmin()&&activeTab==='accounts';
function isMyAccount(a){
  if(!hasCloud()||!isAdmin())return true;
  const synced=state.cloud?.syncedSnapshots?.[a.id]===a.snapshot;
  if(!synced)return true;
  const myId=String(state.cloud?.user?.id??'');
  return Boolean(myId)&&assignedOf(a).some(uid=>String(uid)===myId);
}
function visibleAccounts(){
  if(!state?.accounts)return [];
  return isManage()?state.accounts:state.accounts.filter(isMyAccount);
}
function unsavedCurrent(){return Boolean(state&&!state.pending&&state.live.compatible&&state.live.cookie==='present'&&state.live.uuid&&!state.accounts.some(a=>a.current));}
// Tell the user once when the post-switch check finds a dropped login.
function noticeLoginCheck(){
  for(const a of state.accounts){
    const c=state.loginCheck?.[a.id];if(!c||!loginCheckText[c.state])continue;
    const key=a.id+':'+c.at;if(shownCheck===key)return;shownCheck=key;
    message(c.state==='LOGGED_OUT'?`“${a.label}”的登录似乎已失效：Claude 打开后清除了登录信息。${isAdmin()?'请点它的红色标记打开账号步骤，在第 5 步点「重新登录 Claude」。':'请联系管理员更新快照后点「同步云端」。'}`:`切换到“${a.label}”后，Claude 里登录的却是另一个账号。${isAdmin()?'请点它的红色标记打开账号步骤，在第 5 步点「重新登录 Claude」，登录正确的账号。':'请联系管理员更新快照后点「同步云端」。'}`,true);return;
  }
}
const stateText = { present:'本地登录态已存', missing:'缺少登录态', expired:'本地登录态已过期', unreadable:'暂时无法读取', damaged:'快照校验失败', 'identity-mismatch':'账号身份不一致' };
async function api(action,args={}) {
  let response;
  try { response = await fetch('/api',{method:'POST',headers:{'Content-Type':'application/json','X-Switcher-Token':token || ''},body:JSON.stringify({action,args})}); }
  catch { throw new Error('与本机后台连接已断开，请关闭窗口后重新打开软件。'); }
  const body = await response.json(); if (!body.ok) { const e = new Error(body.error); e.code=body.code; throw e; } return body.result;
}
function message(text,error=false) { $('message').hidden=false; $('message').className=error?'error':''; $('message').textContent=text; }
function ask(text,input=false,initial=''){return new Promise(resolve=>{const dialog=$('confirm-dialog'),ok=$('confirm-ok'),close=$('confirm-cancel');$('confirm-text').textContent=text;$('confirm-input-label').hidden=!input;$('confirm-input').value=input?initial:'';ok.disabled=false;ok.textContent='确认';ok.classList.add('primary');close.disabled=false;dialog.returnValue='cancel';ok.onclick=()=>dialog.close('ok');close.onclick=()=>dialog.close('cancel');dialog.onclose=()=>resolve(dialog.returnValue==='ok'?(input?$('confirm-input').value:true):(input?null:false));dialog.showModal();if(input){$('confirm-input').focus();$('confirm-input').select();}else close.focus();});}
const confirmAction=text=>ask(text,false), promptName=(text,initial='')=>ask(text,true,initial);
const SERVICE_PRESETS=['Claude','Antigravity','Gemini','ChatGPT','Cursor','Copilot'];
function splitServices(val){return String(val||'').split(/[,，、;；]+/).map(s=>s.trim()).filter(Boolean);}
// A small dialog for one or two fields; resolves to their trimmed values by key, or null when cancelled.
// A field may carry a validate(value) returning a message, and a preview(value) shown under it.
function fieldDialog({title,sub='',note='',fields}){return new Promise(resolve=>{
  const dialog=$('field-dialog');let result=null,dlgTotpTimer=null;
  $('field-title').textContent=title;$('field-sub').textContent=sub;$('field-sub').hidden=!sub;$('field-note').textContent=note;$('field-note').hidden=!note;
  $('field-ok').disabled=false;$('field-cancel').disabled=false;
  const inputs=fields.map(f=>{
    const label=node('label'),input=document.createElement('input'),preview=node('p','','form-note expiry-preview');
    let updateTotpRight=null;
    if(f.key==='totpSecret'){
      const headRow=node('span');headRow.style.cssText='display:flex;align-items:center;justify-content:space-between;gap:8px;width:100%;flex-wrap:wrap';
      const leftSpan=node('span',f.label);if(f.hint){leftSpan.append(' ',node('span',f.hint,'hint'));}
      const rightSpan=node('span');rightSpan.style.cssText='display:inline-flex;align-items:center;gap:6px';
      const codeBadge=node('span','','badge good');codeBadge.hidden=true;codeBadge.style.cssText='font-family:ui-monospace,Menlo,monospace;font-size:12.5px;font-weight:700;padding:1px 8px';
      const copyCodeBtn=node('button','复制验证码','small');copyCodeBtn.type='button';copyCodeBtn.hidden=true;
      updateTotpRight=async()=>{
        const raw=input.value.trim();
        if(!raw){
          codeBadge.hidden=true;copyCodeBtn.hidden=true;
          return;
        }
        const key=totpSecret(raw);
        if(!key){codeBadge.hidden=false;codeBadge.className='badge danger';codeBadge.textContent='密钥格式不对';copyCodeBtn.hidden=true;return;}
        const now=Date.now(),secs=30-Math.floor(now/1000)%30;
        const code=await totpCode(key,now).catch(()=>null);
        if(!code){codeBadge.hidden=false;codeBadge.className='badge danger';codeBadge.textContent='无法生成';copyCodeBtn.hidden=true;return;}
        codeBadge.hidden=false;codeBadge.className='badge good';codeBadge.textContent=`${code} (${secs}s)`;
        copyCodeBtn.hidden=false;
        copyCodeBtn.onclick=()=>{const ok=copyText(code);copyCodeBtn.textContent=ok?'已复制':'复制失败';setTimeout(()=>{copyCodeBtn.textContent='复制验证码';},1400);};
      };
      rightSpan.append(codeBadge,copyCodeBtn);
      headRow.append(leftSpan,rightSpan);
      label.append(headRow);
      dlgTotpTimer=setInterval(()=>{if(dialog.open)updateTotpRight();},1000);
    }else{
      label.textContent=f.label;
      if(f.hint)label.append(node('span',f.hint,'hint'));
    }
    input.type=f.type||'text';input.value=f.value||'';input.autocomplete='off';input.spellcheck=false;
    for(const [k,v] of Object.entries(f.attrs||{}))input.setAttribute(k,v);
    let syncChips=null;
    if(Array.isArray(f.chips)&&f.chips.length){
      const chipWrap=node('div',undefined,'chip-list');
      const btns=f.chips.map(item=>{
        const b=node('button',item,'chip-btn');b.type='button';
        b.onclick=()=>{
          const cur=splitServices(input.value);
          const idx=cur.findIndex(x=>x.toLowerCase()===item.toLowerCase());
          if(idx>=0)cur.splice(idx,1);else cur.push(item);
          input.value=cur.join(', ');
          input.oninput();
        };
        chipWrap.append(b);
        return {item,b};
      });
      syncChips=()=>{
        const cur=splitServices(input.value).map(x=>x.toLowerCase());
        for(const {item,b} of btns)b.classList.toggle('active',cur.includes(item.toLowerCase()));
      };
      label.append(chipWrap);
    }
    const show=()=>{if(f.preview)preview.textContent=f.preview(input.value);if(syncChips)syncChips();if(updateTotpRight)updateTotpRight(false);};
    input.oninput=()=>{input.setCustomValidity('');show();};show();
    // Open the calendar on any click in a date field, not just the small icon.
    if(input.type==='date')input.onclick=()=>{try{input.showPicker();}catch{}};
    if(f.copy){
      // Copies what is in the box now, so an ID just pasted or edited can be copied too.
      const row=node('div',undefined,'copy-row'),copy=node('button','复制');copy.type='button';
      copy.onclick=()=>{const v=input.value.trim();if(!v){input.focus();return;}const ok=copyText(v);copy.textContent=ok?'已复制':'请手动选中复制';clearTimeout(copy.timer);copy.timer=setTimeout(()=>{copy.textContent='复制';},1600);};
      row.append(input,copy);label.append(row);
    }else label.append(input);
    return {f,input,nodes:f.preview?[label,preview]:[label]};
  });
  $('field-inputs').replaceChildren(...inputs.flatMap(x=>x.nodes));
  $('field-form').onsubmit=event=>{
    for(const {f,input} of inputs){const problem=f.validate?.(input.value.trim());if(problem)input.setCustomValidity(problem);}
    if(!$('field-form').reportValidity()){event.preventDefault();return;}
    result=Object.fromEntries(inputs.map(({f,input})=>[f.key,input.value.trim()]));
  };
  $('field-cancel').onclick=()=>dialog.close();
  dialog.onclose=()=>{if(dlgTotpTimer)clearInterval(dlgTotpTimer);resolve(result);};
  dialog.showModal();inputs[0].input.focus();if(inputs[0].input.type==='text')inputs[0].input.select();
});}
// Saving one detail sends the others unchanged; the email comes from the bound Chrome profile.
function accountFields(a){
  const p=boundProfile(a),google=p&&!p.missing?p.email:'',g=googleOf(a);
  const keys=totpKeys(),localTotp=(p?.dir&&keys[p.dir])||keys['acct:'+a.id]||'';
  const defaultServices=Array.isArray(g.steps)&&g.steps[9]&&g.steps[9]!=='unusable'?'Claude, Antigravity':'Claude';
  return {
    id:a.id,
    name:a.label,
    activatedOn:a.activatedOn||'',
    organizationId:a.organizationId||'',
    email:a.email||google||'',
    password:a.password||'',
    totpSecret:a.totpSecret||localTotp||'',
    services:a.services||defaultServices,
    note:a.note||g.note||'',
    group:groupOf(a)
  };
}
function syncLocalTotp(a,secret){
  if(!a)return;
  const keys=totpKeys(),clean=totpKey(secret)||String(secret||'').trim();
  const p=boundProfile(a),slots=[p?.dir,'acct:'+a.id].filter(Boolean);
  for(const s of slots){if(clean)keys[s]=clean;else delete keys[s];}
  totpStore(keys);
}
const chromeFields=a=>{const g=googleOf(a);return {id:a.id,profile:g.profile||'',status:g.status||'',note:g.note||a.note||''};};
const PRIVATE='保存在本机账号记录（本地修改备注仅在本机显示，不会覆盖云端备注），不会写进诊断报告。清空即删除。';
async function editName(a){
  const f=accountFields(a);
  const v=await fieldDialog({title:'“'+a.label+'”的账号信息',sub:f.email||'',note:PRIVATE,fields:[
    {key:'name',label:'账号名称',value:f.name,attrs:{maxlength:80},validate:v=>v?'':'请输入账号名称。'},
    {key:'email',label:'邮箱',hint:'选填',value:f.email,copy:true,attrs:{maxlength:254,placeholder:'example@gmail.com'},
      validate:v=>!v||/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)?'':'请输入有效的邮箱地址。'},
    {key:'password',label:'密码',hint:'选填',value:f.password,copy:true,attrs:{maxlength:200,placeholder:'登录密码'}},
    {key:'totpSecret',label:'2FA 密钥（Key）',hint:'选填，支持 Base32 密钥或 otpauth:// 链接',value:f.totpSecret,copy:true,attrs:{maxlength:200,placeholder:'例如：JBSWY3DPEHPK3PXP'}},
    {key:'note',label:'备注',hint:'选填，仅在本机显示（不覆盖云端）',value:f.note,attrs:{maxlength:200,placeholder:'例如：朋友代付，下月续费前确认'}},
    {key:'organizationId',label:'Organization ID',hint:'选填',value:f.organizationId,copy:true,attrs:{maxlength:36,placeholder:'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'},
      validate:v=>!v||/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v)?'':'格式应类似 xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'}]});
  if(v){syncLocalTotp(a,v.totpSecret);return api('edit',{...f,...v});}
}
async function editActivated(a){
  const v=await fieldDialog({title:'“'+a.label+'”的开通时间',note:PRIVATE,fields:[
    {key:'activatedOn',label:'开通时间',hint:'选填，按月付计算到期时间',type:'date',value:a.activatedOn||'',attrs:{min:'2020-01-01',max:'2100-12-31'},
      preview:v=>{const e=expiryInfo({activatedOn:v});return e?e.text:'';}}]});
  if(v)return api('edit',{...accountFields(a),...v});
}
async function editNote(a){
  const f=accountFields(a);
  const v=await fieldDialog({title:'“'+a.label+'”的账号信息与备注',note:PRIVATE,fields:[
    {key:'name',label:'账号名称',value:f.name,attrs:{maxlength:80},validate:v=>v?'':'请输入账号名称。'},
    {key:'email',label:'邮箱',hint:'选填',value:f.email,copy:true,attrs:{maxlength:254,placeholder:'example@gmail.com'},
      validate:v=>!v||/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)?'':'请输入有效的邮箱地址。'},
    {key:'password',label:'密码',hint:'选填',value:f.password,copy:true,attrs:{maxlength:200,placeholder:'登录密码'}},
    {key:'totpSecret',label:'2FA 密钥（Key）',hint:'选填，支持 Base32 密钥或 otpauth:// 链接',value:f.totpSecret,copy:true,attrs:{maxlength:200,placeholder:'例如：JBSWY3DPEHPK3PXP'}},
    {key:'note',label:'备注',hint:'选填，仅在本机显示（不覆盖云端）',value:f.note,attrs:{maxlength:200,placeholder:'例如：朋友代付，下月续费前确认'}},
    {key:'organizationId',label:'Organization ID',hint:'选填，同步到云端',value:f.organizationId,copy:true,attrs:{maxlength:36,placeholder:'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'},
      validate:v=>!v||/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v)?'':'格式应类似 xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'}]});
  if(v){syncLocalTotp(a,v.totpSecret);return api('edit',{...f,...v});}
}
async function editChromeNote(a){
  const v=await fieldDialog({title:'“'+a.label+'”的备注',note:'保存在本机备注（不会覆盖云端后台备注）。清空即删除。',fields:[
    {key:'note',label:'备注',hint:'选填，仅在本机显示（不覆盖云端）',value:googleOf(a).note||a.note||'',attrs:{maxlength:200,placeholder:'例如：谷歌被禁用了，Claude 还能用'}}]});
  if(v){
    await api('edit',{...accountFields(a),note:v.note});
    return api('profile-edit',{...chromeFields(a),...v});
  }
}
async function editBinding(a){
  const profile=await chromeDialog(a);
  if(profile!==null)return api('profile-edit',{...chromeFields(a),profile});
}
function syncAccountView(){
  const manage=isManage(), admin=isAdmin();
  $('accounts-heading').textContent=manage?'账号管理':'我的账号';
  $('add-account').hidden=!manage;
  $('cloud-push').hidden=!hasCloud();
  $('cloud-assign').hidden=!(hasCloud()&&manage);
  $('view-switch').hidden=!manage;
  const memberViewBtn=document.querySelector('[data-view="members"]');
  if(memberViewBtn)memberViewBtn.hidden=!hasCloud();
  if($('assign-filter'))$('assign-filter').hidden=!(hasCloud()&&manage&&view==='accounts');
  $('accounts-help').hidden=!manage;
  $('pending').hidden=!(manage&&state?.pending);
  $('unsaved').hidden=!unsavedCurrent();
  if($('save-and-push')) $('save-and-push').hidden=!hasCloud();
  $('account-list').classList.toggle('chrome-view',manage&&view==='profiles');
}
function tab(id,{renderNow=true}={}) {
  if(!isLoggedIn()){document.querySelectorAll('.panel').forEach(p=>p.hidden=p.id!=='login-screen');return;}
  if(!isAdmin())id='my-accounts';
  const prev=activeTab;activeTab=id;
  const panelId=id==='my-accounts'?'accounts':id;
  document.querySelectorAll('.panel').forEach(p=>p.hidden=p.id!==panelId);
  document.querySelectorAll('.sidebar nav [data-tab]').forEach(b=>b.classList.toggle('active',b.dataset.tab===id));
  syncAccountView();
  if(state&&prev!==id){
    const vis=visibleAccounts();
    if(!vis.some(a=>a.id===selected))selected=vis.find(a=>a.current)?.id||vis[0]?.id||null;
  }
  if(renderNow&&state&&panelId==='accounts'&&prev!==id)render();
  if(id==='my-accounts'&&hasCloud()&&prev!==id){
    api('cloud-pull').then(()=>refresh()).catch(()=>{});
  }
}
document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>tab(b.dataset.tab));
function node(tag,text,cls) { const n=document.createElement(tag); if(text!==undefined)n.textContent=text; if(cls)n.className=cls; return n; }
// Short relative day: 今天 / 明天 / 昨天, otherwise month/day.
function when(seconds){
  const d=new Date(seconds*1000),now=new Date(),start=new Date(now.getFullYear(),now.getMonth(),now.getDate()).getTime();
  const time=d.toLocaleTimeString('zh-CN',{hour:'2-digit',minute:'2-digit',hour12:false}),diff=Math.floor((d.getTime()-start)/86400000);
  return (diff===0?'今天':diff===1?'明天':diff===-1?'昨天':(d.getMonth()+1)+'/'+d.getDate())+' '+time;
}
// An inferred reset is only known to fall in (from,to]; show the latest time, so the quota is never
// shown as back before it can be. The hover tip gives the whole window when it is not narrow.
const ranged=w=>Number.isFinite(w?.resetsFrom)&&w.resetsAt-w.resetsFrom>15*60;
function resetText(w){return (w.resetSource==='inferred'?'约 ':'')+when(w.resetsAt);}
// One cell per quota window; the account row lays them out as table columns.
// Claude records usage only now and then (often hours apart), so a reading past an hour old gets its
// time in the hover tip, as the quota may well be lower by now; its colours stay as they are. A window
// counts as reset once the reading is older than the window itself.
const OLD_READING=3600;
function quotaCells(q){
  if(!q||q.status==='NONE')return [node('div','暂无本机用量记录','quota-empty')];
  const now=Date.now()/1000;
  return [['five_hour','5 小时',5*3600],['seven_day','本周',7*86400]].map(([key,title,span])=>{
    const w=q[key],cell=node('div',undefined,'meter');
    const pct=w&&Number.isFinite(w.utilization)?Number((100-w.utilization).toFixed(1)):null;
    const age=Number.isFinite(w?.observedAt)?now-w.observedAt:0,old=age>=OLD_READING;
    // A reading taken before its window reset says little about the quota now.
    const timed=Number.isFinite(w?.resetsAt),reset=timed?w.resetsAt<=now:age>=span;
    // Past the middle of the inferred window the refresh has likely happened: the tip says so, and
    // the time stays shown. The window's start is often the reading itself, so it cannot be the cue.
    const maybe=!reset&&ranged(w)&&now>(w.resetsFrom+w.resetsAt)/2;
    // The weekly refresh repeats at the same time, so a passed one still tells when the next comes.
    const shift=reset&&timed&&key==='seven_day'?(Math.floor((now-w.resetsAt)/span)+1)*span:0;
    const next=shift?{...w,resetsAt:w.resetsAt+shift,resetsFrom:Number.isFinite(w.resetsFrom)?w.resetsFrom+shift:null}:null;
    if(reset||pct==null)cell.classList.add('unknown');else if(pct===0)cell.classList.add('spent');else if(pct<20)cell.classList.add('low');
    const bar=node('div',undefined,'meter-bar'),fill=node('i');fill.style.width=(reset?0:pct??0)+'%';bar.append(fill);
    const head=node('div',undefined,'meter-head');head.append(node('span',title+'剩余','meter-label'),bar,node('b',pct==null||reset?'—':pct+'%'));
    const note=node('small',undefined,'meter-note'),between=v=>when(v.resetsFrom)+' 到 '+when(v.resetsAt);
    let tip='';
    if(next){note.textContent='下次'+resetText(next)+' 重置';tip='这条记录早于上次重置，额度应已恢复。'+(ranged(next)?'下次重置推算在 '+between(next)+' 之间':'');}
    // The shown time is the latest the refresh can be, so it stays true after passing: keep it until a new reading.
    else if(reset){note.textContent=timed?resetText(w)+' 已重置':'应已重置';if(ranged(w))tip='推算重置在 '+between(w)+' 之间，最晚这时已经重置，等 Claude 写入新记录后更新';}
    else if(maybe){note.textContent=resetText(w)+' 重置';tip='推算重置在 '+between(w)+' 之间，现在可能已经重置，这里的剩余额度可能已过时';}
    else if(key==='five_hour'&&w?.utilization===0&&!timed){
      // Unused at the time of a reading that may be hours old: say when, rather than claim a full quota.
      if(age>=1800){note.textContent='记录于'+when(w.observedAt)+'，当时未用';tip='Claude 最近一次记录用量是在'+when(w.observedAt)+'，当时这 5 小时还没用过。之后用了也要等 Claude 再写一次记录才会更新，以 Claude 设置里的「用量」为准';}
      else{note.textContent='满额，用了才开始计时';tip='记录时 5 小时窗口里还没有用量，额度是满的。Claude 从下次发消息时才开始这 5 小时的计时，之后这里会显示重置时间';}
    }
    else note.textContent=timed?resetText(w)+' 重置':'重置时间未知';
    note.title=tip||(ranged(w)?'Claude 不是每时每刻都记录用量，只能推算出重置在 '+between(w)+' 之间，这里显示最晚时间':note.textContent);
    if(old)note.title+='\n这是'+when(w.observedAt)+'的记录：Claude 不常写入用量，现在的剩余额度可能更少，以 Claude 设置里的「用量」为准';
    cell.append(head,note);return cell;
  });
}
function ago(seconds){
  const d=Math.max(0,Math.floor(Date.now()/1000-seconds));
  return d<60?'刚刚':d<3600?Math.floor(d/60)+' 分钟前':d<86400?Math.floor(d/3600)+' 小时前':when(seconds);
}
// Quota only comes from Claude desktop's local usage meter; the reading's age is in the hover tip.
function quotaStatus(q){
  if(!q||q.status==='NONE')return {text:'暂无本机用量记录：Claude 还没记录过这个账号的额度，切换过去打开一次 Claude 即可'};
  const src=q.status==='API'||q.source==='api'?'来自官方接口实时读数':'来自本机 Claude 用量记录';
  return {text:src+' · '+ago(q.checkedAt)+'记录'};
}
// Accounts without a stored group are in use.
const GROUPS=[['active','使用中'],['reserve','储备'],['retired','作废']];
const groupOf=a=>a.group||'active';
let dragging=null;
// Drop a dragged account row on another group to move it there.
function dropTarget(section,key){
  section.ondragover=event=>{if(!dragging||groupOf(dragging)===key)return;event.preventDefault();event.dataTransfer.dropEffect='move';section.classList.add('drop');};
  section.ondragleave=event=>{if(!section.contains(event.relatedTarget))section.classList.remove('drop');};
  section.ondrop=event=>{event.preventDefault();section.classList.remove('drop');const a=dragging;dragging=null;if(a&&groupOf(a)!==key)run(()=>api('group',{id:a.id,group:key}));};
}
// Shared by both views: the same account rows; the Chrome view swaps quota and expiry for the bound profile.
function accountRow(a){
  const manage=isManage(),q=state.usage?.find(q=>q.id===a.id),status=quotaStatus(q),chrome=manage&&view==='profiles';
  const row=node('label',undefined,'account'+(a.current?' current':'')), radio=document.createElement('input'); radio.type='radio'; radio.name='account'; radio.checked=a.id===selected;
  radio.onchange=()=>{selected=a.id;};
  row.draggable=manage;
  row.ondragstart=event=>{dragging=a;event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/plain',a.label);row.classList.add('dragging');document.body.classList.add('is-dragging');};
  row.ondragend=()=>{dragging=null;row.classList.remove('dragging');document.body.classList.remove('is-dragging');document.querySelectorAll('.group.drop').forEach(g=>g.classList.remove('drop'));};
  const title=node('div',undefined,'account-title'),name=node('div',undefined,'account-name');
  name.append(node('strong',a.label));
  if(q?.tier){
    const tierMap={'claude_max_5x':'Max 5x','claude_max_20x':'Max 20x','claude_max':'Max','claude_pro':'Pro','claude_team':'Team','claude_enterprise':'Enterprise'};
    const isMax=String(q.tier).includes('max');
    name.append(node('span',tierMap[q.tier]||q.tier,'badge badge-tier'+(isMax?' badge-tier-max':' badge-tier-pro')));
  }
  if(a.current)name.append(node('span','使用中','badge good'));
  if(a.state!=='present')name.append(manage?stepsBadge(a,stateText[a.state] || '待检查','badge'):node('span',stateText[a.state] || '待检查','badge'));
  // Idle warnings only matter for accounts you still plan to use.
  const idle=a.state==='present'&&groupOf(a)!=='retired'&&idleDays(a)>=IDLE_DAYS;
  if(idle)name.append(node('span','久未使用','badge'));
  const check=state.loginCheck?.[a.id];
  if(check&&loginCheckText[check.state])name.append(manage?stepsBadge(a,loginCheckText[check.state],'badge danger'):node('span',loginCheckText[check.state],'badge danger'));
  if(hasCloud()){
    const synced=state.cloud?.syncedSnapshots?.[a.id]===a.snapshot;
    if(!synced){
      const b=node('span','未上传','badge warn badge-link');
      b.title='该本机快照尚未上传到云端，点击立即上传到云端（也可选中后点上方「上传到云端」）';
      b.onclick=event=>{event.preventDefault();event.stopPropagation();selected=a.id;radio.checked=true;run(()=>pushAccountWithDetails(a));};
      name.append(b);
    }
    if(manage){
      const assigned=state.cloud?.assigned?.[a.id]||[];
      name.append(assignBadge(a,assigned));
    }
  }
  // Save time and quota source live in the hover tip.
  const expiry=expiryInfo(a),google=googleOf(a),profile=boundProfile(a);
  row.title=[a.note&&'备注：'+a.note,a.email,a.activatedOn&&'开通于 '+a.activatedOn.replaceAll('-','/'),expiry&&expiry.text,a.organizationId&&'Organization ID：'+a.organizationId,'保存于 '+when(Date.parse(a.saved)/1000),idle&&`已 ${idleDays(a)} 天未使用：登录约 4 周不用会过期，切换过去用一次即可续期`,status.text,
    profile&&'Chrome 资料：'+profile.name+(profile.email?'（'+profile.email+'）':''),google.note&&'Chrome 备注：'+google.note,manage&&'拖动可移到其他分组'].filter(Boolean).join('\n');
  title.append(name);
  if(a.email)title.append(node('small',a.email,'account-meta'));
  // Unify note display so notes written in either view appear in both views and get uploaded to cloud.
  const memo=chrome?(google.note||a.note):(a.note||google.note),note=node('div',memo||'—','account-note'+(memo?'':' none'));
  const expCell=node('div',undefined,'expiry'+(expiry?.level?' '+expiry.level:expiry?'':' none'));
  expCell.append(node('span',expiry?expiry.days:'—','expiry-pill'));
  const cells=chrome?chromeCells(a,profile):[...quotaCells(q),expCell];
  const pick=()=>{selected=a.id;radio.checked=true;};
  // The name fills most of the row, so in the accounts view a click there only selects; renaming is in the Chrome view.
  if(chrome&&manage){editable(title,'点击修改账号名称与信息',()=>editName(a),pick);editable(cells[0],'点击绑定 Chrome 资料',()=>editBinding(a),pick);editable(note,'点击修改 Chrome 备注',()=>editChromeNote(a),pick);}
  else if(manage){title.title='单击选中，双击切换；点击右侧备注可修改名称与账号信息';editable(cells.at(-1),'点击修改开通时间',()=>editActivated(a),pick);editable(note,'点击修改账号信息与备注',()=>editNote(a),pick);}
  else{title.title='单击选中，双击切换到这个账号；点击右侧备注可补充账号信息';editable(note,'点击修改账号信息与备注',()=>editNote(a),pick);}
  row.append(radio,title,...cells,note); row.ondblclick=()=>{clearTimeout(clickTimer);clickTimer=null;selected=a.id;switchSelected();};
  return row;
}
function assignedOf(a){return state?.cloud?.assigned?.[a.id]||[];}
function assigneeNameOf(a){
  const ids=assignedOf(a);if(!ids.length)return '';
  const u=(state?.cloud?.users||[]).find(x=>String(x.id)===String(ids[0]));
  return u?(u.name?`${u.name}`:u.username):`成员#${ids[0]}`;
}
function assignBadge(a,assigned){
  const hasAssignee=assigned.length>0,who=hasAssignee?assigneeNameOf(a):'';
  const badge=node('span',hasAssignee?`已分：${who}`:'未分配','badge badge-assign badge-link'+(hasAssignee?' assigned':''));
  badge.title=hasAssignee?`已分配给「${who}」；点击可收回该账号（收回后才能分给其他人）`:'当前空闲未分配；点击分配给一位成员';
  badge.onclick=event=>{event.preventDefault();event.stopPropagation();clearTimeout(clickTimer);clickTimer=null;selected=a.id;run(()=>assignAccount(a));};
  badge.ondblclick=event=>{event.preventDefault();event.stopPropagation();};
  return badge;
}
// A login problem badge opens the account's steps, where step 5 logs in again.
function stepsBadge(a,text,cls){
  const badge=node('span',text,cls+' badge-link');badge.title='点击打开账号步骤，在第 5 步重新登录 Claude';
  badge.onclick=event=>{event.preventDefault();event.stopPropagation();clearTimeout(clickTimer);clickTimer=null;selected=a.id;openSteps(a.id);};
  badge.ondblclick=event=>{event.preventDefault();event.stopPropagation();};
  return badge;
}
// A cell that opens its editor on a single click. The editor waits a moment so a double click on the
// row still switches to the account instead.
let clickTimer=null;
function editable(cell,hint,open,pick){
  cell.classList.add('cell-edit');cell.title=hint;
  cell.onclick=event=>{event.preventDefault();event.stopPropagation();pick();clearTimeout(clickTimer);clickTimer=setTimeout(()=>{clickTimer=null;run(open);},250);};
}

// View modes: 'accounts' (按账号), 'members' (按人员), 'profiles' (Chrome 资料)
let view=(()=>{try{const v=sessionStorage.getItem('switcher-view');return ['accounts','members','profiles'].includes(v)?v:'accounts';}catch{return 'accounts';}})();
let assignFilter='all';
function setView(next){
  view=next;try{sessionStorage.setItem('switcher-view',next);}catch{}
  document.querySelectorAll('[data-view]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.view===next)));
  $('account-list').classList.toggle('chrome-view',isManage()&&next==='profiles');
  if($('assign-filter'))$('assign-filter').hidden=!(hasCloud()&&isManage()&&next==='accounts');
  if(next==='members'&&hasCloud()&&isAdmin()&&!(state?.cloud?.users?.length)){
    api('cloud-users').then(()=>refresh()).catch(()=>{});
  }
  if(state)render();
}
document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>setView(b.dataset.view));
document.querySelectorAll('[data-assign-filter]').forEach(b=>b.onclick=()=>{
  assignFilter=b.dataset.assignFilter;
  document.querySelectorAll('[data-assign-filter]').forEach(x=>x.setAttribute('aria-pressed',String(x.dataset.assignFilter===assignFilter)));
  if(state)render();
});
const profiles=()=>state?.chrome?.profiles||[];
const googleOf=a=>state?.chrome?.accounts?.[a.id]||{};
// The bound profile. While Chrome's list cannot be read it is shown as remembered at binding time;
// one Chrome no longer lists stays visible as missing until it is rebound.
function boundProfile(a){
  const g=googleOf(a),dir=g.profile;if(!dir)return null;
  const live=profiles().find(p=>p.dir===dir);if(live)return live;
  const remembered={dir,name:g.profileName||dir,email:g.profileEmail||''};
  return state.chrome?.readable?{...remembered,missing:true}:remembered;
}
const takenBy=dir=>state.accounts.find(a=>googleOf(a).profile===dir);
// A free profile signed in to the account's Google address is the likely match.
function suggestedProfile(a){
  if(googleOf(a).profile||!a.email)return null;
  return profiles().find(p=>p.email&&p.email.toLowerCase()===a.email.toLowerCase()&&!takenBy(p.dir))||null;
}
// A running Chrome cannot create a profile: with the user's consent it is quit first.
async function createProfile(){
  try{return await api('profile-create');}
  catch(e){
    if(e.code!=='CHROME_RUNNING')throw e;
    if(!(await confirmAction('Chrome 正在运行，运行中的 Chrome 不会新建资料。\n要让工具先退出 Chrome（和按 ⌘Q 一样），再新建资料吗？\n没开启“继续浏览上次打开的网页”的话，退出前打开的标签页不会自动恢复。')))return;
    return api('profile-create',{quitChrome:true});
  }
}
// How far the account is through the add-account steps; opens its steps when clicked.
function progressCell(a,profile){
  const cell=node('div',undefined,'step-progress');
  const button=node('button',undefined,'step-button');button.type='button';
  button.onclick=event=>{event.preventDefault();event.stopPropagation();openSteps(a.id);};
  button.ondblclick=event=>{event.preventDefault();event.stopPropagation();};
  // Without a profile the steps still open, for step 5 (logging in to Claude again).
  if(!profile||profile.missing){button.append(node('span','—','faint'));button.title='点击查看账号步骤，第 5 步可重新登录 Claude';cell.append(button);return cell;}
  const done=stepsOf(a),count=done.filter(Boolean).length,next=nextStep(done);
  const until=waitUntil(done),dots=node('span',undefined,'step-dots');
  done.forEach((d,i)=>dots.append(node('i',String(i+1),d===UNUSABLE?'no':d?'on':isLater(i)&&until?'wait':'')));
  const line=node('span',undefined,'step-line');line.append(dots,node('span',count+'/'+done.length,'step-count'));
  // The next step, and when the waiting ones open, are in the hover tip rather than under the circles.
  const later=next!==null&&isLater(next)&&until&&until!==Infinity?'（建议 '+shortDate(until)+' 起再做）':'';
  button.append(line);
  button.title=(next===null?'全部完成':'下一步：'+WIZARD_STEPS[next].title+later)+'\n'+WIZARD_STEPS.map((s,i)=>(done[i]===UNUSABLE?'✗ ':done[i]?'✓ ':'○ ')+(i+1)+'. '+s.title+(i===ANTIGRAVITY&&done[i]?(done[i]===UNUSABLE?'：不可用':'：可用'):'')).join('\n')+'\n点击查看和继续这些步骤';
  cell.append(button);return cell;
}
function chromeCells(a,profile){
  const cell=node('div',undefined,'profile-cell');
  if(profile){
    const head=node('div',undefined,'account-name');head.append(node('strong',profile.name));
    if(profile.missing)head.append(node('span','Chrome 中已删除','badge warn'));
    // No email here: the account column shows it. Only a profile needing attention gets a second line.
    const meta=profile.missing?'请重新绑定':!profile.email?'未登录 Google':'';
    cell.append(head);if(meta)cell.append(node('small',meta,'account-meta'));
  }else{
    const hint=suggestedProfile(a);
    cell.append(hint?node('span','建议绑定 '+hint.name,'suggest'):node('span','未绑定','faint'));
  }
  return [cell,progressCell(a,profile)];
}
function chromeDialog(a){return new Promise(resolve=>{
  const dialog=$('profile-dialog'),select=$('profile-select'),current=boundProfile(a);let result=null;
  $('profile-ok').disabled=false;$('profile-cancel').disabled=false;
  $('profile-title').textContent='“'+a.label+'”的 Chrome 资料';$('profile-sub').textContent=a.email||'没有记录邮箱';
  select.replaceChildren(new Option('不绑定',''));
  const list=[...profiles()];if(current&&!list.some(p=>p.dir===current.dir))list.push(current);
  for(const p of list){
    const other=takenBy(p.dir),mine=other?.id===a.id;
    const tags=[p.missing&&'Chrome 中已删除',a.email&&p.email&&a.email.toLowerCase()===p.email.toLowerCase()&&'邮箱一致',other&&!mine&&'已绑定“'+other.label+'”，保存后改到这里'].filter(Boolean);
    select.append(new Option(p.name+(p.email?' · '+p.email:'')+(tags.length?'（'+tags.join('，')+'）':''),p.dir));
  }
  select.value=current?.dir||suggestedProfile(a)?.dir||'';
  $('profile-empty').hidden=profiles().length>0;
  $('profile-form').onsubmit=()=>{result=select.value;};
  $('profile-cancel').onclick=()=>dialog.close();
  dialog.onclose=()=>resolve(result);
  dialog.showModal();select.focus();
});}
// Add-account steps: each has an action and a tick the user sets once it is done, in order. Until the
// new account is saved, progress stays in this window's storage, so closing the dialog midway loses
// nothing; from then on it is saved with the account, shown in the Chrome view and opened from there.
const WIZARD='switcher-add-account';let wizardMemory=null,wizardAccount=null;
const blankWizard=()=>({done:Array(WIZARD_STEPS.length).fill(false)});
// An account's ticks; one never recorded has its profile bound (step 1) and is saved (step 5).
function stepsOf(a){
  const saved=googleOf(a).steps;
  // Ticks saved when there were fewer steps carry over; the new steps start unticked.
  if(Array.isArray(saved)&&saved.length&&saved.length<=WIZARD_STEPS.length)return WIZARD_STEPS.map((_,i)=>saved[i]||false);
  return WIZARD_STEPS.map((_,i)=>(i===0&&!!googleOf(a).profile)||i===4);
}
function wizard(){
  if(wizardAccount){
    const a=state.accounts.find(x=>x.id===wizardAccount),p=a&&boundProfile(a);
    return {account:wizardAccount,dir:p&&!p.missing?p.dir:'',name:a?.label||'',done:a?stepsOf(a):blankWizard().done};
  }
  if(wizardMemory)return wizardMemory;
  try{
    const w=JSON.parse(localStorage.getItem(WIZARD)||'null');
    // Progress saved when there were fewer steps carries over; the new steps start unticked.
    if(w&&Array.isArray(w.done)&&w.done.length<=WIZARD_STEPS.length){while(w.done.length<WIZARD_STEPS.length)w.done.push(false);return wizardMemory=w;}
  }catch{}
  return wizardMemory=blankWizard();
}
// Ticks of a saved account go to the tool's records; a new account's stay in this window.
async function saveWizard(w){
  if(w.account){await api('profile-steps',{id:w.account,steps:w.done});await refresh();return;}
  wizardMemory=w;try{localStorage.setItem(WIZARD,JSON.stringify(w));}catch{}
}
const wizardProfile=w=>w.dir?profiles().find(p=>p.dir===w.dir)||{dir:w.dir,name:w.dir}:null;
// Opens a page in the profile: the account's bound one, or the one the first step created.
const openIn=page=>w=>api('profile-open',w.account?{id:w.account,page}:{dir:w.dir,page});
// Each step lists its buttons as [label, action]; a saved account gets its own for steps 1 and 5.
// Only the desktop window can scan the screen; the preview page has no scan button.
// The scan button is hidden for now: screen recording needs a restart, and the window's storage does not
// survive one. Google's 「无法扫描？」 shows the secret as text, which is pasted into the 2FA box instead.
const scanQr=null;
const WIZARD_STEPS=[
  {title:'新建 Chrome 资料',text:'新建资料后会跳到改名页，起个好认的名字。',
    buttons:w=>w.account?[['打开改名页',w=>api('profile-rename',{id:w.account})]]:[['新建 Chrome 资料',async w=>{const r=await createProfile();if(r?.dir){w.dir=r.dir;await saveWizard(w);}return r;}]]},
  {title:'安装 WebRTC 插件',text:'打开 WebRTC Control 插件页，点「添加至 Chrome」。',buttons:()=>[['打开插件页',openIn('webrtc')]]},
  {title:'检测网络环境',text:'打开检测页，确认 IP 和环境正常。',buttons:()=>[['打开检测页',openIn('check')]]},
  {title:'登录 Google 账号',text:'在新资料里登录要用的 Google 账号。',buttons:()=>[['打开 Google 登录页',openIn('google')]]},
  // A saved account logs in again here when its login is lost or Claude shows another account.
  {title:'授权登录 Claude',text:w=>w.account?'登录失效或登错号时，点右边按钮重新登录同一个账号。':'用这个 Google 账号登录 Claude，能聊天后点「完成登录并保存」，自动绑定资料。',
    buttons:w=>{
      const mine=state?.pending&&(w.account?state.pending.id===w.account:state.pending.name===w.name);
      if(mine)return [['完成登录并保存',()=>finishLogin()]];
      if(w.account)return [['重新登录 Claude',w=>repairLogin(w.account)]];
      return [['登录 Claude',async w=>{
        const started=await startLogin(wizardProfile(w)?.name||'');if(!started)return;
        w.name=started.name;await saveWizard(w);return started.result;
      }]];
    }},
  {title:'修改两步验证（2FA）',text:()=>scanQr?'换成你自己的验证器并删掉原来的；出现二维码时点「扫码」保存 2FA。':'换成自己的验证器并删掉原来的；点二维码下的「无法扫描？」，把密钥贴到右上角。',
    buttons:()=>[['打开两步验证',openIn('twoStep')],...(scanQr?[['扫码',scanTotp]]:[])]},
  {title:'踢出 Google 其他设备',text:'退出除这台电脑以外的所有设备。',buttons:()=>[['打开设备管理',openIn('devices')]]},
  {title:'修改 Google 密码',text:'设一个新密码。',buttons:()=>[['打开修改密码',openIn('password')]]},
  {title:'修改 Google 辅助邮箱和手机号',text:'改成你自己的辅助邮箱和手机号。',buttons:()=>[['辅助邮箱',openIn('recoveryEmail')],['辅助手机号',openIn('recoveryPhone')]]},
  // Records whether this account can use Antigravity. Either answer completes the step; unticking clears it.
  {title:'确认反重力（Antigravity）是否可用',text:'用这个资料登录 Antigravity，试过后选可用或不可用。',
    buttons:()=>[['打开 Antigravity',w=>api('profile-antigravity',w.account?{id:w.account}:{dir:w.dir})]],
    choices:w=>[['可用',usable(w.done[ANTIGRAVITY]),()=>Date.now()],['不可用',w.done[ANTIGRAVITY]===UNUSABLE,()=>UNUSABLE]]},
];
// The last step's answer: a tick time when Antigravity works, UNUSABLE when it is banned.
const ANTIGRAVITY=WIZARD_STEPS.length-1,UNUSABLE='unusable';
const usable=d=>!!d&&d!==UNUSABLE;
// The next step to do, or null when all are ticked.
const nextStep=done=>{const i=done.findIndex(d=>!d);return i<0?null:i;};
// The first steps are done in order. Steps 7-9 are not locked, but are best left to the day after
// step 6; when Google refuses them that soon, they are tried again a week after step 6. Steps after
// those (Antigravity) only need the profile.
const ORDERED=6,LATER=9,RETRY_DAYS=7,DAY=864e5;
const isLater=i=>i>=ORDERED&&i<LATER;
const shortDate=t=>{const d=new Date(t);return (d.getMonth()+1)+'/'+d.getDate();};
const shortTime=t=>{const d=new Date(t);return shortDate(t)+' '+d.getHours()+':'+String(d.getMinutes()).padStart(2,'0');};
// When step 6 was ticked, or null (not ticked, or ticked before times were kept).
const sixthAt=done=>typeof done[ORDERED-1]==='number'?done[ORDERED-1]:null;
// When the last steps open: Infinity before step 6, 0 once open.
const waitUntil=done=>{
  if(!done[ORDERED-1])return Infinity;
  const t=sixthAt(done);if(!t)return 0;
  const next=new Date(t);next.setHours(24,0,0,0);
  return Date.now()<next.getTime()?next.getTime():0;
};
// While the last steps are open but within a week of step 6, Google may still refuse them; when to retry.
const retryFrom=done=>{const t=sixthAt(done);return t&&Date.now()<t+RETRY_DAYS*DAY?t+RETRY_DAYS*DAY:0;};
// Whether step i can be done now, and if not, why.
function stepBlock(w,i){
  // Logging a saved account in again needs neither its profile nor the earlier steps.
  if(w.account&&i===4)return '';
  if(i>0&&!w.dir)return '先在第 1 步新建 Chrome 资料';
  if(i<ORDERED){const k=w.done.slice(0,i).findIndex(d=>!d);return k<0?'':'先完成第 '+(k+1)+' 步';}
  return '';
}
// When a last step is best done: a hint only, the step stays open.
function stepHint(w,i){
  if(!isLater(i)||w.done[i])return '';
  const until=waitUntil(w.done);
  if(until===Infinity)return '建议第 '+ORDERED+' 步完成后第二天再做';
  if(until)return '建议 '+shortDate(until)+' 起再做';
  const retry=retryFrom(w.done);
  return retry?'做不了的话 '+shortDate(retry)+' 起再试':'';
}
function renderWizard(){
  const w=wizard(),list=$('add-steps'),profile=wizardProfile(w);list.replaceChildren();
  $('add-title').textContent=w.account?'“'+w.name+'”的账号步骤':'添加新账号';$('add-reset').hidden=!!w.account;
  WIZARD_STEPS.forEach((step,i)=>{
    const blocked=stepBlock(w,i);
    const item=node('li',undefined,w.done[i]===UNUSABLE?'done no':w.done[i]?'done':''),tick=document.createElement('input');
    // A tick records when it was set; a ticked step can always be unticked.
    tick.type='checkbox';tick.checked=!!w.done[i];tick.disabled=!!blocked&&!w.done[i];tick.setAttribute('aria-label','第 '+(i+1)+' 步已完成');
    if(tick.disabled)tick.title=blocked;
    tick.onchange=()=>{w.done[i]=tick.checked?Date.now():false;wizardRun(()=>saveWizard(w));};
    // What a step produced sits beside its title, so every step stays two lines high.
    const head=node('div',undefined,'wizard-head');head.append(node('strong',(i+1)+'. '+step.title));
    if(i===0&&profile)head.append(node('span',(w.account?'资料：':'已新建：')+profile.name+'（'+profile.dir+'）','wizard-profile'));
    if(i===4&&w.done[4]&&w.name)head.append(node('span','已保存“'+w.name+'”'+(w.dir?'并绑定':''),'wizard-profile'));
    if(i===ORDERED-1&&sixthAt(w.done))head.append(node('span','完成于 '+shortTime(sixthAt(w.done)),'wizard-profile'));
    // A last step says when it is best done, or, after that, when to try again if Google refuses it.
    const hint=stepHint(w,i);
    if(hint){const tip=node('span',hint,'wizard-wait');tip.title='第 '+ORDERED+' 步完成后第二天再做比较稳；当天 Google 不让改的话，等第 '+ORDERED+' 步完成 '+RETRY_DAYS+' 天后再试';head.append(tip);}
    if(i===4&&w.account&&state?.pending?.id===w.account)head.append(node('span','正在重新登录','wizard-wait'));
    const body=node('div');body.append(head,node('p',typeof step.text==='function'?step.text(w):step.text));
    const acts=node('div',undefined,'wizard-buttons');
    for(const [label,fn] of step.buttons(w)){const b=node('button',label,'small');b.type='button';b.disabled=!!blocked;if(blocked)b.title=blocked;b.onclick=()=>wizardRun(()=>fn(w));acts.append(b);}
    // A step that records an answer offers it as radio buttons before its buttons.
    if(step.choices){const group=node('div',undefined,'wizard-choices');group.setAttribute('role','radiogroup');group.setAttribute('aria-label',step.title);
      for(const [label,on,value] of step.choices(w)){const r=document.createElement('input'),l=node('label');r.type='radio';r.name='wizard-choice-'+i;r.checked=on;r.disabled=!!blocked;if(blocked)l.title=blocked;
        r.onchange=()=>{w.done[i]=value();wizardRun(()=>saveWizard(w));};l.append(r,label);group.append(l);}
      acts.prepend(group);}
    item.append(tick,body,acts);list.append(item);
  });
  const finished=w.done.every(Boolean);$('add-finished').hidden=!finished;$('add-reset').textContent=finished?'再添加一个账号':'重新开始';
  totpLoad();
}
// Runs a step through the usual runner, then shows its outcome inside the dialog.
async function wizardRun(fn){
  $('message').hidden=true;
  await run(fn);
  const shown=!$('message').hidden;$('add-status').hidden=!shown;
  if(shown){$('add-status').textContent=$('message').textContent;$('add-status').className='form-note'+($('message').className==='error'?' error':'');}
  renderWizard();
}
function openSteps(account=null){wizardAccount=account;totpSlot=undefined;$('add-status').hidden=true;renderWizard();$('add-dialog').showModal();}
$('add-account').onclick=()=>openSteps();
$('add-close').onclick=()=>$('add-dialog').close();
$('add-dialog').addEventListener('close',()=>{wizardAccount=null;});
// The window denies clipboard permissions, so copy through a hidden selection instead of navigator.clipboard.
function copyText(text){const t=document.createElement('textarea');t.value=text;t.setAttribute('readonly','');t.style.cssText='position:fixed;opacity:0';document.body.append(t);t.select();let ok=false;try{ok=document.execCommand('copy');}catch{}t.remove();return ok;}
for(const b of document.querySelectorAll('.copy-prompt'))b.onclick=()=>{const ok=copyText(b.previousElementSibling.textContent);b.textContent=ok?'已复制':'请手动选中复制';clearTimeout(b.timer);b.timer=setTimeout(()=>{b.textContent='复制';},1600);};
// --- totp begin (tests/totp.test.mjs evaluates this block) ---
// Google 2FA codes: RFC 6238 TOTP, SHA-1, 6 digits, 30 seconds.
// A key is kept as plain base32; an otpauth:// link contributes only its secret (its label holds the email).
function totpKey(text){
  let s=String(text||'').trim();
  if(/^otpauth:/i.test(s)){try{s=new URL(s).searchParams.get('secret')||'';}catch{return null;}}
  s=s.replace(/[\s-]/g,'').replace(/=+$/,'').toUpperCase();
  return s.length>=16&&/^[A-Z2-7]+$/.test(s)?s:null;
}
function totpSecret(text){
  const s=totpKey(text);if(!s)return null;
  let bits=0,value=0;const out=[];
  for(const c of s){value=value<<5|'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567'.indexOf(c);bits+=5;if(bits>=8){out.push(value>>>(bits-8)&255);bits-=8;}}
  return new Uint8Array(out);
}
async function totpCode(key,ms=Date.now()){
  const counter=Math.floor(ms/30000),msg=new Uint8Array(8);
  new DataView(msg.buffer).setUint32(0,Math.floor(counter/2**32));new DataView(msg.buffer).setUint32(4,counter>>>0);
  const k=await crypto.subtle.importKey('raw',key,{name:'HMAC',hash:'SHA-1'},false,['sign']);
  const h=new Uint8Array(await crypto.subtle.sign('HMAC',k,msg)),o=h[19]&15;
  return String(((h[o]&127)<<24|h[o+1]<<16|h[o+2]<<8|h[o+3])%1e6).padStart(6,'0');
}
// --- totp end ---
// Each Chrome profile's 2FA key is remembered in this window only, like a new account's step ticks:
// never sent to the backend or written into the diagnostic report. A key typed before step 1 made a
// profile waits under '' and moves to that profile once it exists. An account with no profile has no slot.
const TOTP='switcher-2fa';let totpTimer=null,totpRun=0,totpSlot;
function totpKeys(){try{const m=JSON.parse(localStorage.getItem(TOTP)||'{}');return m&&typeof m==='object'&&!Array.isArray(m)?m:{};}catch{return {};}}
function totpStore(keys){try{localStorage.setItem(TOTP,JSON.stringify(keys));}catch{}}
// Called on every render of the steps; fills the box only when the profile changes, so typing is never undone.
function totpLoad(){
  const w=wizard(),acc=w.account?state?.accounts.find(x=>x.id===w.account):null,slot=w.dir||(w.account?'acct:'+w.account:'');
  if(slot===totpSlot)return;
  const keys=totpKeys();
  if(slot&&keys['']&&!keys[slot]){keys[slot]=keys[''];delete keys[''];totpStore(keys);}
  if(slot&&acc?.totpSecret&&totpKey(acc.totpSecret)&&!keys[slot]){keys[slot]=totpKey(acc.totpSecret);totpStore(keys);}
  totpSlot=slot;$('totp-secret').value=slot===null?'':(keys[slot]||acc?.totpSecret||'');
  $('add-dialog').querySelector('.totp').title='密钥保存在本机并随快照同步到云端，验证码在本地实时计算；清空即删除。';
  showTotp();
}
async function showTotp(){
  const seq=++totpRun,key=totpSecret($('totp-secret').value),code=$('totp-code'),left=$('totp-left');
  clearTimeout(totpTimer);totpTimer=null;$('totp-copy').disabled=true;code.classList.remove('bad');left.textContent='';left.classList.remove('soon');
  if(!$('totp-secret').value.trim()){code.textContent='———';return;}
  if(!key){code.textContent='格式不对';code.classList.add('bad');return;}
  const now=Date.now(),secs=30-Math.floor(now/1000)%30;
  let text;try{text=await totpCode(key,now);}catch{text=null;}
  if(seq!==totpRun)return;
  if(!text){code.textContent='无法生成';code.classList.add('bad');return;}
  code.textContent=text;
  left.textContent=secs+' 秒';left.classList.toggle('soon',secs<=5);$('totp-copy').disabled=false;
  totpTimer=setTimeout(showTotp,1000-now%1000);
}
// A valid key is saved as typed; clearing the box deletes it; an unfinished key leaves the saved one alone.
$('totp-secret').oninput=()=>{
  showTotp();
  if(totpSlot===null||totpSlot===undefined)return;
  const value=$('totp-secret').value,key=totpKey(value),keys=totpKeys();
  if(key)keys[totpSlot]=key;else if(!value.trim())delete keys[totpSlot];else return;
  totpStore(keys);
};
// Step 6 scans the 2FA QR code Google shows on screen; the main process hands back only the otpauth link,
// and the box keeps just its secret, never the email in its label.
async function scanTotp(){
  const result=await scanQr().catch(()=>({ok:false,code:'FAILED'})),key=result?.ok?totpKey(result.url):null;
  if(key){$('totp-secret').value=key;$('totp-secret').oninput();return {message:totpSlot===null?'已识别二维码并填入右上角。这个账号没绑定 Chrome 资料，密钥不会保存。':'已识别二维码，2FA 密钥已保存到右上角，可直接复制验证码。'};}
  throw new Error({PERMISSION:'需要先允许“录屏”权限，开启后退出并重新打开本工具再点“扫码”。',NONE:'没在屏幕上找到 2FA 二维码。请让二维码完整显示在屏幕上（窗口不要最小化）再点“扫码”。',BUSY:'正在识别，请稍候。'}[result?.code]||'识别失败，请重试，或手动粘贴密钥。');
}
$('totp-copy').onclick=()=>{const b=$('totp-copy'),ok=copyText($('totp-code').textContent);b.textContent=ok?'已复制':'请手动选中复制';clearTimeout(b.timer);b.timer=setTimeout(()=>{b.textContent='复制';},1600);};
// Closing stops the countdown; opening fills the box again for whichever profile it shows.
// The close event arrives a moment later, so a dialog already reopened is left alone.
$('add-dialog').addEventListener('close',()=>{if($('add-dialog').open)return;clearTimeout(totpTimer);totpTimer=null;totpRun++;});
$('add-reset').onclick=async()=>{if(!wizard().done.every(Boolean)&&!(await confirmAction('清空这些步骤的进度，重新开始添加新账号？\n已经新建的 Chrome 资料和已保存的账号不会被删除。')))return;await saveWizard(blankWizard());$('add-status').hidden=true;renderWizard();};
function render(){
  const manage=isManage(),chrome=manage&&view==='profiles',byMember=manage&&view==='members';
  $('account-list').replaceChildren();
  if($('assign-filter')){
    $('assign-filter').hidden=!(hasCloud()&&manage&&view==='accounts');
    if(hasCloud()&&manage){
      const total=state.accounts.length;
      const assignedCnt=state.accounts.filter(a=>assignedOf(a).length>0).length;
      const idleCnt=total-assignedCnt;
      const btnAll=document.querySelector('[data-assign-filter="all"]');
      const btnIdle=document.querySelector('[data-assign-filter="idle"]');
      const btnAssigned=document.querySelector('[data-assign-filter="assigned"]');
      if(btnAll)btnAll.textContent=`全部 (${total})`;
      if(btnIdle)btnIdle.textContent=`未分配 (${idleCnt})`;
      if(btnAssigned)btnAssigned.textContent=`已分配 (${assignedCnt})`;
    }
  }
  if($('accounts-tip'))$('accounts-tip').textContent=manage?(byMember?'按人员查看已持有账号 · 点击「+ 分配闲置账号」从空闲池分配':'双击账号行快速切换 · 点击备注修改信息 · 拖动可调整分组'):'双击账号行即可快速切换到该账号';
  if(chrome&&state.chrome?.error)$('account-list').append(node('p','Chrome 资料记录无法读取（'+state.chrome.error+'）。账号功能不受影响，可到“检查修复”导出诊断报告。','view-warning'));
  else if(chrome&&state.chrome&&!state.chrome.installed)$('account-list').append(node('p','没有找到 Google Chrome，暂时不能打开资料；绑定和记录仍可编辑。','view-warning'));
  else if(chrome&&state.chrome?.denied)$('account-list').append(node('p','macOS 不允许本工具读取 Chrome 的资料列表，已绑定的资料仍可打开，但不能绑定新的。请到「系统设置 → 隐私与安全性 → 完全磁盘访问权限」打开「Claude 账号管理工具」（应用文件名是「Claude 账号切换器」），然后退出并重新打开本工具。详见「使用帮助」底部的「更多说明」。','view-warning'));
  else if(chrome&&state.chrome&&!state.chrome.readable)$('account-list').append(node('p','暂时读不到 Chrome 的资料列表。打开一次 Chrome 后再回来看看。','view-warning'));
  const list=visibleAccounts();
  if(!list.length){$('account-list').append(node('p',manage?'还没有保存的账号。点「添加新账号」，按步骤登录并能聊天后，点「完成登录并保存」；也可点「我的账号」拉取云端账号。':(isAdmin()?'当前没有分配给你的云端账号，也没有本机未上传的快照。如需在本机切换使用云端账号，请先在「账号管理」中将其分配给自己。':'管理员还没有给你分配账号，或尚未同步。'),'empty'));}
  else if(byMember){
    const idleAccs=state.accounts.filter(a=>!assignedOf(a).length);
    const idleSection=node('section',undefined,'group group-active'),idleHead=node('div',undefined,'group-head'),idleBody=node('div',undefined,'group-body');
    idleHead.append(node('i',undefined,'group-dot'),node('h3','未分配（空闲可分）'),node('span',String(idleAccs.length),'group-count'));
    idleSection.append(idleHead,idleBody);
    if(idleAccs.length){
      const cols=node('div',undefined,'account-list-head');cols.setAttribute('aria-hidden','true');
      cols.append(node('span'),node('span','账号'),node('span','5 小时剩余'),node('span','本周剩余'),node('span','到期'),node('span','备注'));
      idleBody.append(cols);
      for(const a of idleAccs)idleBody.append(accountRow(a));
    }else{
      idleBody.append(node('p','所有账号均已分配，暂无空闲账号','group-empty'));
    }
    $('account-list').append(idleSection);

    const cloudUsers=state.cloud?.users||[];
    if(!cloudUsers.length){
      $('account-list').append(node('p','云端还没有普通成员账号，请先在云端后台「用户账号管理」创建成员。','empty'));
    }else for(const u of cloudUsers){
      const memberAccs=state.accounts.filter(a=>assignedOf(a).some(uid=>String(uid)===String(u.id)));
      const section=node('section',undefined,'group group-reserve'),head=node('div',undefined,'group-head'),body=node('div',undefined,'group-body');
      const uTitle=u.name?`${u.name}（${u.username}）`:u.username;
      head.append(node('i',undefined,'group-dot'),node('h3',uTitle),node('span',`已持有 ${memberAccs.length} 个账号`,'group-count'));
      const addBtn=node('button','+ 分配闲置账号','small member-add-btn');addBtn.type='button';
      addBtn.onclick=()=>run(()=>assignToMember(u));
      head.append(addBtn);
      section.append(head,body);
      if(memberAccs.length){
        const cols=node('div',undefined,'account-list-head');cols.setAttribute('aria-hidden','true');
        cols.append(node('span'),node('span','账号'),node('span','5 小时剩余'),node('span','本周剩余'),node('span','到期'),node('span','备注'));
        body.append(cols);
        for(const a of memberAccs)body.append(accountRow(a));
      }else{
        body.append(node('p','该成员暂未分配账号，可点右上角「+ 分配闲置账号」为其分配','group-empty'));
      }
      $('account-list').append(section);
    }
  }
  else for(const [key,title] of (manage?GROUPS:[['active','使用中']])){
    const members=list.filter(a=>{
      if((manage?groupOf(a):'active')!==key)return false;
      if(manage&&view==='accounts'&&hasCloud()){
        const hasA=assignedOf(a).length>0;
        if(assignFilter==='idle'&&hasA)return false;
        if(assignFilter==='assigned'&&!hasA)return false;
      }
      return true;
    });
    const section=node('section',undefined,'group group-'+key),head=node('div',undefined,'group-head'),body=node('div',undefined,'group-body');
    head.append(node('i',undefined,'group-dot'),node('h3',title),node('span',String(members.length),'group-count'));
    section.append(head,body);if(manage)dropTarget(section,key);
    if(members.length){
      const cols=node('div',undefined,'account-list-head');cols.setAttribute('aria-hidden','true');
      cols.append(node('span'),node('span','账号'),...(chrome?[node('span','Chrome 资料'),node('span','步骤进度')]:[node('span','5 小时剩余'),node('span','本周剩余'),node('span','到期')]),node('span','备注'));
      body.append(cols);
    }else body.append(node('p',manage?(assignFilter==='all'?'拖动账号到这里':'该分组下没有符合当前筛选状态的账号'):'暂无使用中的账号','group-empty'));
    for(const a of members)body.append(accountRow(a));
    $('account-list').append(section);
  }
  if($('add-dialog').open)renderWizard();
}
function showCloud(){
  const c=state.cloud,nav=document.querySelector('.sidebar nav');
  if(!c){
    if(nav)nav.hidden=false;
    $('nav-my-accounts').hidden=false;$('nav-accounts').hidden=false;$('nav-guide').hidden=false;$('nav-repair').hidden=false;
    $('login-screen').hidden=true;
    $('cloud-user').hidden=true;$('cloud-logout').hidden=true;
    if($('cloud-pull'))$('cloud-pull').hidden=true;
    $('cloud-push').hidden=true;$('cloud-assign').hidden=true;
    tab(activeTab,{renderNow:false});
    return true;
  }
  if(!c.loggedIn){
    if(nav)nav.hidden=true;
    $('stop-claude').hidden=true;$('cloud-user').hidden=true;$('cloud-logout').hidden=true;
    document.querySelectorAll('.panel').forEach(p=>p.hidden=p.id!=='login-screen');
    fillRememberedLogin(c.username);
    return false;
  }
  if(nav)nav.hidden=false;
  $('stop-claude').hidden=false;
  const admin=c.user?.role==='admin',roleText=admin?'管理员':'成员';
  $('nav-my-accounts').hidden=false;
  $('nav-accounts').hidden=!admin;
  $('nav-guide').hidden=!admin;
  $('nav-repair').hidden=!admin;
  $('cloud-user').hidden=false;
  $('cloud-user').replaceChildren(
    node('span',(c.user.username||'U').slice(0,1).toUpperCase(),'user-avatar'),
    node('span',c.user.username,'user-name'),
    node('span',roleText,'user-role'+(admin?' is-admin':''))
  );
  $('cloud-user').title=`当前登录：${c.user.username}\n角色：${roleText}${c.lastSync?'\n上次同步：'+when(Date.parse(c.lastSync)/1000):''}`;
  $('cloud-logout').hidden=false;
  if($('cloud-pull'))$('cloud-pull').hidden=true;
  if(!admin&&view==='profiles')setView('accounts');
  if($('rebuild')?.parentElement)$('rebuild').parentElement.hidden=!admin;
  if($('choose')?.parentElement)$('choose').parentElement.hidden=!admin;
  tab(admin?activeTab:'my-accounts',{renderNow:false});
  return true;
}
async function refresh() {
  state=await api('status');
  const shortVer=String(state.version||'').split('-')[0];
  $('version').textContent=shortVer?`v${shortVer}`:state.version;
  $('version').title=`完整版本：${state.version}`;
  showLaunchGuard();
  if(!showCloud())return;
  const vis=visibleAccounts();
  const account=vis.find(a=>a.current);
  if(!vis.some(a=>a.id===selected))selected=account?.id || vis[0]?.id || null;
  render();
  syncAccountView();
  if(state.pending)$('pending-title').textContent=`正在添加 / 修复：${state.pending.name}`;
  const checks=[['Claude 应用',state.platform.installed?`已找到 · ${state.platform.claudeVersion}`:`需要检查（${state.platform.code}）`],['数据格式',state.live.compatible?`已识别 ${state.live.layout==='root'?'根目录':'Network'} Cookie 布局`:'暂未识别；请正常退出 Claude 后检查，必要时导出报告'],['桌面登录态',stateText[state.live.cookie] || '待检查'],['账号身份',state.live.uuid?'本地存在账号编号（仍需在 Claude 确认实际账号）':'未能确认；登录后打开一次 Code 页面，再正常退出'],['中断恢复',state.recovery?'需要恢复：请点击下方“恢复中断前的备份”':'没有中断记录'],['登录向导',state.pending?'尚未完成，可保存或取消恢复':'没有待完成登录']];
  $('checks').replaceChildren(); for(const [title,detail] of checks){const row=node('div',undefined,'check');row.append(node('strong',title),node('span',detail));$('checks').append(row);}
  $('recover').disabled=!state.recovery;
  noticeLoginCheck();
  const rev=state.cloud?.lastRevoked;
  if(rev?.at&&rev.at!==shownRevokedAt){
    shownRevokedAt=rev.at;
    try{sessionStorage.setItem('switcher-revoked-at',rev.at);}catch{}
    const names=(rev.labels||[]).join('、')||'当前账号';
    message(rev.closedClaude?`管理员已收回账号“${names}”，已关闭 Claude 并退出该账号的本地登录状态。`:`管理员已收回账号“${names}”，已从你的账号列表中移除。`,true);
  }
}
let working=false;
async function run(fn,{reload=true}={}){
  if(working)return; working=true; const buttons=[...document.querySelectorAll('button')]; buttons.forEach(b=>b.disabled=true);
  try{const result=await fn();if(result?.message)message(result.message);if(reload)await refresh();}
  catch(e){message(`${e.message}${e.code?'\n问题编号：'+e.code:''}`,true);if(e.code==='RECOVERY_REQUIRED'||e.code==='INDEX_CORRUPT')tab(isAdmin()?'repair':'my-accounts');}
  finally{working=false;buttons.forEach(b=>b.disabled=false);if(state)$('recover').disabled=!state.recovery;}
}
function target(){const vis=visibleAccounts();const a=vis.find(a=>a.id===selected)||state?.accounts.find(a=>a.id===selected);if(!a)throw new Error('请先选择一个已保存的账号。');return a;}
function observed(){return state?.live.uuid || null;}
function nextCloudName(a=null){
  if(a?.label&&/^C\d+$/i.test(a.label.trim()))return a.label.trim().toUpperCase();
  const used=new Set();
  for(const item of state?.accounts||[]){
    if(a&&item.id===a.id)continue;
    const m=/^C(\d+)$/i.exec(String(item.label||'').trim());
    if(m)used.add(Number(m[1]));
  }
  let n=1;
  while(used.has(n))n++;
  return `C${n}`;
}
async function promptUploadDetails(a=null){
  const f=a?accountFields(a):{name:'',email:'',password:'',totpSecret:totpKeys()['']||'',services:'Claude',note:'',organizationId:''};
  const autoName=nextCloudName(a);
  return fieldDialog({
    title:a?`上传“${a.label}”到云端（云端编号 ${autoName}）`:`保存并上传账号到云端（云端编号 ${autoName}）`,
    sub:a?'请确认或补充要一并上传到云端的账号信息':'将先退出 Claude 保存本机登录态，并把快照与以下信息一并上传到云端',
    note:'上传到云端时，服务端会自动按 C1、C2、C3… 顺序统一编号命名。首次读取钥匙串时若弹出系统窗口，请输入开机密码并点“允许”。',
    fields:[
      {key:'name',label:'账号名称',hint:'云端按 C1、C2、C3… 顺序编号',value:autoName,attrs:{maxlength:80,placeholder:autoName},validate:v=>v?'':'请输入账号名称。'},
      {key:'email',label:'邮箱',hint:'选填',value:f.email,copy:true,attrs:{maxlength:254,placeholder:'example@gmail.com'},
        validate:v=>!v||/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)?'':'请输入有效的邮箱地址。'},
      {key:'password',label:'密码',hint:'选填',value:f.password,copy:true,attrs:{maxlength:200,placeholder:'登录密码'}},
      {key:'totpSecret',label:'2FA 密钥（Key）',hint:'选填，支持 Base32 密钥或 otpauth:// 链接',value:f.totpSecret,copy:true,attrs:{maxlength:200,placeholder:'例如：JBSWY3DPEHPK3PXP'}},
      {key:'note',label:'备注',hint:'选填，同步到云端',value:f.note,attrs:{maxlength:200,placeholder:'例如：朋友代付，下月续费前确认'}},
      {key:'organizationId',label:'Organization ID',hint:'选填，留空则从登录态自动提取',value:f.organizationId,copy:true,attrs:{maxlength:36,placeholder:'xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'},
        validate:v=>!v||/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(v)?'':'格式应类似 xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'}
    ]
  });
}
async function saveUnsaved(){
  const name=await promptName('给 Claude 当前登录的账号起一个名称，例如“个人”或“工作”。');if(name===null)return null;
  if(!(await confirmAction(`保存“${name}”？\n请先确认 Claude 显示的是这个账号并能正常聊天。如果 Claude 还在运行，会先退出并结束后台进程，再保存。未保存的内容会丢失。不会点“退出登录”。`)))return null;
  await refresh();
  return api('save',{name,expectedUuid:observed(),stopFirst:true});
}
async function saveAndPushUnsaved(){
  requireNoPending();
  const v=await promptUploadDetails(null);
  if(!v)return null;
  await refresh();
  const saved=await api('save',{
    name:v.name,
    email:v.email,
    password:v.password,
    totpSecret:v.totpSecret,
    services:v.services,
    note:v.note,
    expectedUuid:observed(),
    stopFirst:true
  });
  if(!saved?.account)return saved;
  await refresh();
  const acc=state.accounts.find(a=>a.id===saved.account);
  if(acc)syncLocalTotp(acc,v.totpSecret);
  if(hasCloud()&&acc){
    const pushRes=await api('cloud-push',{id:acc.id});
    return {message:pushRes.message||'已成功保存并上传到云端！'};
  }
  return saved;
}
$('save-unsaved').onclick=()=>run(async()=>{requireNoPending();return saveUnsaved();});
if($('save-and-push'))$('save-and-push').onclick=()=>run(saveAndPushUnsaved);
async function switchSelected(){await run(async()=>{const a=target();
  if(a.cloudOnly)throw new Error(`“${a.label}”仅在云端账号列表中，未下载快照到本机。如需在本机切换使用，请先在「账号管理」中将该账号分配给自己，再到「我的账号」中切换。`);
  await requireProxy();
  if(unsavedCurrent()){
    if(!(await confirmAction('Claude 当前登录的账号还没保存。切换前要先保存它，否则之后无法切换回来。现在保存吗？')))return;
    if(!(await saveUnsaved()))return;await refresh();
  }
  // Checked right before switching: only a running Claude is quit, which stops any task still in progress, so only then ask.
  const running=(await api('status')).claudeRunning!==false;
  if(running&&!(await confirmAction(`切换到“${a.label}”？\nClaude 正在运行。切换会退出 Claude，还没完成的任务（例如 Code 里正在执行的会话、正在生成的回复）会被中断。\n请先在 Claude 里确认没有会话在运行，再点「确认」。`)))return;
  return api('switch',{id:a.id,expectedUuid:observed()});});}
$('switch').onclick=switchSelected;
$('refresh-quota').onclick=()=>run(async()=>{
  const res=await api('usage-refresh',{force:true});
  message(res.message||'已刷新额度。');
  await refresh();
});
$('diagnose').onclick=()=>run(async()=>{await refresh();message('检查已完成。请根据下方提示处理。');},{reload:false});
// 启动前检查代理: checked again right before anything quits or opens Claude, so no confirmation is asked in vain.
// The backend checks too; this only stops early.
async function requireProxy(){const g=(await api('status')).launchGuard;if(g?.port&&!g.ok)throw Object.assign(new Error(`${g.reason}。按「启动前检查代理」设置，这次没有切换账号，也没有关闭或打开 Claude。请在 v2rayN 里打开系统代理后重试；不需要这项检查时，点左下角「代理检查」把端口清空。`),{code:'PROXY_REQUIRED'});}
function showLaunchGuard(){
  const g=state.launchGuard,button=$('launch-guard');button.hidden=!g;if(!g)return;
  // Kept short: the sidebar is narrow. The details are in the tooltip.
  $('launch-guard-text').textContent=g.error?'代理检查设置损坏':g.port?(g.ok?`代理检查 ${g.port}`:`代理 ${g.port} 未通过`):'代理检查：关';
  button.classList.toggle('failing',Boolean(g.error||(g.port&&!g.ok)));button.classList.toggle('ok',Boolean(g.port&&g.ok));
  button.title='启动前检查代理（点击设置端口）\n'+(g.error?'设置文件损坏，点这里重新设置端口。':g.port?(g.ok?`系统代理指向 127.0.0.1:${g.port}，端口在监听。切换账号、添加或重新登录账号前会再检查一次。`:g.reason+'。现在切换账号会被拦下。'):'开启后，系统代理没指向这个端口或端口没在监听时，不切换账号、不打开 Claude。');
}
$('launch-guard').onclick=()=>run(async()=>{
  const g=state.launchGuard||{};
  const v=await fieldDialog({title:'启动前检查代理',sub:'切换账号、添加或重新登录账号、取消登录前，先检查系统代理。',
    note:'系统代理（HTTPS）必须指向 127.0.0.1 的这个端口，并且端口在监听，否则不切换账号、不关闭也不打开 Claude。只检查本机，不联网。从程序坞或「应用程序」直接打开 Claude 时不检查。',
    fields:[{key:'port',label:'代理端口',hint:'默认 10808，留空表示不检查',value:g.port?String(g.port):'',attrs:{inputmode:'numeric',maxlength:'5',placeholder:'10808'},
      validate:x=>!x||(/^\d{1,5}$/.test(x)&&+x>=1&&+x<=65535)?'':'请输入 1～65535 的端口，或留空关闭检查。'}]});
  if(v)return api('launch-guard',{port:v.port?Number(v.port):null});
});
function requireNoPending(){if(state?.pending)throw new Error('请使用上方“完成登录并保存”按钮。');}
// Logs a saved account in again, from step 5 of its steps.
async function repairLogin(id){
  requireNoPending();const a=state.accounts.find(x=>x.id===id);if(!a)throw new Error('找不到这个账号，请刷新后重试。');await requireProxy();
  if(!(await confirmAction(`修复“${a.label}”的登录？\n当前账号会先备份，然后 Claude 会打开登录页。请登录“${a.label}”这个账号，能正常聊天后回到这里点「完成登录并保存」。登错账号会被拒绝保存，可点「取消并恢复原账号」。`)))return;
  return api('prepare',{id:a.id,expectedUuid:observed()});
}
// Starts logging in a new account; returns the name it will be saved under, or null when cancelled.
async function startLogin(initial=''){
  requireNoPending();await requireProxy();
  const name=await promptName('新账号的名称：',initial);if(name===null)return null;
  if(!(await confirmAction('准备添加新账号？\n当前账号会先备份。随后请手动登录新账号，不要对原账号点“退出登录”。能聊天后点“完成登录并保存”，工具会先退出 Claude 再保存。')))return null;
  const result=await api('prepare',{name,expectedUuid:observed()});
  return {name,result};
}
// Saves the pending login. An account started from the add-account steps is then bound to the
// Chrome profile those steps created.
async function finishLogin(){
  if(!state?.pending)return;
  const name=state.pending.name;
  if(!(await confirmAction(`保存“${name}”？\n将先退出 Claude，并结束它留在后台的进程，然后保存当前登录。未保存的内容会丢失。不会点“退出登录”。`)))return;
  await refresh();
  const saved=await api('save',{id:state.pending.id,name,expectedUuid:observed(),stopFirst:true});
  const w=wizard();if(w.account||!w.dir||w.name!==name)return saved;
  await refresh();const a=state.accounts.find(x=>x.label===name);if(!a)return saved;
  try{
    const bound=await api('profile-edit',{id:a.id,profile:w.dir});
    // From here the progress is saved with the account; the dialog, if open, goes on showing it.
    await api('profile-steps',{id:a.id,steps:w.done.map((d,i)=>d||(i===4?Date.now():false))});
    await saveWizard(blankWizard());if($('add-dialog').open)wizardAccount=a.id;
    return {message:saved.message+'\n'+bound.message};
  }
  catch(e){return {message:saved.message+'\n没能自动绑定 Chrome 资料：'+e.message+' 可在「Chrome 资料」视图点这个账号的 Chrome 资料列绑定。'};}
}
$('finish').onclick=()=>run(finishLogin);
$('cancel').onclick=()=>run(async()=>{await requireProxy();if(await confirmAction('取消本次登录，并恢复之前备份的本地状态？'))return api('cancel');});
$('stop-claude').onclick=()=>run(async()=>{if(!(await confirmAction('关闭 Claude，并结束它留在后台的进程？\n未保存的内容会丢失。不会退出桌面账号，也不会退出这个切换器。')))return;return api('stop-claude');});
$('recover').onclick=()=>run(async()=>{if(await confirmAction('恢复上次中断操作前的数据？工具会先正常退出 Claude。'))return api('recover');});
$('rebuild').onclick=()=>run(async()=>{if(await confirmAction('扫描完整快照并重建账号列表？旧索引会保留，当前 Claude 不会被切换。请先按 ⌘Q 退出 Claude。'))return api('rebuild');});
const LOGIN_STORE_KEY='switcher-saved-login-v1';
function readSavedLogin(){
  try{
    const raw=localStorage.getItem(LOGIN_STORE_KEY);
    const parsed=raw?JSON.parse(raw):null;
    return parsed&&typeof parsed==='object'?parsed:{remember:true,username:'',password:'',history:[]};
  }catch{return {remember:true,username:'',password:'',history:[]};}
}
function writeSavedLogin({remember,username,password}){
  try{
    const prev=readSavedLogin();
    const history=Array.isArray(prev.history)?prev.history.filter(x=>x&&x.username&&x.username!==username):[];
    if(remember&&username){
      history.unshift({username,password:password||''});
      localStorage.setItem(LOGIN_STORE_KEY,JSON.stringify({remember:true,username,password:password||'',history:history.slice(0,5)}));
    }else{
      localStorage.setItem(LOGIN_STORE_KEY,JSON.stringify({remember:false,username:'',password:'',history:history.slice(0,5)}));
    }
  }catch{}
}
let loginFormFilled=false;
function fillRememberedLogin(fallbackUsername=''){
  const saved=readSavedLogin();
  if($('login-remember')&&!loginFormFilled)$('login-remember').checked=saved.remember!==false;
  const box=$('saved-logins');
  if(box){
    const list=Array.isArray(saved.history)?saved.history.filter(x=>x&&x.username):[];
    box.hidden=list.length===0;
    box.replaceChildren();
    if(list.length>0){
      box.append(node('span','历史账号：'));
      for(const item of list){
        const chip=node('button',item.username,'saved-login-chip');
        chip.type='button';
        chip.title=`点击填入账号“${item.username}”`;
        chip.onclick=()=>{
          $('login-username').value=item.username;
          $('login-password').value=item.password||'';
          if($('login-remember'))$('login-remember').checked=true;
        };
        box.append(chip);
      }
    }
  }
  if(loginFormFilled)return;
  loginFormFilled=true;
  if(saved.remember!==false&&(saved.username||fallbackUsername)){
    if(!$('login-username').value)$('login-username').value=saved.username||fallbackUsername;
    if(!$('login-password').value&&saved.password&&$('login-username').value===saved.username){
      $('login-password').value=saved.password;
    }
  }else if(!$('login-username').value&&fallbackUsername){
    $('login-username').value=fallbackUsername;
  }
}
$('login-form').onsubmit=event=>{
  event.preventDefault();
  const username=$('login-username').value.trim(),password=$('login-password').value;
  const remember=$('login-remember')?$('login-remember').checked:true;
  if(!username||!password){message('请输入登录账号和密码。',true);return;}
  run(async()=>{
    const r=await api('cloud-login',{username,password});
    writeSavedLogin({remember,username,password});
    if(!remember)$('login-password').value='';
    loginFormFilled=false;
    activeTab=r.user?.role==='admin'?'accounts':'my-accounts';
    return r;
  });
};
$('cloud-logout').onclick=()=>run(async()=>{
  if(!(await confirmAction('退出当前云端账号登录？\n退出后需要重新登录才能使用本工具。')))return;
  loginFormFilled=false;
  return api('cloud-logout');
});
if($('cloud-pull'))$('cloud-pull').onclick=()=>run(()=>api('cloud-pull'));
async function pushAccountWithDetails(targetAcc){
  const v=await promptUploadDetails(targetAcc);
  if(!v)return null;
  await api('edit',{...accountFields(targetAcc),...v});
  syncLocalTotp(targetAcc,v.totpSecret);
  const pushRes=await api('cloud-push',{id:targetAcc.id});
  await refresh();
  return {message:pushRes.message||'已成功将快照和账号信息上传到云端！'};
}
$('cloud-push').onclick=()=>run(async()=>{
  if(unsavedCurrent()&&!state?.accounts.some(a=>a.uuid===state.live.uuid)){
    if(!state?.accounts.length||(await confirmAction('当前电脑正在登录的 Claude 账号尚未保存。是否先保存并上传到云端？'))){
      return saveAndPushUnsaved();
    }
  }
  const localAccs=(state?.accounts||[]).filter(a=>!a.cloudOnly);
  if(!localAccs.length)throw new Error('本机还没有已保存的本地账号快照可上传。');
  const unuploaded=localAccs.filter(a=>state.cloud?.syncedSnapshots?.[a.id]!==a.snapshot);
  const targetAcc=localAccs.find(x=>x.id===selected)||unuploaded[0]||localAccs[0];
  return pushAccountWithDetails(targetAcc);
});
function assignDialog(a,users){return new Promise(resolve=>{
  const dialog=$('assign-dialog'),list=$('assign-list');let result=null;
  $('assign-title').textContent=`分配空闲账号“${a.label}”`;
  $('assign-sub').textContent=a.email?`账号邮箱：${a.email}（一个账号只能分配给一个人）`:'请选择一位成员（一个账号只能分配给一个人）';
  list.replaceChildren();
  const radios=users.map((u,idx)=>{
    const label=node('label',undefined,'assign-item'),radio=document.createElement('input');
    radio.type='radio';radio.name='assign-single-user';radio.value=u.id;radio.checked=idx===0;
    const heldCnt=(u.accountIds||[]).length;
    label.append(radio,node('span',u.name?`${u.name}（${u.username}）`:u.username),node('small',heldCnt?`已持有 ${heldCnt} 个账号`:'暂未持有账号'));
    return {id:u.id,radio,label};
  });
  list.append(...radios.map(x=>x.label));
  $('assign-empty').hidden=users.length>0;
  $('assign-ok').textContent='确认分配';
  $('assign-ok').disabled=users.length===0;$('assign-cancel').disabled=false;
  $('assign-form').onsubmit=()=>{
    const picked=radios.find(x=>x.radio.checked);
    result=picked?[picked.id]:null;
  };
  $('assign-cancel').onclick=()=>dialog.close();
  dialog.onclose=()=>resolve(result);
  dialog.showModal();
});}
function assignIdleAccountsDialog(member,idleAccs){return new Promise(resolve=>{
  const dialog=$('assign-dialog'),list=$('assign-list');let result=null;
  const uTitle=member.name?`${member.name}（${member.username}）`:member.username;
  $('assign-title').textContent=`给“${uTitle}”分配闲置账号`;
  $('assign-sub').textContent='仅显示当前「未分配」的空闲账号（一个人可分配多个账号；已分配给别人的账号需先收回）';
  list.replaceChildren();
  const boxes=idleAccs.map(acc=>{
    const label=node('label',undefined,'assign-item'),box=document.createElement('input');
    box.type='checkbox';box.value=acc.id;
    const synced=state.cloud?.syncedSnapshots?.[acc.id]===acc.snapshot;
    label.append(box,node('span',acc.label+(acc.email?` · ${acc.email}`:'')),node('small',synced?(GROUPS.find(g=>g[0]===groupOf(acc))?.[1]||''):'待上传快照'));
    return {acc,box,label};
  });
  list.append(...boxes.map(x=>x.label));
  $('assign-empty').hidden=idleAccs.length>0;
  $('assign-ok').textContent='确认分配';
  $('assign-ok').disabled=idleAccs.length===0;$('assign-cancel').disabled=false;
  $('assign-form').onsubmit=()=>{result=boxes.filter(x=>x.box.checked).map(x=>x.acc);};
  $('assign-cancel').onclick=()=>dialog.close();
  dialog.onclose=()=>resolve(result);
  dialog.showModal();
});}
async function assignAccount(a=target()){
  const curAssigned=assignedOf(a);
  if(curAssigned.length>0){
    const who=assigneeNameOf(a);
    if(!(await confirmAction(`账号“${a.label}”当前已分配给「${who}」。\n\n确定从「${who}」名下收回“${a.label}”吗？\n• 该账号将恢复为「未分配」空闲状态，可重新分配给其他人\n• 若「${who}」正在使用该账号，其客户端会立即弹窗提醒，确认后自动关闭 Claude 并退出该账号登录态`)))return;
    return api('cloud-assign',{accountId:a.id,userIds:[]});
  }
  if(state.cloud?.syncedSnapshots?.[a.id]!==a.snapshot){
    if(!(await confirmAction(`“${a.label}”的最新快照还没有上传到云端。\n要先上传它的快照到云端，再分配给成员吗？`)))return;
    const pushed=await pushAccountWithDetails(a);
    if(!pushed)return;
  }
  const {users}=await api('cloud-users');
  const chosen=await assignDialog(a,users);
  if(!chosen||!chosen.length)return;
  return api('cloud-assign',{accountId:a.id,userIds:chosen});
}
async function assignToMember(member){
  const idleAccs=state.accounts.filter(a=>!assignedOf(a).length);
  if(!idleAccs.length)throw new Error('当前没有空闲的「未分配」账号。已分配给其他成员的账号需先收回后才能重新分配。');
  const chosenAccs=await assignIdleAccountsDialog(member,idleAccs);
  if(!chosenAccs||!chosenAccs.length)return;
  for(const acc of chosenAccs){
    if(state.cloud?.syncedSnapshots?.[acc.id]!==acc.snapshot){
      const pushed=await pushAccountWithDetails(acc);
      if(!pushed)return;
    }
    await api('cloud-assign',{accountId:acc.id,userIds:[String(member.id)]});
  }
  const uTitle=member.name?`${member.name}（${member.username}）`:member.username;
  return {message:`已将 ${chosenAccs.length} 个空闲账号分配给「${uTitle}」。`};
}
$('cloud-assign').onclick=()=>run(()=>assignAccount());
$('choose').onclick=()=>run(()=>api('choose'));
$('report').onclick=()=>run(async()=>{
  const report=await api('report'),text=JSON.stringify(report,null,2);$('report-preview').hidden=false;$('report-content').value=text;
  if(window.switcherDesktop){
    const saved=await window.switcherDesktop.exportReport();
    if(!saved.ok)throw new Error('报告未能保存，请重试；也可展开下方复制脱敏报告。');
    message(saved.canceled?'已取消保存，仍可在下方查看和复制脱敏报告。':'脱敏报告已保存到你选择的位置。');return;
  }
  const url=URL.createObjectURL(new Blob([text],{type:'application/json'})),a=document.createElement('a');a.href=url;a.download='ClaudeSwitcher-诊断报告.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),1000);
  message('脱敏报告已生成；也可展开下方查看和复制。');
},{reload:false});
// In-app update: the window's main process checks, downloads and installs; this page only shows it.
const updates=window.switcherDesktop?.update;
let updateState={phase:'idle'};
const size=n=>n<1048576?Math.max(1,Math.round(n/1024))+' KB':(n/1048576).toFixed(n<10485760?1:0)+' MB';
function showUpdate(s){
  updateState=s;
  const shown=['available','downloading','preparing','installing'].includes(s.phase)||(s.phase==='error'&&s.during==='apply');
  $('update').hidden=!shown;if(!shown)return;
  $('update').classList.toggle('error',s.phase==='error');
  const percent=s.size?Math.floor((s.received||0)/s.size*100):0;
  $('update-title').textContent={available:`有新版本 ${s.version}`,downloading:`正在下载新版本 ${s.version}…`,preparing:`正在准备新版本 ${s.version}…`,installing:'正在安装新版本…',error:'更新没有完成'}[s.phase];
  $('update-detail').textContent={
    available:[s.notes,s.kind==='full'?`这次包含新的运行环境，需要下载完整安装包，约 ${size(s.size)}。`:`下载约 ${size(s.size)}。`].filter(Boolean).join('\n'),
    downloading:`已下载 ${percent}%（${size(s.received||0)} / ${size(s.size)}）。下载时可以继续使用。`,
    preparing:'正在校验并组装新版本，可以继续使用。完成后工具会自动关闭并打开新版本。',
    installing:'工具会自动关闭并打开新版本。',
    error:`${s.message}${s.code?'（问题编号：'+s.code+'）':''}\n旧版本仍可正常使用。`}[s.phase];
  $('update-progress').hidden=s.phase!=='downloading';$('update-progress').value=percent;
  $('update-apply').hidden=!['available','error'].includes(s.phase);$('update-apply').textContent=s.phase==='error'?'重试':'更新';
}
$('update-apply').onclick=async()=>{
  const s=updateState;
  if(s.phase==='available'&&!(await confirmAction(`更新到 ${s.version}？\n${s.kind==='full'?`需要下载约 ${size(s.size)}。`:''}下载和准备时可以继续使用；准备好后工具会自动关闭并打开新版本，账号数据不受影响。\n如果正在切换或保存账号，请等完成后再更新。`)))return;
  $('update-apply').disabled=true;
  try{await updates.apply();}catch{}finally{$('update-apply').disabled=false;}
};
$('check-update').onclick=async()=>{
  const s=await updates.check();
  if(s?.phase==='latest')message(`已是最新版本（${s.current}）。`);
  else if(s?.phase==='error'&&s.during==='check')message(`暂时无法检查更新：${s.message}`,true);
};
if(updates){
  $('check-update').hidden=false;
  updates.onChange(showUpdate);
  updates.start().then(r=>{
    if(!r)return;
    if(r.result)message(r.result.ok?`已更新到 ${r.result.version}。`:`上次更新没有完成：${r.result.message}（问题编号：${r.result.code}）\n旧版本仍可正常使用，可以稍后重试。`,!r.result.ok);
    showUpdate(r.state);
  }).catch(()=>{});
}
setInterval(async()=>{if(working||polling||document.hidden)return;polling=true;try{await refresh();}catch{}finally{polling=false;}},10000);
setView(view);
run(refresh,{reload:false});
